import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  // Load all env vars (not just VITE_-prefixed) so we can bridge values that
  // arrive under NEXT_PUBLIC_/unprefixed names from the hosting environment.
  const env = loadEnv(mode, process.cwd(), '');

  // Base URL of the Klirline Express API (Aurora + Cognito). Falls back to the
  // legacy SUPABASE_URL var name so existing derived URLs keep working.
  const apiUrl =
    env.VITE_API_URL ||
    env.API_URL ||
    env.VITE_SUPABASE_URL ||
    env.NEXT_PUBLIC_SUPABASE_URL ||
    env.SUPABASE_URL ||
    '';

  const cognitoDomain =
    env.VITE_COGNITO_DOMAIN || env.COGNITO_DOMAIN || '';
  const cognitoClientId =
    env.VITE_COGNITO_CLIENT_ID || env.COGNITO_CLIENT_ID || '';

  return {
    plugins: [react()],
    optimizeDeps: {
      exclude: ['lucide-react'],
    },
    define: {
      'import.meta.env.VITE_API_URL': JSON.stringify(apiUrl),
      // Kept for backwards compatibility with any code still reading it.
      'import.meta.env.VITE_SUPABASE_URL': JSON.stringify(apiUrl),
      'import.meta.env.VITE_COGNITO_DOMAIN': JSON.stringify(cognitoDomain),
      'import.meta.env.VITE_COGNITO_CLIENT_ID': JSON.stringify(cognitoClientId),
    },
  };
});
