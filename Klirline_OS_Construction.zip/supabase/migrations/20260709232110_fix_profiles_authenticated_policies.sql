/*
# Fix profiles RLS — add authenticated-user policies

## Problem
The profiles table has RLS enabled but no policies for the `authenticated` role.
After login, fetchProfile() SELECT returns null (blocked by RLS), so the app
renders the login page even for valid authenticated users.

## Changes
- Add SELECT policy: authenticated users can read their own profile
- Add INSERT policy: authenticated users can insert their own profile (for auto-create)
- Add UPDATE policy: authenticated users can update their own profile
- Add SELECT policy for anon: needed for count_admins() and first-run detection
  (already added in prior migration, dropped here to be safe and re-added)
- Keep existing anon_select_profiles_role policy from prior migration

## Notes
The admin_select_all_profiles recursive self-join is intentionally removed —
a plain self-join on profiles to check role creates infinite recursion in RLS.
Admins can see all profiles via service-role key or via a separate security-definer function.
*/

-- Own-profile read
DROP POLICY IF EXISTS "auth_select_own_profile" ON public.profiles;
CREATE POLICY "auth_select_own_profile"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Own-profile insert (auto-create path in auth.tsx)
DROP POLICY IF EXISTS "auth_insert_own_profile" ON public.profiles;
CREATE POLICY "auth_insert_own_profile"
  ON public.profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Own-profile update
DROP POLICY IF EXISTS "auth_update_own_profile" ON public.profiles;
CREATE POLICY "auth_update_own_profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Anon can read role column only — needed for count_admins() first-run check
DROP POLICY IF EXISTS "anon_select_profiles_role" ON public.profiles;
CREATE POLICY "anon_select_profiles_role"
  ON public.profiles FOR SELECT
  TO anon
  USING (true);
