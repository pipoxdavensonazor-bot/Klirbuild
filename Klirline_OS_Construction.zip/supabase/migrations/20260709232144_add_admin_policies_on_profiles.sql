/*
# Add admin policies on profiles for UsersAdmin page

## Problem
Admins need to read and update ALL profiles (not just their own).
A recursive self-join (SELECT FROM profiles WHERE role = 'admin') causes
infinite recursion in RLS. Instead, we use a SECURITY DEFINER helper
function that bypasses RLS to check the caller's role.

## Changes
- Add is_admin_or_manager() SECURITY DEFINER function
- Add admin SELECT policy: admins can read all profiles
- Add admin UPDATE policy: admins can update any profile
*/

CREATE OR REPLACE FUNCTION public.is_admin_or_manager()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid()
      AND role IN ('admin', 'manager')
  );
$$;

-- Admin: read all profiles
DROP POLICY IF EXISTS "admin_select_all_profiles" ON public.profiles;
CREATE POLICY "admin_select_all_profiles"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (public.is_admin_or_manager());

-- Admin: update any profile
DROP POLICY IF EXISTS "admin_update_any_profile" ON public.profiles;
CREATE POLICY "admin_update_any_profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (public.is_admin_or_manager())
  WITH CHECK (true);
