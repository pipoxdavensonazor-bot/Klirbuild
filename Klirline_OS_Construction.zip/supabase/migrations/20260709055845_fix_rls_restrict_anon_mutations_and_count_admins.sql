/*
# Security hardening: restrict anon mutations + fix count_admins

## Summary
Closes critical RLS holes where unauthenticated (anon) users could
INSERT, UPDATE, and DELETE data in clients, employees, leads, projects,
tasks, and time_entries. Also fixes the count_admins() SECURITY DEFINER
exposure.

## Changes

### 1. RLS mutation policies (6 tables)
- DROP existing anon_insert / anon_update / anon_delete policies.
- Recreate each as TO authenticated only.

### 2. count_admins() function
- Switch from SECURITY DEFINER to SECURITY INVOKER.
- Add minimal anon SELECT policy on profiles so the function still works
  when called pre-login to detect first-run state.
*/

-- ─────────────────────────────────────────────
-- CLIENTS
-- ─────────────────────────────────────────────
DROP POLICY IF EXISTS "anon_insert_clients" ON public.clients;
DROP POLICY IF EXISTS "anon_update_clients" ON public.clients;
DROP POLICY IF EXISTS "anon_delete_clients" ON public.clients;

CREATE POLICY "auth_insert_clients" ON public.clients
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "auth_update_clients" ON public.clients
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "auth_delete_clients" ON public.clients
  FOR DELETE TO authenticated USING (true);

-- ─────────────────────────────────────────────
-- EMPLOYEES
-- ─────────────────────────────────────────────
DROP POLICY IF EXISTS "anon_insert_employees" ON public.employees;
DROP POLICY IF EXISTS "anon_update_employees" ON public.employees;
DROP POLICY IF EXISTS "anon_delete_employees" ON public.employees;

CREATE POLICY "auth_insert_employees" ON public.employees
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "auth_update_employees" ON public.employees
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "auth_delete_employees" ON public.employees
  FOR DELETE TO authenticated USING (true);

-- ─────────────────────────────────────────────
-- LEADS
-- ─────────────────────────────────────────────
DROP POLICY IF EXISTS "anon_insert_leads" ON public.leads;
DROP POLICY IF EXISTS "anon_update_leads" ON public.leads;
DROP POLICY IF EXISTS "anon_delete_leads" ON public.leads;

CREATE POLICY "auth_insert_leads" ON public.leads
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "auth_update_leads" ON public.leads
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "auth_delete_leads" ON public.leads
  FOR DELETE TO authenticated USING (true);

-- ─────────────────────────────────────────────
-- PROJECTS
-- ─────────────────────────────────────────────
DROP POLICY IF EXISTS "anon_insert_projects" ON public.projects;
DROP POLICY IF EXISTS "anon_update_projects" ON public.projects;
DROP POLICY IF EXISTS "anon_delete_projects" ON public.projects;

CREATE POLICY "auth_insert_projects" ON public.projects
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "auth_update_projects" ON public.projects
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "auth_delete_projects" ON public.projects
  FOR DELETE TO authenticated USING (true);

-- ─────────────────────────────────────────────
-- TASKS
-- ─────────────────────────────────────────────
DROP POLICY IF EXISTS "anon_insert_tasks" ON public.tasks;
DROP POLICY IF EXISTS "anon_update_tasks" ON public.tasks;
DROP POLICY IF EXISTS "anon_delete_tasks" ON public.tasks;

CREATE POLICY "auth_insert_tasks" ON public.tasks
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "auth_update_tasks" ON public.tasks
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "auth_delete_tasks" ON public.tasks
  FOR DELETE TO authenticated USING (true);

-- ─────────────────────────────────────────────
-- TIME_ENTRIES
-- ─────────────────────────────────────────────
DROP POLICY IF EXISTS "anon_insert_time_entries" ON public.time_entries;
DROP POLICY IF EXISTS "anon_update_time_entries" ON public.time_entries;
DROP POLICY IF EXISTS "anon_delete_time_entries" ON public.time_entries;

CREATE POLICY "auth_insert_time_entries" ON public.time_entries
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "auth_update_time_entries" ON public.time_entries
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "auth_delete_time_entries" ON public.time_entries
  FOR DELETE TO authenticated USING (true);

-- ─────────────────────────────────────────────
-- count_admins(): SECURITY INVOKER
-- ─────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.count_admins()
RETURNS integer
LANGUAGE sql
SECURITY INVOKER
STABLE
AS $$
  SELECT COUNT(*)::integer FROM public.profiles WHERE role = 'admin';
$$;

DROP POLICY IF EXISTS "anon_select_profiles_role" ON public.profiles;
CREATE POLICY "anon_select_profiles_role" ON public.profiles
  FOR SELECT TO anon USING (true);
