import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Electron build — uses relative asset paths so the app loads correctly
// from the local filesystem (file:// protocol). No service worker.
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    outDir: 'dist',
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
});
