import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { STRIPE_PRODUCTS } from '../stripe-config';

export interface SubscriptionInfo {
  status: string | null;
  priceId: string | null;
  planName: string | null;
  currentPeriodEnd: number | null;
  cancelAtPeriodEnd: boolean;
  isActive: boolean;
}

const DEFAULT: SubscriptionInfo = {
  status: null,
  priceId: null,
  planName: null,
  currentPeriodEnd: null,
  cancelAtPeriodEnd: false,
  isActive: false,
};

export function useSubscription() {
  const [subscription, setSubscription] = useState<SubscriptionInfo>(DEFAULT);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function fetchSubscription() {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          if (mounted) { setSubscription(DEFAULT); setLoading(false); }
          return;
        }

        const { data, error } = await supabase
          .from('stripe_user_subscriptions')
          .select('*')
          .maybeSingle();

        if (error || !data) {
          if (mounted) { setSubscription(DEFAULT); setLoading(false); }
          return;
        }

        const activeStatuses = ['active', 'trialing'];
        const isActive = activeStatuses.includes(data.subscription_status ?? '');
        const product = STRIPE_PRODUCTS.find(p => p.priceId === data.price_id);

        if (mounted) {
          setSubscription({
            status: data.subscription_status ?? null,
            priceId: data.price_id ?? null,
            planName: product?.name ?? null,
            currentPeriodEnd: data.current_period_end ?? null,
            cancelAtPeriodEnd: data.cancel_at_period_end ?? false,
            isActive,
          });
          setLoading(false);
        }
      } catch {
        if (mounted) { setSubscription(DEFAULT); setLoading(false); }
      }
    }

    fetchSubscription();

    const { data: { subscription: authSub } } = supabase.auth.onAuthStateChange(() => {
      fetchSubscription();
    });

    return () => {
      mounted = false;
      authSub?.unsubscribe();
    };
  }, []);

  return { subscription, loading };
}