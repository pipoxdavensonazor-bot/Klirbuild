import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { StripeProduct } from '../stripe-config';

interface UseCheckoutReturn {
  loading: boolean;
  error: string | null;
  initiateCheckout: (product: StripeProduct) => Promise<void>;
}

export function useCheckout(): UseCheckoutReturn {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const initiateCheckout = async (product: StripeProduct) => {
    setLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('You must be logged in to subscribe.');
      }

      const successUrl = `${window.location.origin}/success?plan=${encodeURIComponent(product.name)}`;
      const cancelUrl = `${window.location.origin}/pricing`;

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-checkout`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            price_id: product.priceId,
            success_url: successUrl,
            cancel_url: cancelUrl,
            mode: product.mode,
          }),
        }
      );

      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to create checkout session.');
      }

      const { url } = await response.json();
      if (!url) throw new Error('No checkout URL returned.');

      window.location.href = url;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
      setLoading(false);
    }
  };

  return { loading, error, initiateCheckout };
}