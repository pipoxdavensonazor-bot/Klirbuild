import { Bell, Search, Plus, Menu } from 'lucide-react';
import { useMobileMenu } from '../lib/mobile-menu';

interface HeaderProps {
  title: string;
  subtitle?: string;
  action?: { label: string; onClick: () => void };
}

export default function Header({ title, subtitle, action }: HeaderProps) {
  const openMenu = useMobileMenu();

  return (
    <header className="flex items-center justify-between px-4 md:px-6 py-3 md:py-4 bg-white border-b border-slate-100 sticky top-0 z-10">
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={openMenu}
          className="md:hidden p-2 -ml-1 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition flex-shrink-0"
        >
          <Menu size={20} />
        </button>
        <div className="min-w-0">
          <h1 className="text-lg md:text-xl font-bold text-slate-900 truncate">{title}</h1>
          {subtitle && <p className="text-xs md:text-sm text-slate-500 mt-0.5 truncate">{subtitle}</p>}
        </div>
      </div>
      <div className="flex items-center gap-2 md:gap-3 flex-shrink-0">
        <div className="relative hidden md:block">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Rechercher..."
            className="pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 w-56 transition"
          />
        </div>
        <button className="relative p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition">
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-orange-500 rounded-full" />
        </button>
        {action && (
          <button
            onClick={action.onClick}
            className="flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold rounded-lg transition shadow-sm shadow-orange-200"
          >
            <Plus size={16} />
            <span className="hidden sm:inline">{action.label}</span>
            <span className="sm:hidden"><Plus size={14} /></span>
          </button>
        )}
      </div>
    </header>
  );
}
