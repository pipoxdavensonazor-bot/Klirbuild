import React from 'react';
import { Zap } from 'lucide-react';
import { useSubscription } from '../../hooks/useSubscription';

export function PlanBadge() {
  const { loading, plan, isActive } = useSubscription();

  if (loading || !plan || !isActive) return null;

  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-gradient-to-r from-violet-500 to-indigo-500 text-white shadow-sm">
      <Zap className="w-3 h-3" />
      {plan}
    </span>
  );
}