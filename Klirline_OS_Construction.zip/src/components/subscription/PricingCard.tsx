import React, { useState } from 'react';
import { Check, Loader2, Star } from 'lucide-react';
import { redirectToCheckout } from '../../lib/checkout';
import type { StripeProduct } from '../../stripe-config';

interface PricingCardProps {
  product: StripeProduct;
  currentPlan?: string | null;
}

export function PricingCard({ product, currentPlan }: PricingCardProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isCurrent = currentPlan?.toLowerCase() === product.name.toLowerCase();

  async function handleCheckout() {
    setError(null);
    setLoading(true);
    try {
      await redirectToCheckout(product.priceId, product.mode);
    } catch (err: any) {
      setError(err.message ?? 'Something went wrong.');
      setLoading(false);
    }
  }

  return (
    <div
      className={`relative flex flex-col rounded-2xl border p-8 transition-all duration-200 ${
        product.featured
          ? 'border-violet-500 bg-gradient-to-b from-violet-950/60 to-indigo-950/60 shadow-xl shadow-violet-500/10 scale-105'
          : 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/8'
      }`}
    >
      {product.featured && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-violet-500 to-indigo-500 text-white text-xs font-semibold shadow">
            <Star className="w-3 h-3 fill-current" /> Most Popular
          </span>
        </div>
      )}

      <div className="mb-6">
        <h3 className="text-lg font-semibold text-white mb-2">{product.name}</h3>
        <p className="text-sm text-gray-400 leading-relaxed min-h-[2.5rem]">{product.description}</p>
      </div>

      <div className="mb-8">
        <div className="flex items-baseline gap-1">
          <span className="text-4xl font-bold text-white">
            {product.currencySymbol}{product.price.toFixed(2)}
          </span>
          <span className="text-gray-400 text-sm">/mo</span>
        </div>
        {product.currency !== 'usd' && (
          <p className="text-xs text-gray-500 mt-1">{product.currency.toUpperCase()}</p>
        )}
      </div>

      <div className="flex-1 mb-8">
        <ul className="space-y-3">
          {product.description.split('. ').filter(Boolean).map((feat, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-gray-300">
              <Check className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
              {feat.replace(/\.$/, '')}
            </li>
          ))}
        </ul>
      </div>

      {error && <p className="text-red-400 text-xs mb-3">{error}</p>}

      <button
        onClick={handleCheckout}
        disabled={loading || isCurrent}
        className={`w-full flex items-center justify-center gap-2 py-3 px-6 rounded-xl font-semibold text-sm transition-all duration-200 ${
          isCurrent
            ? 'bg-white/10 text-gray-400 cursor-default'
            : product.featured
            ? 'bg-gradient-to-r from-violet-500 to-indigo-500 text-white hover:from-violet-400 hover:to-indigo-400 shadow-lg hover:shadow-violet-500/25'
            : 'bg-white/10 text-white hover:bg-white/20'
        } disabled:opacity-60`}
      >
        {loading && <Loader2 className="w-4 h-4 animate-spin" />}
        {isCurrent ? 'Current Plan' : loading ? 'Redirecting…' : 'Get Started'}
      </button>
    </div>
  );
}