import React from 'react';
import { Crown, Loader2 } from 'lucide-react';
import { useSubscription } from '../../hooks/useSubscription';

interface SubscriptionBadgeProps {
  className?: string;
  showIcon?: boolean;
}

export function SubscriptionBadge({ className = '', showIcon = true }: SubscriptionBadgeProps) {
  const { activeProduct, loading, isActive } = useSubscription();

  if (loading) {
    return (
      <span className={`inline-flex items-center gap-1.5 ${className}`}>
        <Loader2 className="h-3.5 w-3.5 animate-spin text-gray-500" />
      </span>
    );
  }

  if (!isActive || !activeProduct) {
    return (
      <span
        className={`inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs font-medium text-gray-400 ${className}`}
      >
        Free
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-blue-500/40 bg-blue-500/10 px-2.5 py-1 text-xs font-semibold text-blue-300 ${className}`}
    >
      {showIcon && <Crown className="h-3 w-3" />}
      {activeProduct.name}
    </span>
  );
}