import React, { useState } from 'react';
import {
  LayoutDashboard, Users, UserCircle, TrendingUp, HardHat, Clock,
  Calendar, UserCheck, Briefcase, FileText, CreditCard, BarChart3,
  FolderOpen, Mail, MessageSquare, Sparkles, Settings, ChevronLeft,
  ChevronRight, LogOut, Crown, Shield, ClipboardList, DollarSign, X
} from 'lucide-react';
import { useAuth } from '../lib/auth';

export type PageId =
  | 'dashboard' | 'clients' | 'leads' | 'projects' | 'chantiers'
  | 'presences' | 'calendrier' | 'employes' | 'rh' | 'soumissions'
  | 'facturation' | 'paiements' | 'paie' | 'ccq' | 'comptabilite' | 'documents' | 'emailhub' | 'chat'
  | 'klir-ai' | 'rapports' | 'parametres' | 'abonnements' | 'users-admin';

interface NavItem {
  id: PageId;
  label: string;
  icon: React.FC<{ size?: number; className?: string }>;
  group?: string;
  roles?: string[];
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
  { id: 'clients', label: 'Clients', icon: Users, group: 'CRM', roles: ['admin', 'manager', 'accountant'] },
  { id: 'leads', label: 'Leads', icon: TrendingUp, group: 'CRM', roles: ['admin', 'manager'] },
  { id: 'chantiers', label: 'Chantiers', icon: HardHat, group: 'Opérations', roles: ['admin', 'manager'] },
  { id: 'presences', label: 'Présences', icon: Clock, group: 'Opérations' },
  { id: 'calendrier', label: 'Calendrier', icon: Calendar, group: 'Opérations' },
  { id: 'employes', label: 'Employés', icon: UserCircle, group: 'RH', roles: ['admin', 'manager'] },
  { id: 'rh', label: 'Ressources humaines', icon: UserCheck, group: 'RH', roles: ['admin', 'manager'] },
  { id: 'soumissions', label: 'Soumissions', icon: ClipboardList, group: 'Finance', roles: ['admin', 'manager', 'accountant'] },
  { id: 'facturation', label: 'Facturation', icon: FileText, group: 'Finance', roles: ['admin', 'manager', 'accountant'] },
  { id: 'paiements', label: 'Paiements', icon: CreditCard, group: 'Finance', roles: ['admin', 'manager', 'accountant'] },
  { id: 'paie', label: 'Paie', icon: DollarSign, group: 'Finance', roles: ['admin', 'accountant'] },
  { id: 'ccq', label: 'Module CCQ', icon: HardHat, group: 'Finance', roles: ['admin', 'manager', 'accountant'] },
  { id: 'comptabilite', label: 'Comptabilité', icon: Briefcase, group: 'Finance', roles: ['admin', 'accountant'] },
  { id: 'documents', label: 'Documents', icon: FolderOpen, group: 'Ressources' },
  { id: 'emailhub', label: 'Email Hub', icon: Mail, group: 'Communication', roles: ['admin', 'manager', 'accountant'] },
  { id: 'chat', label: 'Chat', icon: MessageSquare, group: 'Communication' },
  { id: 'klir-ai', label: 'Klir AI', icon: Sparkles, group: 'Communication' },
  { id: 'rapports', label: 'Rapports', icon: BarChart3, group: 'Analyse', roles: ['admin', 'manager', 'accountant'] },
  { id: 'parametres', label: 'Paramètres', icon: Settings, roles: ['admin'] },
  { id: 'users-admin', label: 'Utilisateurs', icon: Shield, roles: ['admin'] },
  { id: 'abonnements', label: 'Abonnement', icon: Crown, roles: ['admin'] },
];

interface SidebarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  mobileOpen: boolean;
  onMobileClose: () => void;
}

export default function Sidebar({ currentPage, onNavigate, mobileOpen, onMobileClose }: SidebarProps) {
  const { profile, signOut } = useAuth();
  const [collapsed, setCollapsed] = useState(false);

  const role = profile?.role ?? 'employee';
  const visibleItems = navItems.filter(item => !item.roles || item.roles.includes(role));

  const groups: Record<string, NavItem[]> = {};
  const ungrouped: NavItem[] = [];
  for (const item of visibleItems) {
    if (item.group) {
      if (!groups[item.group]) groups[item.group] = [];
      groups[item.group].push(item);
    } else {
      ungrouped.push(item);
    }
  }

  const roleLabel: Record<string, string> = {
    admin: 'Administrateur', manager: 'Gestionnaire',
    employee: 'Employé', accountant: 'Comptable',
  };

  const roleBadgeColor: Record<string, string> = {
    admin: 'bg-orange-500/20 text-orange-400',
    manager: 'bg-blue-500/20 text-blue-400',
    employee: 'bg-emerald-500/20 text-emerald-400',
    accountant: 'bg-violet-500/20 text-violet-400',
  };

  const initials = profile?.full_name
    ? profile.full_name.split(' ').map(p => p[0]).join('').toUpperCase().slice(0, 2)
    : profile?.email?.[0]?.toUpperCase() ?? '?';

  const handleNavigate = (page: PageId) => {
    onNavigate(page);
    onMobileClose();
  };

  const sidebarContent = (
    <aside
      className={`flex flex-col bg-slate-900 text-white h-full transition-all duration-300 ${
        collapsed ? 'w-16' : 'w-64'
      } flex-shrink-0`}
    >
      {/* Logo */}
      <div className={`flex items-center border-b border-slate-700/60 ${collapsed ? 'justify-center px-3 py-4' : 'px-4 py-3'}`}>
        {collapsed ? (
          <div className="w-9 h-9 rounded-xl bg-white flex items-center justify-center overflow-hidden flex-shrink-0">
            <img src="/Copilot_20260624_204551.png" alt="Klirline" className="w-8 h-8 object-contain" />
          </div>
        ) : (
          <div className="flex items-center gap-2.5 w-full">
            <div className="w-9 h-9 rounded-xl bg-white flex items-center justify-center overflow-hidden flex-shrink-0 shadow-sm">
              <img src="/Copilot_20260624_204551.png" alt="Klirline" className="w-8 h-8 object-contain" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-black text-white text-base leading-tight tracking-tight">KLIRLINE</div>
              <div className="text-[10px] text-slate-400 font-semibold tracking-widest uppercase">OS Platform</div>
            </div>
            {/* Close button on mobile */}
            <button
              onClick={onMobileClose}
              className="md:hidden ml-auto p-1.5 text-slate-400 hover:text-white hover:bg-slate-700/50 rounded-lg transition"
            >
              <X size={16} />
            </button>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5 scrollbar-hide">
        {ungrouped.map((item) => (
          <NavButton key={item.id} item={item} active={currentPage === item.id} collapsed={collapsed} onNavigate={handleNavigate} />
        ))}

        {Object.entries(groups).map(([group, items]) => (
          <div key={group} className="mt-4">
            {!collapsed && (
              <div className="px-3 mb-1 text-[10px] font-semibold text-slate-500 uppercase tracking-widest">
                {group}
              </div>
            )}
            {collapsed && <div className="border-t border-slate-700/40 my-2" />}
            {items.map((item) => (
              <NavButton key={item.id} item={item} active={currentPage === item.id} collapsed={collapsed} onNavigate={handleNavigate} />
            ))}
          </div>
        ))}
      </nav>

      {/* Bottom: user info + logout */}
      <div className="border-t border-slate-700/60 p-3 space-y-1">
        {!collapsed && profile && (
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl bg-slate-800/50 mb-1">
            <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
              {initials}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-semibold text-white truncate">{profile.full_name ?? profile.email}</div>
              <div className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full inline-block mt-0.5 ${roleBadgeColor[role] ?? 'bg-slate-700 text-slate-400'}`}>
                {roleLabel[role] ?? role}
              </div>
            </div>
          </div>
        )}
        {collapsed && profile && (
          <div className="flex justify-center mb-1">
            <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold text-sm" title={profile.full_name ?? ''}>
              {initials}
            </div>
          </div>
        )}
        <button
          onClick={() => signOut()}
          title={collapsed ? 'Déconnexion' : undefined}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors text-sm"
        >
          <LogOut size={16} />
          {!collapsed && <span>Déconnexion</span>}
        </button>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="hidden md:flex w-full items-center justify-center gap-2 px-3 py-2 rounded-lg text-slate-500 hover:text-white hover:bg-slate-700/50 transition-colors text-sm"
        >
          {collapsed ? <ChevronRight size={16} /> : <><ChevronLeft size={16} /><span>Réduire</span></>}
        </button>
      </div>
    </aside>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <div className="hidden md:flex h-screen">
        {sidebarContent}
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 md:hidden"
          onClick={onMobileClose}
        />
      )}

      {/* Mobile drawer */}
      <div
        className={`fixed inset-y-0 left-0 z-50 md:hidden flex transition-transform duration-300 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {sidebarContent}
      </div>
    </>
  );
}

function NavButton({
  item, active, collapsed, onNavigate,
}: {
  item: NavItem;
  active: boolean;
  collapsed: boolean;
  onNavigate: (page: PageId) => void;
}) {
  const Icon = item.icon;
  return (
    <button
      onClick={() => onNavigate(item.id)}
      title={collapsed ? item.label : undefined}
      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 ${
        active
          ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20'
          : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
      } ${collapsed ? 'justify-center' : ''}`}
    >
      <Icon size={18} className="flex-shrink-0" />
      {!collapsed && <span className="truncate">{item.label}</span>}
    </button>
  );
}
