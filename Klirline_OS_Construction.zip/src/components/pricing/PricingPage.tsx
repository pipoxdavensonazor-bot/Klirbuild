import React from 'react';
import { AlertCircle } from 'lucide-react';
import { STRIPE_PRODUCTS } from '../../stripe-config';
import { useCheckout } from '../../hooks/useCheckout';
import { useSubscription } from '../../hooks/useSubscription';
import { PricingCard } from './PricingCard';
import { StripeProduct } from '../../stripe-config';

interface PricingPageProps {
  isAuthenticated: boolean;
  onLoginRequired?: () => void;
}

export function PricingPage({ isAuthenticated, onLoginRequired }: PricingPageProps) {
  const { loading, error, initiateCheckout } = useCheckout();
  const { activeProduct } = useSubscription();

  const handleSelect = (product: StripeProduct) => {
    if (!isAuthenticated) {
      onLoginRequired?.();
      return;
    }
    initiateCheckout(product);
  };

  const usdProducts = STRIPE_PRODUCTS.filter(p => p.currency === 'usd');
  const cadProducts = STRIPE_PRODUCTS.filter(p => p.currency === 'cad');

  return (
    <div className="min-h-screen bg-gray-950 py-16 px-4">
      <div className="mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white tracking-tight">
            Simple, transparent pricing
          </h1>
          <p className="mt-3 text-lg text-gray-400">
            Choose the plan that fits your needs. Upgrade or cancel anytime.
          </p>
        </div>

        {error && (
          <div className="mb-8 mx-auto max-w-md flex items-start gap-3 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">
            <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          {usdProducts.map(product => (
            <PricingCard
              key={product.priceId}
              product={product}
              isCurrentPlan={activeProduct?.priceId === product.priceId}
              onSelect={handleSelect}
              loading={loading}
              isAuthenticated={isAuthenticated}
            />
          ))}
        </div>

        {cadProducts.length > 0 && (
          <div className="mt-12">
            <div className="flex items-center gap-4 mb-6">
              <div className="h-px flex-1 bg-white/10" />
              <span className="text-xs font-medium uppercase tracking-widest text-gray-500">
                Additional Plans
              </span>
              <div className="h-px flex-1 bg-white/10" />
            </div>
            <div className="flex justify-center gap-6 flex-wrap">
              {cadProducts.map(product => (
                <div key={product.priceId} className="w-full max-w-xs">
                  <PricingCard
                    product={product}
                    isCurrentPlan={activeProduct?.priceId === product.priceId}
                    onSelect={handleSelect}
                    loading={loading}
                    isAuthenticated={isAuthenticated}
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        <p className="mt-10 text-center text-xs text-gray-600">
          Prices shown exclude applicable taxes. Subscriptions renew automatically.
        </p>
      </div>
    </div>
  );
}