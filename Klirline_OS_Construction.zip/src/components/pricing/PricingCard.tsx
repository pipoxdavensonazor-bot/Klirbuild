import React, { useState } from 'react';
import { Check, Loader2, Zap } from 'lucide-react';
import { StripeProduct } from '../../stripe-config';
import { createCheckoutSession } from '../../lib/stripe';

interface PricingCardProps {
  product: StripeProduct;
  isCurrentPlan?: boolean;
  highlighted?: boolean;
}

export function PricingCard({ product, isCurrentPlan, highlighted }: PricingCardProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCheckout() {
    setError(null);
    setLoading(true);
    try {
      const url = await createCheckoutSession(product.priceId, product.mode);
      window.location.href = url;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
      setLoading(false);
    }
  }

  const priceDisplay = product.price !== null
    ? `${product.currencySymbol}${product.price.toFixed(2)}`
    : 'Custom';

  const intervalLabel = product.mode === 'subscription' ? '/mo' : '';

  return (
    <div
      className={`relative flex flex-col rounded-2xl border p-8 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${
        highlighted
          ? 'border-indigo-500 bg-indigo-600 text-white shadow-lg shadow-indigo-200'
          : 'border-gray-200 bg-white text-gray-900 shadow-sm'
      }`}
    >
      {highlighted && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-400 px-3 py-1 text-xs font-semibold text-amber-900">
            <Zap className="h-3 w-3" />
            Most Popular
          </span>
        </div>
      )}

      {isCurrentPlan && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2">
          <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
            highlighted ? 'bg-white text-indigo-700' : 'bg-indigo-100 text-indigo-700'
          }`}>
            <Check className="h-3 w-3" />
            Current Plan
          </span>
        </div>
      )}

      <div className="mb-6">
        <h3 className={`text-xl font-bold ${highlighted ? 'text-white' : 'text-gray-900'}`}>
          {product.name}
        </h3>
        {product.description && (
          <p className={`mt-2 text-sm leading-relaxed ${highlighted ? 'text-indigo-100' : 'text-gray-500'}`}>
            {product.description}
          </p>
        )}
      </div>

      <div className="mb-8">
        <div className="flex items-end gap-1">
          <span className={`text-4xl font-extrabold tracking-tight ${highlighted ? 'text-white' : 'text-gray-900'}`}>
            {priceDisplay}
          </span>
          {intervalLabel && (
            <span className={`mb-1 text-sm font-medium ${highlighted ? 'text-indigo-200' : 'text-gray-400'}`}>
              {intervalLabel}
            </span>
          )}
        </div>
        {product.currency !== 'usd' && (
          <p className={`mt-1 text-xs ${highlighted ? 'text-indigo-200' : 'text-gray-400'}`}>
            Billed in {product.currency.toUpperCase()}
          </p>
        )}
      </div>

      {error && (
        <p className="mb-4 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>
      )}

      <div className="mt-auto">
        <button
          onClick={handleCheckout}
          disabled={loading || isCurrentPlan}
          className={`flex w-full items-center justify-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-60 ${
            highlighted
              ? 'bg-white text-indigo-700 hover:bg-indigo-50 active:bg-indigo-100'
              : 'bg-indigo-600 text-white hover:bg-indigo-700 active:bg-indigo-800'
          }`}
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Redirecting…
            </>
          ) : isCurrentPlan ? (
            'Active'
          ) : product.mode === 'payment' ? (
            'Support Now'
          ) : (
            'Get Started'
          )}
        </button>
      </div>
    </div>
  );
}