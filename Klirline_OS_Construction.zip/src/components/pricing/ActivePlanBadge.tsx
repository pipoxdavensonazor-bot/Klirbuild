import React from 'react';
import { Crown } from 'lucide-react';
import { useSubscription } from '../../hooks/useSubscription';

export function ActivePlanBadge() {
  const { subscription, loading } = useSubscription();

  if (loading || !subscription.isActive || !subscription.planName) return null;

  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700 ring-1 ring-indigo-200">
      <Crown className="h-3 w-3" />
      {subscription.planName}
    </span>
  );
}