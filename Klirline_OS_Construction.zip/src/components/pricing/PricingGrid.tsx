import React from 'react';
import { PricingCard } from './PricingCard';
import { SUBSCRIPTION_PRODUCTS, PAYMENT_PRODUCTS } from '../../stripe-config';
import { useSubscription } from '../../hooks/useSubscription';

export function PricingGrid() {
  const { subscription } = useSubscription();

  const highlightedIndex = 2; // Pro plan

  return (
    <div className="space-y-16">
      {/* Subscription Plans */}
      <section>
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900">Subscription Plans</h2>
          <p className="mt-2 text-gray-500">Choose the plan that fits your needs. Cancel anytime.</p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {SUBSCRIPTION_PRODUCTS.map((product, i) => (
            <PricingCard
              key={product.priceId}
              product={product}
              isCurrentPlan={subscription.isActive && subscription.priceId === product.priceId}
              highlighted={i === highlightedIndex}
            />
          ))}
        </div>
      </section>

      {/* One-time Support */}
      {PAYMENT_PRODUCTS.length > 0 && (
        <section>
          <div className="mb-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900">Support</h2>
            <p className="mt-2 text-gray-500">One-time contributions to support the mission.</p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {PAYMENT_PRODUCTS.map((product) => (
              <PricingCard
                key={product.priceId}
                product={product}
              />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}