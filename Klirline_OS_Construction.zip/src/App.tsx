import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './lib/auth';
import { supabase } from './lib/supabase';
import Sidebar, { PageId } from './components/Sidebar';
import { MobileMenuContext } from './lib/mobile-menu';
import { WifiOff, CheckCircle, AlertCircle } from 'lucide-react';

function OfflineBanner() {
  const [offline, setOffline] = useState(!navigator.onLine);
  useEffect(() => {
    const on = () => setOffline(false);
    const off = () => setOffline(true);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);
  if (!offline) return null;
  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-2.5 bg-slate-800 border border-slate-600 text-slate-200 text-xs font-semibold rounded-full shadow-2xl animate-pulse">
      <WifiOff size={13} className="text-orange-400" />
      Mode hors ligne — données en cache affichées
    </div>
  );
}

// Auth pages
import LoginPage from './pages/auth/Login';
import RegisterPage from './pages/auth/Register';
import ForgotPasswordPage from './pages/auth/ForgotPassword';
import AdminSetupPage from './pages/auth/AdminSetup';

// App pages
import Dashboard from './pages/Dashboard';
import ClientsPage from './pages/Clients';
import LeadsPage from './pages/Leads';
import ChantiersPage from './pages/Chantiers';
import PresencesPage from './pages/Presences';
import CalendrierPage from './pages/Calendrier';
import EmployesPage from './pages/Employes';
import RHPage from './pages/RH';
import FacturationPage from './pages/Facturation';
import SoumissionsPage from './pages/Soumissions';
import PaiementsPage from './pages/Paiements';
import PaiePage from './pages/Paie';
import CcqPage from './pages/CCQ';
import ComptabilitePage from './pages/Comptabilite';
import DocumentsPage from './pages/Documents';
import EmailHubPage from './pages/EmailHub';
import ChatPage from './pages/Chat';
import KlirAIPage from './pages/KlirAI';
import RapportsPage from './pages/Rapports';
import ParametresPage from './pages/Parametres';
import AbonnementsPage from './pages/Abonnements';
import UsersAdminPage from './pages/UsersAdmin';

type AuthView = 'login' | 'register' | 'forgot' | 'admin-setup';

function AuthGate({ firstRun }: { firstRun: boolean }) {
  const [authView, setAuthView] = useState<AuthView>('login');

  if (authView === 'admin-setup' || firstRun) {
    return <AdminSetupPage onComplete={() => setAuthView('login')} />;
  }
  if (authView === 'register') return <RegisterPage onGoLogin={() => setAuthView('login')} />;
  if (authView === 'forgot') return <ForgotPasswordPage onGoLogin={() => setAuthView('login')} />;
  return (
    <LoginPage
      onGoRegister={() => setAuthView('register')}
      onGoForgot={() => setAuthView('forgot')}
      onGoAdminSetup={() => setAuthView('admin-setup')}
      firstRun={firstRun}
    />
  );
}

function DeactivatedScreen() {
  const { signOut } = useAuth();
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full text-center">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-3xl">&#128274;</span>
        </div>
        <h2 className="text-xl font-bold text-slate-900 mb-2">Compte désactivé</h2>
        <p className="text-slate-500 text-sm mb-6">Votre compte a été désactivé par un administrateur. Contactez votre responsable pour réactiver l'accès.</p>
        <button onClick={() => signOut()} className="w-full py-3 bg-slate-900 text-white font-bold rounded-xl transition hover:bg-slate-800 text-sm">
          Se déconnecter
        </button>
      </div>
    </div>
  );
}

function AppShellSafe() {
  const { user, profile, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState<PageId>('dashboard');
  const [firstRun, setFirstRun] = useState<boolean | null>(null);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const showNotification = (type: 'success' | 'error', msg: string) => {
    setNotification({ type, msg });
    setTimeout(() => setNotification(null), 4000);
  };

  // Handle OAuth callback URL params (Gmail, M365, Stripe checkout)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    let navigateTo: PageId | null = null;

    if (params.get('gmail_connected') === 'true') {
      showNotification('success', `Gmail connecté : ${params.get('gmail_email') ?? ''}`);
      navigateTo = 'emailhub';
    } else if (params.get('gmail_error')) {
      showNotification('error', `Erreur Gmail : ${params.get('gmail_error')}`);
    }

    if (params.get('m365_connected') === 'true') {
      showNotification('success', `Microsoft 365 connecté : ${params.get('ms_email') ?? ''}`);
      navigateTo = 'parametres';
    } else if (params.get('m365_error')) {
      showNotification('error', `Erreur Microsoft 365 : ${params.get('m365_error')}`);
    }

    if (params.get('checkout') === 'success') {
      showNotification('success', 'Paiement réussi ! Votre abonnement est activé.');
      navigateTo = 'abonnements';
    }

    if (navigateTo) setCurrentPage(navigateTo);
    if (params.toString()) window.history.replaceState({}, '', window.location.pathname);
  }, []);

  // Listen for in-app navigation events from pages (e.g. Parametres → Abonnements)
  useEffect(() => {
    const handler = (e: CustomEvent) => setCurrentPage(e.detail as PageId);
    window.addEventListener('klirline:navigate', handler as EventListener);
    return () => window.removeEventListener('klirline:navigate', handler as EventListener);
  }, []);

  useEffect(() => {
    if (loading) return;
    if (user) { setFirstRun(false); return; }
    // Use secure count_admins() RPC — returns an integer, no PII exposed
    supabase
      .rpc('count_admins')
      .then(({ data }) => setFirstRun((data ?? 1) === 0));
  }, [user, loading]);

  // Show spinner while auth or first-run check is pending
  if (loading || firstRun === null) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-white flex items-center justify-center shadow-xl">
            <img src="/Copilot_20260624_204551.png" alt="Klirline" className="w-14 h-14 object-contain" />
          </div>
          <div className="w-10 h-10 border-4 border-slate-700 border-t-orange-500 rounded-full animate-spin" />
          <p className="text-slate-400 text-sm">Chargement de Klirline OS...</p>
        </div>
      </div>
    );
  }

  if (!user || !profile) return <AuthGate firstRun={firstRun} />;
  if (!profile.is_active) return <DeactivatedScreen />;

  const role = profile.role;

  const employeeAllowed: PageId[] = ['dashboard', 'presences', 'calendrier', 'documents', 'chat', 'klir-ai'];
  const accountantAllowed: PageId[] = ['dashboard', 'clients', 'soumissions', 'facturation', 'paiements', 'paie', 'ccq', 'comptabilite', 'documents', 'chat', 'klir-ai', 'rapports'];

  const effectivePage: PageId = (() => {
    if (role === 'employee' && !employeeAllowed.includes(currentPage)) return 'dashboard';
    if (role === 'accountant' && !accountantAllowed.includes(currentPage)) return 'dashboard';
    return currentPage;
  })();

  const pages: Partial<Record<PageId, JSX.Element>> = {
    dashboard: <Dashboard />,
    clients: <ClientsPage />,
    leads: <LeadsPage />,
    projects: <ChantiersPage />,
    chantiers: <ChantiersPage />,
    presences: <PresencesPage />,
    calendrier: <CalendrierPage />,
    employes: <EmployesPage />,
    rh: <RHPage />,
    facturation: <FacturationPage />,
    soumissions: <SoumissionsPage />,
    paiements: <PaiementsPage />,
    paie: <PaiePage />,
    ccq: <CcqPage />,
    comptabilite: <ComptabilitePage />,
    documents: <DocumentsPage />,
    emailhub: <EmailHubPage />,
    chat: <ChatPage />,
    'klir-ai': <KlirAIPage />,
    rapports: <RapportsPage />,
    parametres: <ParametresPage />,
    abonnements: <AbonnementsPage />,
    'users-admin': <UsersAdminPage />,
  };

  return (
    <MobileMenuContext.Provider value={() => setMobileSidebarOpen(true)}>
      <div className="flex h-screen overflow-hidden bg-slate-50">
        <Sidebar
          currentPage={effectivePage}
          onNavigate={(page) => { setCurrentPage(page); setMobileSidebarOpen(false); }}
          mobileOpen={mobileSidebarOpen}
          onMobileClose={() => setMobileSidebarOpen(false)}
        />
        <main className="flex-1 flex flex-col overflow-hidden min-w-0">
          {notification && (
            <div className={`fixed top-4 right-4 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg text-sm font-semibold animate-fade-in max-w-xs ${notification.type === 'success' ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white'}`}>
              {notification.type === 'success' ? <CheckCircle size={15} /> : <AlertCircle size={15} />}
              {notification.msg}
            </div>
          )}
          {pages[effectivePage] ?? <Dashboard />}
        </main>
      </div>
    </MobileMenuContext.Provider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppShellSafe />
      <OfflineBanner />
    </AuthProvider>
  );
}
