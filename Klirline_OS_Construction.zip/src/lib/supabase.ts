/**
 * Backwards-compatible export. The app historically imported `supabase` from
 * this module. It now points at the Klirline API client (Aurora + Cognito),
 * which mirrors the Supabase JS surface the app relies on. No page code needs
 * to change — only this single indirection.
 */
import { apiClient } from './apiClient';

export const supabase = apiClient;
