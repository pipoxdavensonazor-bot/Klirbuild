export type EmployeeRole = 'admin' | 'manager' | 'foreman' | 'worker' | 'accountant';
export type EmployeeStatus = 'active' | 'inactive' | 'on_leave';
export type ProjectStatus = 'planning' | 'active' | 'paused' | 'completed' | 'cancelled';
export type LeadStage = 'new' | 'contacted' | 'proposal' | 'negotiation' | 'won' | 'lost';
export type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';
export type TaskStatus = 'todo' | 'in_progress' | 'review' | 'done';
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface Employee {
  id: string;
  first_name: string;
  last_name: string;
  email: string | null;
  phone: string | null;
  role: EmployeeRole;
  department: string | null;
  hire_date: string | null;
  salary: number | null;
  status: EmployeeStatus;
  avatar_url: string | null;
  notes: string | null;
  created_at: string;
}

export interface Client {
  id: string;
  company_name: string | null;
  first_name: string;
  last_name: string;
  email: string | null;
  phone: string | null;
  address: string | null;
  city: string | null;
  province: string | null;
  postal_code: string | null;
  status: 'active' | 'inactive';
  type: 'residential' | 'commercial' | 'industrial';
  notes: string | null;
  created_at: string;
}

export interface Lead {
  id: string;
  first_name: string;
  last_name: string;
  company_name: string | null;
  email: string | null;
  phone: string | null;
  source: string | null;
  stage: LeadStage;
  value: number | null;
  notes: string | null;
  assigned_to: string | null;
  created_at: string;
  employees?: Employee;
}

export interface Project {
  id: string;
  name: string;
  description: string | null;
  client_id: string | null;
  foreman_id: string | null;
  address: string | null;
  city: string | null;
  start_date: string | null;
  end_date: string | null;
  status: ProjectStatus;
  budget: number | null;
  spent: number;
  notes: string | null;
  qr_code: string | null;
  created_at: string;
  clients?: Client;
  foreman?: Employee;
}

export interface Task {
  id: string;
  project_id: string | null;
  title: string;
  description: string | null;
  assigned_to: string | null;
  status: TaskStatus;
  priority: TaskPriority;
  due_date: string | null;
  created_at: string;
  employees?: Employee;
}

export interface TimeEntry {
  id: string;
  employee_id: string;
  project_id: string | null;
  clock_in: string;
  clock_out: string | null;
  lat_in: number | null;
  lng_in: number | null;
  lat_out: number | null;
  lng_out: number | null;
  notes: string | null;
  status: 'active' | 'completed';
  created_at: string;
  employees?: Employee;
  projects?: Project;
}

export interface Invoice {
  id: string;
  invoice_no: string;
  client_id: string | null;
  project_id: string | null;
  issue_date: string;
  due_date: string | null;
  status: InvoiceStatus;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  total: number;
  notes: string | null;
  created_at: string;
  clients?: Client;
  projects?: Project;
}

export interface InvoiceItem {
  id: string;
  invoice_id: string;
  description: string;
  quantity: number;
  unit_price: number;
  total: number;
  sort_order: number;
}

export interface Payment {
  id: string;
  invoice_id: string;
  amount: number;
  method: string;
  paid_at: string;
  reference: string | null;
  notes: string | null;
  created_at: string;
  invoices?: Invoice;
}

export interface Expense {
  id: string;
  project_id: string | null;
  employee_id: string | null;
  category: string;
  description: string;
  amount: number;
  date: string;
  receipt_url: string | null;
  notes: string | null;
  created_at: string;
  projects?: Project;
  employees?: Employee;
}

export interface Document {
  id: string;
  name: string;
  type: string;
  file_url: string | null;
  file_size: number | null;
  mime_type: string | null;
  project_id: string | null;
  client_id: string | null;
  uploaded_by: string | null;
  notes: string | null;
  created_at: string;
  projects?: Project;
  clients?: Client;
  employees?: Employee;
}

export interface ChatChannel {
  id: string;
  name: string;
  type: 'group' | 'direct' | 'project';
  project_id: string | null;
  created_at: string;
  projects?: Project;
}

export type SoumissionStatus = 'brouillon' | 'envoyée' | 'approuvée' | 'refusée' | 'expirée';

export interface Soumission {
  id: string;
  soumission_no: string;
  client_id: string | null;
  titre: string;
  description: string | null;
  status: SoumissionStatus;
  issue_date: string;
  valid_until: string | null;
  subtotal: number;
  tps_rate: number;
  tvq_rate: number;
  tps_amount: number;
  tvq_amount: number;
  total: number;
  notes: string | null;
  converted_invoice_id: string | null;
  owner_id: string;
  created_at: string;
  updated_at: string;
  clients?: { id: string; name: string; company: string | null };
}

export interface SoumissionItem {
  id: string;
  soumission_id: string;
  description: string;
  quantity: number;
  unit: string;
  unit_price: number;
  total: number;
  sort_order: number;
}

export interface ChatMessage {
  id: string;
  channel_id: string;
  sender_name: string;
  sender_role: string | null;
  content: string;
  file_url: string | null;
  file_name: string | null;
  created_at: string;
}

export interface Email {
  id: string;
  client_id: string | null;
  direction: 'inbound' | 'outbound';
  from_addr: string;
  to_addr: string;
  subject: string;
  body: string | null;
  status: 'draft' | 'sent' | 'received';
  sent_at: string | null;
  created_at: string;
  clients?: Client;
}
