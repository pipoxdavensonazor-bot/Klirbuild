import { useState, useEffect } from 'react';
import { supabase } from './supabase';
import { useAuth } from './auth';

export interface CompanySettings {
  id?: string;
  nom_entreprise: string;
  neq: string;
  rbq: string;
  tps_no: string;
  tvq_no: string;
  adresse: string;
  ville: string;
  province: string;
  code_postal: string;
  telephone: string;
  courriel: string;
  site_web: string;
  logo_url: string;
}

export const defaultCompanySettings: CompanySettings = {
  nom_entreprise: '',
  neq: '',
  rbq: '',
  tps_no: '',
  tvq_no: '',
  adresse: '',
  ville: '',
  province: 'QC',
  code_postal: '',
  telephone: '',
  courriel: '',
  site_web: '',
  logo_url: '',
};

export function useCompanySettings() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<CompanySettings>(defaultCompanySettings);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('company_settings')
      .select('*')
      .eq('owner_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setSettings(data as CompanySettings);
        setLoading(false);
      });
  }, [user]);

  return { settings, setSettings, loading };
}
