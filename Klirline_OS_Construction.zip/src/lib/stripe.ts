import { supabase } from './supabase';

export async function createCheckoutSession(priceId: string, mode: 'subscription' | 'payment') {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error('You must be logged in to checkout.');

  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-checkout`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${session.access_token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      priceId,
      mode,
      successUrl: `${window.location.origin}/checkout/success`,
      cancelUrl: `${window.location.origin}/pricing`,
    }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Checkout failed' }));
    throw new Error(error.message || 'Failed to create checkout session');
  }

  const { url } = await response.json();
  if (!url) throw new Error('No checkout URL returned');
  return url;
}