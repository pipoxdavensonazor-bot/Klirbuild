/**
 * apiClient — a drop-in replacement for the subset of the Supabase JS client
 * that the Klirline app uses. It talks to the Klirline Express API (Aurora +
 * Cognito) but exposes the same surface (`from().select()...`, `auth.*`,
 * `rpc()`, `functions.invoke()`) so page code does not need to change.
 */

const API_URL = (import.meta.env.VITE_API_URL as string) || (import.meta.env.VITE_SUPABASE_URL as string) || '';

const SESSION_KEY = 'klirline.session';

export interface AuthUser {
  id: string;
  email: string | null;
  user_metadata?: { full_name?: string | null; role?: string | null };
}

export interface Session {
  access_token: string;
  id_token?: string;
  refresh_token: string | null;
  token_type: string;
  expires_in: number;
  expires_at: number;
  user: AuthUser;
}

type AuthEvent = 'SIGNED_IN' | 'SIGNED_OUT' | 'TOKEN_REFRESHED' | 'INITIAL_SESSION';
type AuthCallback = (event: AuthEvent, session: Session | null) => void;

// ---- session storage -------------------------------------------------------
function loadSession(): Session | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as Session) : null;
  } catch {
    return null;
  }
}

let currentSession: Session | null = loadSession();
const listeners = new Set<AuthCallback>();

function setSession(session: Session | null, event: AuthEvent) {
  currentSession = session;
  try {
    if (session) localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    else localStorage.removeItem(SESSION_KEY);
  } catch {
    /* ignore storage errors */
  }
  listeners.forEach((cb) => cb(event, session));
}

// ---- low-level fetch helpers ----------------------------------------------
async function apiFetch(path: string, options: RequestInit = {}, auth = true): Promise<Response> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };
  if (auth && currentSession?.access_token) {
    headers.Authorization = `Bearer ${currentSession.access_token}`;
  }
  return fetch(`${API_URL}${path}`, { ...options, headers });
}

// Attempt a one-time token refresh on 401s.
let refreshing: Promise<boolean> | null = null;
async function refreshSession(): Promise<boolean> {
  if (!currentSession?.refresh_token) return false;
  if (!refreshing) {
    refreshing = (async () => {
      try {
        const resp = await fetch(`${API_URL}/auth/v1/refresh`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            refresh_token: currentSession!.refresh_token,
            username: currentSession!.user?.email,
          }),
        });
        const json = await resp.json();
        if (json.session) {
          setSession(json.session, 'TOKEN_REFRESHED');
          return true;
        }
      } catch {
        /* ignore */
      }
      setSession(null, 'SIGNED_OUT');
      return false;
    })();
  }
  const result = await refreshing;
  refreshing = null;
  return result;
}

async function apiJson<T = unknown>(path: string, options: RequestInit = {}, auth = true): Promise<T> {
  let resp = await apiFetch(path, options, auth);
  if (resp.status === 401 && auth) {
    const ok = await refreshSession();
    if (ok) resp = await apiFetch(path, options, auth);
  }
  return resp.json() as Promise<T>;
}

// ---- query builder ---------------------------------------------------------
interface Filter {
  op: string;
  column: string;
  value: unknown;
}

interface QueryResult<T> {
  data: T;
  error: { message: string; code?: string } | null;
  count?: number | null;
}

// Default generic is `any` to preserve the ergonomics of the previous Supabase
// client, where `data` was loosely typed and freely used with .map/.filter/etc.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
class QueryBuilder<T = any> implements PromiseLike<QueryResult<T>> {
  private table: string;
  private _op: 'select' | 'insert' | 'update' | 'delete' | 'upsert' = 'select';
  private _select = '*';
  private _returning: string | boolean | null = null;
  private _filters: Filter[] = [];
  private _order: Array<{ column: string; ascending: boolean; nullsFirst?: boolean }> = [];
  private _limit?: number;
  private _rangeFrom?: number;
  private _rangeTo?: number;
  private _single?: 'one' | 'maybe';
  private _values?: unknown;
  private _onConflict?: string;
  private _count?: string;
  private _head?: boolean;

  constructor(table: string) {
    this.table = table;
  }

  select(cols = '*', opts?: { count?: 'exact' | 'planned' | 'estimated'; head?: boolean }) {
    if (opts?.count) this._count = opts.count;
    if (opts?.head) this._head = true;
    if (this._op === 'select') {
      this._select = cols || '*';
    } else {
      // .insert(...).select() → return inserted rows
      this._returning = cols || '*';
    }
    return this;
  }

  insert(values: unknown) {
    this._op = 'insert';
    this._values = values;
    return this;
  }

  upsert(values: unknown, opts?: { onConflict?: string }) {
    this._op = 'upsert';
    this._values = values;
    this._onConflict = opts?.onConflict;
    return this;
  }

  update(values: unknown) {
    this._op = 'update';
    this._values = values;
    return this;
  }

  delete() {
    this._op = 'delete';
    return this;
  }

  eq(column: string, value: unknown) {
    this._filters.push({ op: 'eq', column, value });
    return this;
  }
  neq(column: string, value: unknown) {
    this._filters.push({ op: 'neq', column, value });
    return this;
  }
  gt(column: string, value: unknown) {
    this._filters.push({ op: 'gt', column, value });
    return this;
  }
  gte(column: string, value: unknown) {
    this._filters.push({ op: 'gte', column, value });
    return this;
  }
  lt(column: string, value: unknown) {
    this._filters.push({ op: 'lt', column, value });
    return this;
  }
  lte(column: string, value: unknown) {
    this._filters.push({ op: 'lte', column, value });
    return this;
  }
  like(column: string, value: unknown) {
    this._filters.push({ op: 'like', column, value });
    return this;
  }
  ilike(column: string, value: unknown) {
    this._filters.push({ op: 'ilike', column, value });
    return this;
  }
  in(column: string, value: unknown[]) {
    this._filters.push({ op: 'in', column, value });
    return this;
  }
  is(column: string, value: unknown) {
    this._filters.push({ op: 'is', column, value });
    return this;
  }
  match(criteria: Record<string, unknown>) {
    for (const [column, value] of Object.entries(criteria)) {
      this._filters.push({ op: 'eq', column, value });
    }
    return this;
  }

  order(column: string, opts?: { ascending?: boolean; nullsFirst?: boolean }) {
    this._order.push({
      column,
      ascending: opts?.ascending !== false,
      nullsFirst: opts?.nullsFirst,
    });
    return this;
  }

  limit(n: number) {
    this._limit = n;
    return this;
  }

  range(from: number, to: number) {
    this._rangeFrom = from;
    this._rangeTo = to;
    return this;
  }

  single() {
    this._single = 'one';
    if (this._op !== 'select' && this._returning === null) this._returning = '*';
    return this;
  }

  maybeSingle() {
    this._single = 'maybe';
    if (this._op !== 'select' && this._returning === null) this._returning = '*';
    return this;
  }

  private buildPayload() {
    return {
      table: this.table,
      op: this._op,
      select: this._select,
      returning: this._returning,
      filters: this._filters,
      order: this._order,
      limit: this._limit,
      rangeFrom: this._rangeFrom,
      rangeTo: this._rangeTo,
      single: this._single,
      values: this._values,
      onConflict: this._onConflict,
      count: this._count,
      head: this._head,
    };
  }

  async exec(): Promise<QueryResult<T>> {
    try {
      const json = await apiJson<QueryResult<T>>('/rest/v1/query', {
        method: 'POST',
        body: JSON.stringify(this.buildPayload()),
      });
      return json;
    } catch (err) {
      return { data: null as unknown as T, error: { message: (err as Error).message } };
    }
  }

  then<R1 = QueryResult<T>, R2 = never>(
    onfulfilled?: ((value: QueryResult<T>) => R1 | PromiseLike<R1>) | null,
    onrejected?: ((reason: unknown) => R2 | PromiseLike<R2>) | null,
  ): PromiseLike<R1 | R2> {
    return this.exec().then(onfulfilled, onrejected);
  }
}

// ---- auth ------------------------------------------------------------------
const auth = {
  async getSession() {
    return { data: { session: currentSession }, error: null };
  },

  async getUser() {
    return { data: { user: currentSession?.user ?? null }, error: null };
  },

  onAuthStateChange(callback: AuthCallback) {
    listeners.add(callback);
    // Fire an initial event asynchronously, mirroring supabase-js behavior.
    setTimeout(() => callback('INITIAL_SESSION', currentSession), 0);
    return {
      data: {
        subscription: {
          unsubscribe() {
            listeners.delete(callback);
          },
        },
      },
    };
  },

  async signInWithPassword({ email, password }: { email: string; password: string }) {
    const json = await apiJson<{ session: Session | null; error: { message: string } | null }>(
      '/auth/v1/token',
      { method: 'POST', body: JSON.stringify({ email, password }) },
      false,
    );
    if (json.session) setSession(json.session, 'SIGNED_IN');
    return { data: { session: json.session, user: json.session?.user ?? null }, error: json.error };
  },

  async signUp({
    email,
    password,
    options,
  }: {
    email: string;
    password: string;
    options?: { data?: Record<string, unknown>; emailRedirectTo?: string };
  }) {
    const json = await apiJson<{
      session: Session | null;
      needsConfirmation?: boolean;
      error: { message: string } | null;
    }>(
      '/auth/v1/signup',
      { method: 'POST', body: JSON.stringify({ email, password, data: options?.data }) },
      false,
    );
    if (json.session) setSession(json.session, 'SIGNED_IN');
    return {
      data: { session: json.session, user: json.session?.user ?? null },
      error: json.error,
    };
  },

  async signInWithOAuth({
    provider,
    options,
  }: {
    provider: 'google' | 'azure' | string;
    options?: { redirectTo?: string; scopes?: string };
  }) {
    // Redirect to the Cognito Hosted UI for the given identity provider.
    const domain = import.meta.env.VITE_COGNITO_DOMAIN as string;
    const clientId = import.meta.env.VITE_COGNITO_CLIENT_ID as string;
    if (!domain || !clientId) {
      return { data: null, error: { message: 'Cognito Hosted UI non configuré (VITE_COGNITO_DOMAIN / VITE_COGNITO_CLIENT_ID).' } };
    }
    const redirectTo = options?.redirectTo || window.location.origin;
    const idpMap: Record<string, string> = { google: 'Google', azure: 'Microsoft', microsoft: 'Microsoft' };
    const params = new URLSearchParams({
      client_id: clientId,
      response_type: 'code',
      scope: 'openid email profile',
      redirect_uri: redirectTo,
      identity_provider: idpMap[provider] || provider,
    });
    window.location.href = `${domain}/oauth2/authorize?${params}`;
    return { data: { provider, url: `${domain}/oauth2/authorize?${params}` }, error: null };
  },

  // Exchange a Hosted UI authorization code for a session (called on redirect).
  async exchangeCodeForSession(code: string, redirectUri: string) {
    const json = await apiJson<{ session: Session | null; error: { message: string } | null }>(
      '/auth/v1/oauth/token',
      { method: 'POST', body: JSON.stringify({ code, redirect_uri: redirectUri }) },
      false,
    );
    if (json.session) setSession(json.session, 'SIGNED_IN');
    return { data: { session: json.session }, error: json.error };
  },

  async resetPasswordForEmail(email: string, _options?: { redirectTo?: string }) {
    const json = await apiJson<{ error: { message: string } | null }>(
      '/auth/v1/recover',
      { method: 'POST', body: JSON.stringify({ email }) },
      false,
    );
    return { data: {}, error: json.error };
  },

  async signOut() {
    setSession(null, 'SIGNED_OUT');
    return { error: null };
  },
};

// ---- rpc -------------------------------------------------------------------
async function rpc<T = unknown>(fn: string, args?: Record<string, unknown>) {
  try {
    const json = await apiJson<QueryResult<T>>(`/rest/v1/rpc/${fn}`, {
      method: 'POST',
      body: JSON.stringify(args ?? {}),
    });
    return json;
  } catch (err) {
    return { data: null as unknown as T, error: { message: (err as Error).message } };
  }
}

// ---- functions.invoke ------------------------------------------------------
const functions = {
  async invoke<T = unknown>(name: string, opts?: { body?: unknown; headers?: Record<string, string> }) {
    try {
      const resp = await apiFetch(`/functions/v1/${name}`, {
        method: 'POST',
        headers: opts?.headers,
        body: JSON.stringify(opts?.body ?? {}),
      });
      const json = (await resp.json()) as T;
      if (!resp.ok) {
        return { data: null as unknown as T, error: { message: (json as { error?: string })?.error || 'Function error' } };
      }
      return { data: json, error: null };
    } catch (err) {
      return { data: null as unknown as T, error: { message: (err as Error).message } };
    }
  },
};

// ---- realtime (polling shim) ----------------------------------------------
// Supabase realtime is replaced by lightweight polling. We reproduce the subset
// used by the app: `.channel(name).on('postgres_changes', cfg, cb).subscribe()`
// for INSERT events, and `removeChannel(channel)`.
interface PgChangesConfig {
  event?: string;
  schema?: string;
  table?: string;
  filter?: string;
}

class RealtimeChannel {
  private table?: string;
  private filter?: PgChangesConfig['filter'];
  private event?: string;
  private callback?: (payload: { new: unknown; old: unknown; eventType: string }) => void;
  private timer?: ReturnType<typeof setInterval>;
  private seen = new Set<string>();
  private started = false;

  constructor(private name: string) {}

  on(type: string, config: PgChangesConfig, cb: (payload: { new: unknown; old: unknown; eventType: string }) => void) {
    if (type === 'postgres_changes') {
      this.table = config.table;
      this.filter = config.filter;
      this.event = config.event;
      this.callback = cb;
    }
    return this;
  }

  private parseFilter(): Filter | null {
    // Supported form: "column=eq.value"
    if (!this.filter) return null;
    const m = this.filter.match(/^(\w+)=eq\.(.*)$/);
    return m ? { op: 'eq', column: m[1], value: m[2] } : null;
  }

  subscribe() {
    if (!this.table || !this.callback || this.started) return this;
    this.started = true;
    const poll = async () => {
      try {
        const qb = new QueryBuilder(this.table!);
        const f = this.parseFilter();
        if (f) qb.eq(f.column, f.value as string);
        const { data } = await qb;
        const rows = Array.isArray(data) ? data : [];
        // Prime the seen-set on first poll so we only emit genuinely new rows.
        const firstRun = this.seen.size === 0 && !this.primed;
        for (const row of rows as Array<Record<string, unknown>>) {
          const id = String(row.id ?? JSON.stringify(row));
          if (!this.seen.has(id)) {
            this.seen.add(id);
            if (!firstRun && (this.event === 'INSERT' || this.event === '*' || !this.event)) {
              this.callback!({ new: row, old: {}, eventType: 'INSERT' });
            }
          }
        }
        this.primed = true;
      } catch {
        /* ignore poll errors */
      }
    };
    poll();
    this.timer = setInterval(poll, 4000);
    return this;
  }

  private primed = false;

  _teardown() {
    if (this.timer) clearInterval(this.timer);
    this.timer = undefined;
  }
}

export const apiClient = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  from<T = any>(table: string) {
    return new QueryBuilder<T>(table);
  },
  channel(name: string) {
    return new RealtimeChannel(name);
  },
  removeChannel(channel: RealtimeChannel) {
    channel._teardown();
    return Promise.resolve('ok');
  },
  auth,
  rpc,
  functions,
};

export type ApiClient = typeof apiClient;
