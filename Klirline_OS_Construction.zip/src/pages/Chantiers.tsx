import { useEffect, useState } from 'react';
import { HardHat, Search, MapPin, Calendar, DollarSign, User } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Project, Client, Employee, Task } from '../lib/types';
import Header from '../components/Header';
import { Modal, Badge, EmptyState, LoadingSpinner, FormField, inputCls, selectCls, textareaCls, SectionCard, useToast, Toast } from '../components/ui';

const statusOptions = [
  { value: 'planning', label: 'Planification', color: 'blue' as const },
  { value: 'active', label: 'Actif', color: 'green' as const },
  { value: 'paused', label: 'En pause', color: 'yellow' as const },
  { value: 'completed', label: 'Terminé', color: 'slate' as const },
  { value: 'cancelled', label: 'Annulé', color: 'red' as const },
];

export default function ChantiersPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [showDetail, setShowDetail] = useState<Project | null>(null);
  const [editing, setEditing] = useState<Project | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<Project>>({});
  const [tasks, setTasks] = useState<Task[]>([]);
  const [taskForm, setTaskForm] = useState('');
  const [addingTask, setAddingTask] = useState(false);
  const { toast, showToast } = useToast();

  const fetchProjects = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('projects')
      .select('*, clients(first_name,last_name,company_name), foreman:employees(first_name,last_name)')
      .order('created_at', { ascending: false });
    if (error) showToast('error', 'Impossible de charger les chantiers.');
    setProjects(data as Project[] ?? []);
    setLoading(false);
  };

  useEffect(() => {
    fetchProjects();
    supabase.from('clients').select('id,first_name,last_name,company_name').then(({ data }) => setClients(data as Client[] ?? []));
    supabase.from('employees').select('id,first_name,last_name,role').then(({ data }) => setEmployees(data as Employee[] ?? []));
  }, []);

  const fetchTasks = async (projectId: string) => {
    const { data } = await supabase.from('tasks').select('*, employees(first_name,last_name)').eq('project_id', projectId).order('created_at', { ascending: false });
    setTasks(data as Task[] ?? []);
  };

  const openDetail = (p: Project) => {
    setShowDetail(p);
    fetchTasks(p.id);
  };

  const openCreate = () => { setEditing(null); setForm({ status: 'planning' }); setShowModal(true); };
  const openEdit = (p: Project) => { setEditing(p); setForm({ ...p }); setShowModal(true); };

  const handleSave = async () => {
    setSaving(true);
    if (editing) {
      const { error } = await supabase.from('projects').update(form).eq('id', editing.id);
      if (error) { showToast('error', 'Erreur lors de la mise à jour.'); setSaving(false); return; }
    } else {
      const { error } = await supabase.from('projects').insert({ ...form, name: form.name ?? 'Nouveau chantier' });
      if (error) { showToast('error', 'Erreur lors de la création.'); setSaving(false); return; }
    }
    showToast('success', editing ? 'Chantier mis à jour.' : 'Chantier créé.');
    setSaving(false);
    setShowModal(false);
    fetchProjects();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer ce chantier ?')) return;
    const { error } = await supabase.from('projects').delete().eq('id', id);
    if (error) { showToast('error', 'Impossible de supprimer ce chantier.'); return; }
    showToast('success', 'Chantier supprimé.');
    fetchProjects();
  };

  const addTask = async () => {
    if (!taskForm.trim() || !showDetail) return;
    setAddingTask(true);
    const { error } = await supabase.from('tasks').insert({ project_id: showDetail.id, title: taskForm.trim() });
    if (error) showToast('error', 'Erreur lors de l\'ajout de la tâche.');
    setTaskForm('');
    fetchTasks(showDetail.id);
    setAddingTask(false);
  };

  const toggleTask = async (t: Task) => {
    const next = t.status === 'done' ? 'todo' : 'done';
    await supabase.from('tasks').update({ status: next }).eq('id', t.id);
    fetchTasks(showDetail!.id);
  };

  const filtered = projects.filter(p => {
    const q = search.toLowerCase();
    const client = p.clients as any;
    const matchSearch = [p.name, p.city, p.address, client?.company_name].some(v => v?.toLowerCase().includes(q));
    return matchSearch && (statusFilter === 'all' || p.status === statusFilter);
  });

  const fmt = (n: number) => new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD', maximumFractionDigits: 0 }).format(n);

  const taskStatusColor: Record<string, string> = {
    todo: 'bg-slate-100 text-slate-500',
    in_progress: 'bg-blue-100 text-blue-700',
    review: 'bg-amber-100 text-amber-700',
    done: 'bg-emerald-100 text-emerald-700',
  };

  return (
    <div className="flex flex-col h-full">
      <Header title="Chantiers" subtitle={`${projects.length} projet${projects.length !== 1 ? 's' : ''}`} action={{ label: 'Nouveau chantier', onClick: openCreate }} />
      <div className="flex-1 p-6 overflow-auto">
        {/* Filters */}
        <div className="flex gap-3 mb-4 flex-wrap">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher..." className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white transition w-56" />
          </div>
          <div className="flex gap-2">
            {['all', ...statusOptions.map(s => s.value)].map(s => {
              const opt = statusOptions.find(o => o.value === s);
              return (
                <button key={s} onClick={() => setStatusFilter(s)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${statusFilter === s ? 'bg-slate-900 text-white' : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'}`}>
                  {opt?.label ?? 'Tous'}
                </button>
              );
            })}
          </div>
        </div>

        {loading ? <LoadingSpinner /> : filtered.length === 0 ? (
          <EmptyState icon={<HardHat size={28} />} title="Aucun chantier" description="Créez votre premier chantier." action={{ label: 'Nouveau chantier', onClick: openCreate }} />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filtered.map((p) => {
              const client = p.clients as any;
              const foreman = p.foreman as any;
              const s = statusOptions.find(o => o.value === p.status);
              const progress = p.budget && p.budget > 0 ? Math.min(100, Math.round((p.spent / p.budget) * 100)) : 0;
              return (
                <div key={p.id} className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow overflow-hidden">
                  <div className="px-5 py-4 border-b border-slate-50">
                    <div className="flex items-start justify-between mb-1">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-slate-900 text-sm leading-tight truncate">{p.name}</h3>
                        {client && <p className="text-xs text-slate-400 mt-0.5">{client.company_name ?? `${client.first_name} ${client.last_name}`}</p>}
                      </div>
                      {s && <Badge label={s.label} color={s.color} />}
                    </div>
                  </div>
                  <div className="px-5 py-3 space-y-2">
                    {(p.address || p.city) && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <MapPin size={12} /> {[p.address, p.city].filter(Boolean).join(', ')}
                      </div>
                    )}
                    {(p.start_date || p.end_date) && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <Calendar size={12} /> {p.start_date ?? '?'} → {p.end_date ?? '?'}
                      </div>
                    )}
                    {foreman && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <User size={12} /> Chef : {foreman.first_name} {foreman.last_name}
                      </div>
                    )}
                    {p.budget && (
                      <div>
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-slate-400">Budget</span>
                          <span className="font-semibold text-slate-700">{fmt(p.spent)} / {fmt(p.budget)}</span>
                        </div>
                        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${progress > 90 ? 'bg-red-500' : progress > 70 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="px-5 py-3 border-t border-slate-50 flex justify-end gap-2">
                    <button onClick={() => openDetail(p)} className="text-xs font-medium text-blue-600 hover:text-blue-700 transition">Détails</button>
                    <button onClick={() => openEdit(p)} className="text-xs font-medium text-orange-600 hover:text-orange-700 transition">Modifier</button>
                    <button onClick={() => handleDelete(p.id)} className="text-xs font-medium text-red-400 hover:text-red-600 transition">Suppr.</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showModal && (
        <Modal title={editing ? 'Modifier le chantier' : 'Nouveau chantier'} onClose={() => setShowModal(false)} size="lg">
          <div className="grid grid-cols-2 gap-4">
            <FormField label="Nom du chantier" required>
              <input className={inputCls} value={form.name ?? ''} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Rénovation Maison Tremblay" />
            </FormField>
            <FormField label="Client">
              <select className={selectCls} value={form.client_id ?? ''} onChange={e => setForm(f => ({ ...f, client_id: e.target.value || undefined }))}>
                <option value="">— Aucun client —</option>
                {clients.map(c => <option key={c.id} value={c.id}>{c.company_name ?? `${c.first_name} ${c.last_name}`}</option>)}
              </select>
            </FormField>
            <FormField label="Chef de chantier">
              <select className={selectCls} value={form.foreman_id ?? ''} onChange={e => setForm(f => ({ ...f, foreman_id: e.target.value || undefined }))}>
                <option value="">— Aucun chef —</option>
                {employees.map(e => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}
              </select>
            </FormField>
            <FormField label="Statut">
              <select className={selectCls} value={form.status ?? 'planning'} onChange={e => setForm(f => ({ ...f, status: e.target.value as any }))}>
                {statusOptions.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </FormField>
            <FormField label="Adresse">
              <input className={inputCls} value={form.address ?? ''} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} />
            </FormField>
            <FormField label="Ville">
              <input className={inputCls} value={form.city ?? ''} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
            </FormField>
            <FormField label="Date début">
              <input className={inputCls} type="date" value={form.start_date ?? ''} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} />
            </FormField>
            <FormField label="Date fin prévue">
              <input className={inputCls} type="date" value={form.end_date ?? ''} onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))} />
            </FormField>
            <FormField label="Budget ($)">
              <input className={inputCls} type="number" value={form.budget ?? ''} onChange={e => setForm(f => ({ ...f, budget: parseFloat(e.target.value) || undefined }))} />
            </FormField>
            <FormField label="Description">
              <textarea className={textareaCls} rows={3} value={form.description ?? ''} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
            </FormField>
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-slate-100">
            <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
            <button onClick={handleSave} disabled={saving || !form.name} className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50">
              {saving ? 'Enregistrement...' : 'Enregistrer'}
            </button>
          </div>
        </Modal>
      )}

      {/* Detail Modal */}
      {showDetail && (
        <Modal title={showDetail.name} onClose={() => setShowDetail(null)} size="xl">
          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-4 text-sm">
              {(() => {
                const c = showDetail.clients as any;
                return c ? <div><span className="font-medium text-slate-500">Client : </span>{c.company_name ?? `${c.first_name} ${c.last_name}`}</div> : null;
              })()}
              {(() => {
                const f = showDetail.foreman as any;
                return f ? <div><span className="font-medium text-slate-500">Chef : </span>{f.first_name} {f.last_name}</div> : null;
              })()}
              {showDetail.city && <div><span className="font-medium text-slate-500">Ville : </span>{showDetail.city}</div>}
              {showDetail.start_date && <div><span className="font-medium text-slate-500">Début : </span>{showDetail.start_date}</div>}
              {showDetail.end_date && <div><span className="font-medium text-slate-500">Fin prévue : </span>{showDetail.end_date}</div>}
              {showDetail.budget && <div><span className="font-medium text-slate-500">Budget : </span>{fmt(showDetail.budget)}</div>}
            </div>

            {showDetail.description && (
              <div className="bg-slate-50 rounded-xl p-4 text-sm text-slate-700">{showDetail.description}</div>
            )}

            {/* Tasks */}
            <div>
              <h4 className="font-semibold text-slate-800 mb-3">Tâches</h4>
              <div className="flex gap-2 mb-3">
                <input
                  className={inputCls + ' flex-1'}
                  value={taskForm}
                  onChange={e => setTaskForm(e.target.value)}
                  placeholder="Nouvelle tâche..."
                  onKeyDown={e => e.key === 'Enter' && addTask()}
                />
                <button onClick={addTask} disabled={addingTask || !taskForm.trim()} className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold rounded-lg transition disabled:opacity-50">
                  Ajouter
                </button>
              </div>
              {tasks.length === 0 ? (
                <p className="text-sm text-slate-400 text-center py-4">Aucune tâche</p>
              ) : (
                <div className="space-y-2">
                  {tasks.map(t => (
                    <div key={t.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl hover:bg-slate-100 transition">
                      <button
                        onClick={() => toggleTask(t)}
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition flex-shrink-0 ${t.status === 'done' ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-300 hover:border-emerald-400'}`}
                      >
                        {t.status === 'done' && <svg width="10" height="8" viewBox="0 0 10 8" fill="none"><path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>}
                      </button>
                      <span className={`flex-1 text-sm ${t.status === 'done' ? 'line-through text-slate-400' : 'text-slate-700'}`}>{t.title}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${taskStatusColor[t.status]}`}>
                        {t.status === 'todo' ? 'À faire' : t.status === 'done' ? 'Fait' : t.status === 'in_progress' ? 'En cours' : 'Révision'}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </Modal>
      )}
      <Toast toast={toast} />
    </div>
  );
}
