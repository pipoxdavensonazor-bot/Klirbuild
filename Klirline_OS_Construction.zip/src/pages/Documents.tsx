import { useEffect, useState } from 'react';
import { FolderOpen, Search, FileText, Image, File, Download, Upload } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Document, Project, Client } from '../lib/types';
import Header from '../components/Header';
import { Modal, Badge, EmptyState, LoadingSpinner, FormField, inputCls, selectCls, textareaCls } from '../components/ui';

const typeOptions = [
  { value: 'plan', label: 'Plan', icon: '📐' },
  { value: 'contract', label: 'Contrat', icon: '📜' },
  { value: 'invoice', label: 'Facture', icon: '🧾' },
  { value: 'photo', label: 'Photo', icon: '📷' },
  { value: 'report', label: 'Rapport', icon: '📊' },
  { value: 'permit', label: 'Permis', icon: '🏛️' },
  { value: 'other', label: 'Autre', icon: '📎' },
];

const typeColor: Record<string, 'blue' | 'orange' | 'green' | 'purple' | 'slate'> = {
  plan: 'blue', contract: 'purple', invoice: 'orange', photo: 'green', report: 'blue', permit: 'orange', other: 'slate',
};

export default function DocumentsPage() {
  const [docs, setDocs] = useState<Document[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<Document>>({});

  const fetchDocs = async () => {
    setLoading(true);
    const { data } = await supabase.from('documents').select('*, projects(name), clients(first_name,last_name,company_name)').order('created_at', { ascending: false });
    setDocs(data as Document[] ?? []);
    setLoading(false);
  };

  useEffect(() => {
    fetchDocs();
    supabase.from('projects').select('id,name').then(({ data }) => setProjects(data as Project[] ?? []));
    supabase.from('clients').select('id,first_name,last_name,company_name').then(({ data }) => setClients(data as Client[] ?? []));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await supabase.from('documents').insert({ ...form, name: form.name ?? 'Document' });
    setSaving(false);
    setShowModal(false);
    setForm({});
    fetchDocs();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer ce document ?')) return;
    await supabase.from('documents').delete().eq('id', id);
    fetchDocs();
  };

  const filtered = docs.filter(d => {
    const q = search.toLowerCase();
    const matchSearch = d.name.toLowerCase().includes(q);
    return matchSearch && (typeFilter === 'all' || d.type === typeFilter);
  });

  const fmtSize = (bytes?: number | null) => {
    if (!bytes) return '—';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  return (
    <div className="flex flex-col h-full">
      <Header title="Documents" subtitle={`${docs.length} document${docs.length !== 1 ? 's' : ''}`} action={{ label: 'Ajouter document', onClick: () => { setForm({ type: 'other' }); setShowModal(true); } }} />
      <div className="flex-1 p-6 overflow-auto">
        <div className="flex gap-3 mb-4 flex-wrap">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher..." className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white transition w-56" />
          </div>
          <div className="flex gap-2 flex-wrap">
            <button onClick={() => setTypeFilter('all')} className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${typeFilter === 'all' ? 'bg-slate-900 text-white' : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'}`}>Tous</button>
            {typeOptions.map(t => (
              <button key={t.value} onClick={() => setTypeFilter(t.value)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${typeFilter === t.value ? 'bg-slate-900 text-white' : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'}`}>
                {t.icon} {t.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? <LoadingSpinner /> : filtered.length === 0 ? (
          <EmptyState icon={<FolderOpen size={28} />} title="Aucun document" description="Ajoutez votre premier document." action={{ label: 'Ajouter document', onClick: () => setShowModal(true) }} />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filtered.map(d => {
              const proj = d.projects as any;
              const client = d.clients as any;
              const typeOpt = typeOptions.find(t => t.value === d.type);
              return (
                <div key={d.id} className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center text-2xl flex-shrink-0">
                      {typeOpt?.icon ?? '📎'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-slate-900 text-sm truncate">{d.name}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge label={typeOpt?.label ?? d.type} color={typeColor[d.type] ?? 'slate'} />
                        {fmtSize(d.file_size) !== '—' && <span className="text-xs text-slate-400">{fmtSize(d.file_size)}</span>}
                      </div>
                      {proj && <div className="text-xs text-slate-400 mt-1 truncate">Chantier : {proj.name}</div>}
                      {client && <div className="text-xs text-slate-400 truncate">Client : {client.company_name ?? `${client.first_name} ${client.last_name}`}</div>}
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3 pt-3 border-t border-slate-50">
                    {d.file_url && (
                      <a href={d.file_url} target="_blank" rel="noreferrer" className="flex-1 text-center text-xs font-medium text-blue-600 hover:text-blue-700 transition flex items-center justify-center gap-1">
                        <Download size={12} />Télécharger
                      </a>
                    )}
                    <button onClick={() => handleDelete(d.id)} className="flex-1 text-center text-xs font-medium text-red-400 hover:text-red-600 transition">Supprimer</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {showModal && (
        <Modal title="Ajouter un document" onClose={() => setShowModal(false)} size="md">
          <div className="space-y-4">
            <FormField label="Nom du document" required>
              <input className={inputCls} value={form.name ?? ''} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Plan de fondation v2.pdf" />
            </FormField>
            <FormField label="Type">
              <select className={selectCls} value={form.type ?? 'other'} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
                {typeOptions.map(t => <option key={t.value} value={t.value}>{t.icon} {t.label}</option>)}
              </select>
            </FormField>
            <FormField label="URL du fichier" hint="Lien vers le fichier (Google Drive, Dropbox, etc.)">
              <input className={inputCls} type="url" value={form.file_url ?? ''} onChange={e => setForm(f => ({ ...f, file_url: e.target.value }))} placeholder="https://..." />
            </FormField>
            <FormField label="Chantier lié">
              <select className={selectCls} value={form.project_id ?? ''} onChange={e => setForm(f => ({ ...f, project_id: e.target.value || undefined }))}>
                <option value="">— Aucun chantier —</option>
                {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </FormField>
            <FormField label="Client lié">
              <select className={selectCls} value={form.client_id ?? ''} onChange={e => setForm(f => ({ ...f, client_id: e.target.value || undefined }))}>
                <option value="">— Aucun client —</option>
                {clients.map(c => <option key={c.id} value={c.id}>{c.company_name ?? `${c.first_name} ${c.last_name}`}</option>)}
              </select>
            </FormField>
            <FormField label="Notes">
              <textarea className={textareaCls} rows={2} value={form.notes ?? ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </FormField>
          </div>
          <div className="flex justify-end gap-3 mt-5 pt-4 border-t border-slate-100">
            <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
            <button onClick={handleSave} disabled={saving || !form.name} className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50">
              {saving ? 'Enregistrement...' : 'Ajouter'}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
