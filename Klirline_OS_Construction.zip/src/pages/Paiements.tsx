import { useEffect, useState } from 'react';
import { CreditCard, Search, DollarSign } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Payment, Invoice } from '../lib/types';
import Header from '../components/Header';
import { Modal, Badge, EmptyState, LoadingSpinner, FormField, inputCls, selectCls } from '../components/ui';

export default function PaiementsPage() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<Payment & { invoice_id: string }>>({});

  const fetchPayments = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('payments')
      .select('*, invoices(invoice_no, total, status, clients(first_name,last_name,company_name))')
      .order('paid_at', { ascending: false });
    setPayments(data as Payment[] ?? []);
    setLoading(false);
  };

  useEffect(() => {
    fetchPayments();
    supabase.from('invoices').select('id,invoice_no,total,status,clients(first_name,last_name,company_name)').in('status', ['sent', 'overdue']).then(({ data }) => setInvoices(data as Invoice[] ?? []));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await supabase.from('payments').insert({
      invoice_id: form.invoice_id,
      amount: form.amount,
      method: form.method ?? 'transfer',
      paid_at: form.paid_at ?? new Date().toISOString(),
      reference: form.reference,
    });
    const inv = invoices.find(i => i.id === form.invoice_id);
    if (inv) await supabase.from('invoices').update({ status: 'paid' }).eq('id', inv.id);
    setSaving(false);
    setShowModal(false);
    setForm({});
    fetchPayments();
  };

  const fmt = (n: number) => new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD' }).format(n);
  const totalReceived = payments.reduce((s, p) => s + p.amount, 0);

  const methodLabel: Record<string, string> = {
    transfer: 'Virement', cash: 'Comptant', cheque: 'Chèque', card: 'Carte', e_transfer: 'Virement Interac',
  };

  return (
    <div className="flex flex-col h-full">
      <Header title="Paiements" subtitle={`Total reçu : ${fmt(totalReceived)}`} action={{ label: 'Enregistrer paiement', onClick: () => { setForm({ paid_at: new Date().toISOString().split('T')[0], method: 'transfer' }); setShowModal(true); } }} />
      <div className="flex-1 p-6 overflow-auto">
        {loading ? <LoadingSpinner /> : payments.length === 0 ? (
          <EmptyState icon={<CreditCard size={28} />} title="Aucun paiement" description="Enregistrez votre premier paiement reçu." action={{ label: 'Enregistrer paiement', onClick: () => setShowModal(true) }} />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Date</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Facture</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden md:table-cell">Client</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Méthode</th>
                  <th className="text-right px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Montant</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden lg:table-cell">Référence</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {payments.map(p => {
                  const inv = p.invoices as any;
                  const c = inv?.clients;
                  return (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition">
                      <td className="px-5 py-3.5 text-slate-600">{new Date(p.paid_at).toLocaleDateString('fr-CA')}</td>
                      <td className="px-5 py-3.5 font-mono font-medium text-slate-700">{inv?.invoice_no ?? '—'}</td>
                      <td className="px-5 py-3.5 hidden md:table-cell text-slate-600">{c ? (c.company_name ?? `${c.first_name} ${c.last_name}`) : '—'}</td>
                      <td className="px-5 py-3.5"><Badge label={methodLabel[p.method] ?? p.method} color="blue" /></td>
                      <td className="px-5 py-3.5 text-right font-bold text-emerald-700">{fmt(p.amount)}</td>
                      <td className="px-5 py-3.5 hidden lg:table-cell text-slate-400 font-mono text-xs">{p.reference ?? '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showModal && (
        <Modal title="Enregistrer un paiement" onClose={() => setShowModal(false)} size="sm">
          <div className="space-y-4">
            <FormField label="Facture" required>
              <select className={selectCls} value={form.invoice_id ?? ''} onChange={e => {
                const inv = invoices.find(i => i.id === e.target.value);
                setForm(f => ({ ...f, invoice_id: e.target.value, amount: inv?.total }));
              }}>
                <option value="">— Sélectionner —</option>
                {invoices.map(inv => {
                  const c = inv.clients as any;
                  return <option key={inv.id} value={inv.id}>{inv.invoice_no} – {c?.company_name ?? `${c?.first_name} ${c?.last_name}`}</option>;
                })}
              </select>
            </FormField>
            <FormField label="Montant ($)" required>
              <input className={inputCls} type="number" value={form.amount ?? ''} onChange={e => setForm(f => ({ ...f, amount: parseFloat(e.target.value) || 0 }))} />
            </FormField>
            <FormField label="Méthode">
              <select className={selectCls} value={form.method ?? 'transfer'} onChange={e => setForm(f => ({ ...f, method: e.target.value }))}>
                <option value="transfer">Virement bancaire</option>
                <option value="e_transfer">Virement Interac</option>
                <option value="cheque">Chèque</option>
                <option value="cash">Comptant</option>
                <option value="card">Carte</option>
              </select>
            </FormField>
            <FormField label="Date">
              <input className={inputCls} type="date" value={typeof form.paid_at === 'string' ? form.paid_at.split('T')[0] : ''} onChange={e => setForm(f => ({ ...f, paid_at: e.target.value }))} />
            </FormField>
            <FormField label="Référence">
              <input className={inputCls} value={form.reference ?? ''} onChange={e => setForm(f => ({ ...f, reference: e.target.value }))} placeholder="N° confirmation..." />
            </FormField>
            <div className="flex justify-end gap-3 pt-2 border-t border-slate-100">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
              <button onClick={handleSave} disabled={saving || !form.invoice_id || !form.amount} className="px-5 py-2 text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition disabled:opacity-50">
                {saving ? 'Enregistrement...' : 'Confirmer'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
