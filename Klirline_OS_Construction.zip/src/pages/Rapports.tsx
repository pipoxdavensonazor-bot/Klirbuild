import { useEffect, useState, useRef } from 'react';
import { BarChart3, TrendingUp, Clock, DollarSign, HardHat, Users, Printer, Share2, Download } from 'lucide-react';
import { supabase } from '../lib/supabase';
import Header from '../components/Header';
import { StatCard, SectionCard, useToast, Toast } from '../components/ui';

type MonthStat = { month: string; revenue: number; projects: number; clients: number };

export default function RapportsPage() {
  const [stats, setStats] = useState({ clients: 0, projects: 0, employees: 0, revenue: 0, hours: 0, invoices: 0 });
  const [clientsData, setClientsData] = useState<any[]>([]);
  const [projectsData, setProjectsData] = useState<any[]>([]);
  const [presencesData, setPresencesData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const printRef = useRef<HTMLDivElement>(null);
  const { toast, showToast } = useToast();

  useEffect(() => {
    async function load() {
      setLoading(true);
      const [
        { count: clients },
        { count: projects },
        { count: employees },
        { data: invoiceData },
        { data: entries },
        { data: allClients },
        { data: allProjects },
        { data: allEntries },
      ] = await Promise.all([
        supabase.from('clients').select('*', { count: 'exact', head: true }),
        supabase.from('projects').select('*', { count: 'exact', head: true }),
        supabase.from('employees').select('*', { count: 'exact', head: true }),
        supabase.from('invoices').select('total, status'),
        supabase.from('time_entries').select('clock_in, clock_out').eq('status', 'completed'),
        supabase.from('clients').select('first_name, last_name, company_name, email, phone, city, type, status').order('created_at', { ascending: false }),
        supabase.from('projects').select('name, address, city, status, budget, spent, start_date, end_date').order('created_at', { ascending: false }),
        supabase.from('time_entries').select('clock_in, clock_out, status, employees(first_name, last_name), projects(name)').eq('status', 'completed').order('clock_in', { ascending: false }),
      ]);
      const revenue = invoiceData?.filter(i => i.status === 'paid').reduce((s: number, i: any) => s + i.total, 0) ?? 0;
      const hours = entries?.reduce((s, e) => {
        if (!e.clock_out) return s;
        return s + (new Date(e.clock_out).getTime() - new Date(e.clock_in).getTime()) / 3600000;
      }, 0) ?? 0;
      setStats({ clients: clients ?? 0, projects: projects ?? 0, employees: employees ?? 0, revenue, hours: Math.round(hours), invoices: invoiceData?.length ?? 0 });
      setClientsData(allClients ?? []);
      setProjectsData(allProjects ?? []);
      setPresencesData(allEntries ?? []);
      setLoading(false);
    }
    load();
  }, []);

  const fmt = (n: number) => new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD', maximumFractionDigits: 0 }).format(n);

  const mockMonthly: MonthStat[] = [
    { month: 'Jan', clients: 2, projects: 1, revenue: 32000 },
    { month: 'Fév', clients: 3, projects: 2, revenue: 45000 },
    { month: 'Mar', clients: 1, projects: 1, revenue: 28000 },
    { month: 'Avr', clients: 4, projects: 3, revenue: 61000 },
    { month: 'Mai', clients: 2, projects: 2, revenue: 52000 },
    { month: 'Jun', clients: 5, projects: 3, revenue: 73000 },
  ];
  const maxRevenue = Math.max(...mockMonthly.map(m => m.revenue));

  const downloadCSV = (filename: string, headers: string[], rows: string[][]) => {
    const bom = '\uFEFF';
    const csv = bom + [headers.join(','), ...rows.map(r => r.map(v => `"${(v ?? '').toString().replace(/"/g, '""')}"`).join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportClients = () => {
    if (!clientsData.length) { showToast('error', 'Aucun client à exporter.'); return; }
    downloadCSV('clients.csv',
      ['Prénom', 'Nom', 'Entreprise', 'Courriel', 'Téléphone', 'Ville', 'Type', 'Statut'],
      clientsData.map(c => [c.first_name, c.last_name, c.company_name ?? '', c.email ?? '', c.phone ?? '', c.city ?? '', c.type ?? '', c.status ?? ''])
    );
    showToast('success', 'Clients exportés en CSV.');
  };

  const exportProjects = () => {
    if (!projectsData.length) { showToast('error', 'Aucun chantier à exporter.'); return; }
    downloadCSV('chantiers.csv',
      ['Nom', 'Adresse', 'Ville', 'Statut', 'Budget', 'Dépensé', 'Début', 'Fin'],
      projectsData.map(p => [p.name, p.address ?? '', p.city ?? '', p.status ?? '', p.budget ?? '', p.spent ?? '', p.start_date ?? '', p.end_date ?? ''])
    );
    showToast('success', 'Chantiers exportés en CSV.');
  };

  const exportPresences = () => {
    if (!presencesData.length) { showToast('error', 'Aucune présence à exporter.'); return; }
    downloadCSV('presences.csv',
      ['Employé', 'Chantier', 'Arrivée', 'Départ', 'Durée (h)'],
      presencesData.map(e => {
        const emp = e.employees as any;
        const proj = e.projects as any;
        const durH = e.clock_out
          ? ((new Date(e.clock_out).getTime() - new Date(e.clock_in).getTime()) / 3600000).toFixed(2)
          : '';
        return [
          `${emp?.first_name ?? ''} ${emp?.last_name ?? ''}`.trim(),
          proj?.name ?? '',
          new Date(e.clock_in).toLocaleString('fr-CA'),
          e.clock_out ? new Date(e.clock_out).toLocaleString('fr-CA') : '',
          durH,
        ];
      })
    );
    showToast('success', 'Présences exportées en CSV.');
  };

  const handlePrint = () => {
    window.print();
  };

  const handleShare = async () => {
    const text = `Rapport — ${new Date().toLocaleDateString('fr-CA')}\nClients: ${stats.clients} | Chantiers: ${stats.projects} | Employés: ${stats.employees}\nRevenus encaissés: ${fmt(stats.revenue)} | Heures travaillées: ${stats.hours}h`;
    if (navigator.share) {
      try {
        await navigator.share({ title: 'Rapport GestionPro', text });
        showToast('success', 'Rapport partagé.');
      } catch {
        // user cancelled
      }
    } else {
      await navigator.clipboard.writeText(text);
      showToast('success', 'Résumé copié dans le presse-papiers.');
    }
  };

  return (
    <div className="flex flex-col h-full">
      <Header
        title="Rapports"
        subtitle="Analyse et indicateurs de performance"
        action={{ label: 'Imprimer / PDF', onClick: handlePrint }}
      />
      <div ref={printRef} className="flex-1 p-6 overflow-auto space-y-6">
        {/* Print header — visible only when printing */}
        <div className="hidden print:block mb-6">
          <h1 className="text-2xl font-bold text-slate-900">Rapport GestionPro</h1>
          <p className="text-sm text-slate-500">Généré le {new Date().toLocaleDateString('fr-CA', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>

        {/* Action bar */}
        <div className="flex gap-2 flex-wrap no-print">
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold rounded-xl transition"
          >
            <Printer size={15} />
            Imprimer / PDF
          </button>
          <button
            onClick={handleShare}
            className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-sm font-semibold rounded-xl transition"
          >
            <Share2 size={15} />
            Partager
          </button>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          <StatCard label="Total clients" value={stats.clients} sub="dans le CRM" icon={<Users size={22} className="text-blue-600" />} color="bg-blue-50" />
          <StatCard label="Chantiers créés" value={stats.projects} sub="tous statuts" icon={<HardHat size={22} className="text-orange-600" />} color="bg-orange-50" />
          <StatCard label="Employés actifs" value={stats.employees} sub="dans le système" icon={<Users size={22} className="text-violet-600" />} color="bg-violet-50" />
          <StatCard label="Revenus encaissés" value={fmt(stats.revenue)} sub="factures payées" icon={<DollarSign size={22} className="text-emerald-600" />} color="bg-emerald-50" />
          <StatCard label="Heures travaillées" value={`${stats.hours}h`} sub="total pointages" icon={<Clock size={22} className="text-amber-600" />} color="bg-amber-50" />
          <StatCard label="Factures émises" value={stats.invoices} sub="total" icon={<BarChart3 size={22} className="text-slate-600" />} color="bg-slate-100" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Revenue chart */}
          <SectionCard title="Revenus mensuels (données exemple)">
            <div className="px-5 py-4">
              <div className="flex items-end gap-4 h-36 mb-3">
                {mockMonthly.map(m => (
                  <div key={m.month} className="flex-1 flex flex-col items-center gap-1">
                    <div
                      className="w-full bg-orange-500 hover:bg-orange-600 rounded-t-lg transition cursor-pointer"
                      style={{ height: `${(m.revenue / maxRevenue) * 120}px` }}
                      title={fmt(m.revenue)}
                    />
                    <span className="text-xs text-slate-400">{m.month}</span>
                  </div>
                ))}
              </div>
              <div className="text-xs text-slate-400 text-center">Survolez les barres pour voir les montants</div>
            </div>
          </SectionCard>

          {/* Period performance */}
          <SectionCard title="Performance par période">
            <div className="px-5 py-4 space-y-3">
              {[
                { period: 'Ce mois', clients: 2, projects: 1, revenue: fmt(45000), trend: '+12%' },
                { period: 'Ce trimestre', clients: 8, projects: 5, revenue: fmt(138000), trend: '+8%' },
                { period: 'Cette année', clients: 19, projects: 12, revenue: fmt(291000), trend: '+23%' },
              ].map(row => (
                <div key={row.period} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                  <div>
                    <div className="font-semibold text-slate-800 text-sm">{row.period}</div>
                    <div className="text-xs text-slate-400">{row.clients} clients · {row.projects} chantiers</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-slate-900 text-sm">{row.revenue}</div>
                    <div className="text-xs text-emerald-600 font-semibold">{row.trend}</div>
                  </div>
                </div>
              ))}
            </div>
          </SectionCard>
        </div>

        {/* Export section */}
        <SectionCard title="Exporter les données">
          <div className="px-5 py-4 grid grid-cols-2 md:grid-cols-3 gap-3 no-print">
            <button
              onClick={exportClients}
              disabled={loading}
              className="p-4 bg-slate-50 hover:bg-blue-50 border border-slate-100 hover:border-blue-200 rounded-xl text-left transition group disabled:opacity-50"
            >
              <div className="flex items-center justify-between mb-2">
                <Users size={18} className="text-blue-500" />
                <Download size={14} className="text-slate-300 group-hover:text-blue-400 transition" />
              </div>
              <div className="text-sm font-semibold text-slate-800">Clients (CSV)</div>
              <div className="text-xs text-slate-400">{clientsData.length} enregistrement{clientsData.length !== 1 ? 's' : ''}</div>
            </button>

            <button
              onClick={exportProjects}
              disabled={loading}
              className="p-4 bg-slate-50 hover:bg-orange-50 border border-slate-100 hover:border-orange-200 rounded-xl text-left transition group disabled:opacity-50"
            >
              <div className="flex items-center justify-between mb-2">
                <HardHat size={18} className="text-orange-500" />
                <Download size={14} className="text-slate-300 group-hover:text-orange-400 transition" />
              </div>
              <div className="text-sm font-semibold text-slate-800">Chantiers (CSV)</div>
              <div className="text-xs text-slate-400">{projectsData.length} enregistrement{projectsData.length !== 1 ? 's' : ''}</div>
            </button>

            <button
              onClick={exportPresences}
              disabled={loading}
              className="p-4 bg-slate-50 hover:bg-amber-50 border border-slate-100 hover:border-amber-200 rounded-xl text-left transition group disabled:opacity-50"
            >
              <div className="flex items-center justify-between mb-2">
                <Clock size={18} className="text-amber-500" />
                <Download size={14} className="text-slate-300 group-hover:text-amber-400 transition" />
              </div>
              <div className="text-sm font-semibold text-slate-800">Présences (CSV)</div>
              <div className="text-xs text-slate-400">{presencesData.length} pointage{presencesData.length !== 1 ? 's' : ''} complétés</div>
            </button>
          </div>
          <p className="px-5 pb-4 text-xs text-slate-400 no-print">Les fichiers CSV s'ouvrent dans Excel, Google Sheets ou tout autre tableur.</p>
        </SectionCard>

        {/* Print summary table */}
        <div className="hidden print:block">
          <h2 className="text-lg font-bold text-slate-800 mb-3">Résumé des indicateurs</h2>
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="border-b-2 border-slate-300">
                <th className="text-left py-2 font-semibold">Indicateur</th>
                <th className="text-right py-2 font-semibold">Valeur</th>
              </tr>
            </thead>
            <tbody>
              {[
                ['Total clients', stats.clients],
                ['Chantiers créés', stats.projects],
                ['Employés actifs', stats.employees],
                ['Revenus encaissés', fmt(stats.revenue)],
                ['Heures travaillées', `${stats.hours}h`],
                ['Factures émises', stats.invoices],
              ].map(([label, value]) => (
                <tr key={label as string} className="border-b border-slate-100">
                  <td className="py-2 text-slate-600">{label}</td>
                  <td className="py-2 text-right font-semibold text-slate-900">{value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <Toast toast={toast} />
    </div>
  );
}
