import { useEffect, useState } from 'react';
import { Users, Search, Phone, Mail, MapPin, Building } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Client } from '../lib/types';
import Header from '../components/Header';
import { Modal, Badge, EmptyState, LoadingSpinner, FormField, inputCls, selectCls, textareaCls, useToast, Toast } from '../components/ui';

const statusLabel: Record<string, string> = { active: 'Actif', inactive: 'Inactif' };
const typeLabel: Record<string, string> = { residential: 'Résidentiel', commercial: 'Commercial', industrial: 'Industriel' };
const typeColor: Record<string, 'blue' | 'orange' | 'purple'> = { residential: 'blue', commercial: 'orange', industrial: 'purple' };

export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Client | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<Client>>({});
  const [view, setView] = useState<Client | null>(null);
  const { toast, showToast } = useToast();

  const loadClients = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('clients').select('*').order('created_at', { ascending: false });
    if (error) showToast('error', 'Impossible de charger les clients.');
    setClients(data as Client[] ?? []);
    setLoading(false);
  };

  useEffect(() => { loadClients(); }, []);

  const openCreate = () => { setEditing(null); setForm({ type: 'residential', status: 'active' }); setShowModal(true); };
  const openEdit = (c: Client) => { setEditing(c); setForm({ ...c }); setShowModal(true); };

  const handleSave = async () => {
    setSaving(true);
    if (editing) {
      const { error } = await supabase.from('clients').update(form).eq('id', editing.id);
      if (error) { showToast('error', 'Erreur lors de la mise à jour.'); setSaving(false); return; }
    } else {
      const { error } = await supabase.from('clients').insert({ ...form, first_name: form.first_name ?? '', last_name: form.last_name ?? '' });
      if (error) { showToast('error', 'Erreur lors de la création.'); setSaving(false); return; }
    }
    showToast('success', editing ? 'Client mis à jour.' : 'Client créé.');
    setSaving(false);
    setShowModal(false);
    loadClients();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer ce client ?')) return;
    const { error } = await supabase.from('clients').delete().eq('id', id);
    if (error) { showToast('error', 'Impossible de supprimer ce client.'); return; }
    showToast('success', 'Client supprimé.');
    loadClients();
  };

  const filtered = clients.filter((c) => {
    const q = search.toLowerCase();
    return [c.first_name, c.last_name, c.company_name, c.email, c.city].some(v => v?.toLowerCase().includes(q));
  });

  return (
    <div className="flex flex-col h-full">
      <Header title="Clients" subtitle={`${clients.length} client${clients.length !== 1 ? 's' : ''}`} action={{ label: 'Nouveau client', onClick: openCreate }} />
      <div className="flex-1 p-6 overflow-auto">
        <div className="mb-4 flex gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher un client..." className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white transition" />
          </div>
        </div>

        {loading ? <LoadingSpinner /> : filtered.length === 0 ? (
          <EmptyState icon={<Users size={28} />} title="Aucun client" description="Ajoutez votre premier client pour commencer." action={{ label: 'Nouveau client', onClick: openCreate }} />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Client</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden md:table-cell">Contact</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden lg:table-cell">Ville</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Type</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Statut</th>
                  <th className="px-5 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/80 transition">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-sm flex-shrink-0">
                          {c.first_name[0]}
                        </div>
                        <div>
                          <div className="font-medium text-slate-900">{c.first_name} {c.last_name}</div>
                          {c.company_name && <div className="text-xs text-slate-400 flex items-center gap-1"><Building size={10} />{c.company_name}</div>}
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 hidden md:table-cell">
                      <div className="space-y-0.5">
                        {c.email && <div className="flex items-center gap-1.5 text-slate-600"><Mail size={12} className="text-slate-400" />{c.email}</div>}
                        {c.phone && <div className="flex items-center gap-1.5 text-slate-600"><Phone size={12} className="text-slate-400" />{c.phone}</div>}
                      </div>
                    </td>
                    <td className="px-5 py-3.5 hidden lg:table-cell text-slate-600">
                      {c.city && <div className="flex items-center gap-1.5"><MapPin size={12} className="text-slate-400" />{c.city}</div>}
                    </td>
                    <td className="px-5 py-3.5">
                      <Badge label={typeLabel[c.type] ?? c.type} color={typeColor[c.type] ?? 'slate'} />
                    </td>
                    <td className="px-5 py-3.5">
                      <Badge label={statusLabel[c.status] ?? c.status} color={c.status === 'active' ? 'green' : 'slate'} />
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button onClick={() => setView(c)} className="text-slate-400 hover:text-blue-600 px-2 py-1 rounded transition text-xs font-medium">Voir</button>
                      <button onClick={() => openEdit(c)} className="text-slate-400 hover:text-orange-600 px-2 py-1 rounded transition text-xs font-medium">Modifier</button>
                      <button onClick={() => handleDelete(c.id)} className="text-slate-400 hover:text-red-600 px-2 py-1 rounded transition text-xs font-medium">Suppr.</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showModal && (
        <Modal title={editing ? 'Modifier le client' : 'Nouveau client'} onClose={() => setShowModal(false)} size="lg">
          <div className="grid grid-cols-2 gap-4">
            <FormField label="Prénom" required>
              <input className={inputCls} value={form.first_name ?? ''} onChange={e => setForm(f => ({ ...f, first_name: e.target.value }))} placeholder="Jean" />
            </FormField>
            <FormField label="Nom de famille" required>
              <input className={inputCls} value={form.last_name ?? ''} onChange={e => setForm(f => ({ ...f, last_name: e.target.value }))} placeholder="Tremblay" />
            </FormField>
            <FormField label="Entreprise">
              <input className={inputCls} value={form.company_name ?? ''} onChange={e => setForm(f => ({ ...f, company_name: e.target.value }))} placeholder="Construction ABC" />
            </FormField>
            <FormField label="Courriel">
              <input className={inputCls} type="email" value={form.email ?? ''} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="jean@example.com" />
            </FormField>
            <FormField label="Téléphone">
              <input className={inputCls} value={form.phone ?? ''} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="514 555-0000" />
            </FormField>
            <FormField label="Type">
              <select className={selectCls} value={form.type ?? 'residential'} onChange={e => setForm(f => ({ ...f, type: e.target.value as any }))}>
                <option value="residential">Résidentiel</option>
                <option value="commercial">Commercial</option>
                <option value="industrial">Industriel</option>
              </select>
            </FormField>
            <FormField label="Adresse">
              <input className={inputCls} value={form.address ?? ''} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} placeholder="123 rue Principale" />
            </FormField>
            <FormField label="Ville">
              <input className={inputCls} value={form.city ?? ''} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} placeholder="Montréal" />
            </FormField>
            <FormField label="Province">
              <input className={inputCls} value={form.province ?? ''} onChange={e => setForm(f => ({ ...f, province: e.target.value }))} placeholder="QC" />
            </FormField>
            <FormField label="Code postal">
              <input className={inputCls} value={form.postal_code ?? ''} onChange={e => setForm(f => ({ ...f, postal_code: e.target.value }))} placeholder="H1H 1H1" />
            </FormField>
            <FormField label="Statut">
              <select className={selectCls} value={form.status ?? 'active'} onChange={e => setForm(f => ({ ...f, status: e.target.value as any }))}>
                <option value="active">Actif</option>
                <option value="inactive">Inactif</option>
              </select>
            </FormField>
            <FormField label="Notes" hint="Informations supplémentaires">
              <textarea className={textareaCls} rows={3} value={form.notes ?? ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </FormField>
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-slate-100">
            <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
            <button onClick={handleSave} disabled={saving || !form.first_name || !form.last_name} className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed">
              {saving ? 'Enregistrement...' : 'Enregistrer'}
            </button>
          </div>
        </Modal>
      )}

      {/* View Modal */}
      {view && (
        <Modal title={`${view.first_name} ${view.last_name}`} onClose={() => setView(null)}>
          <div className="space-y-3 text-sm">
            {view.company_name && <div><span className="font-medium text-slate-600">Entreprise :</span> <span className="text-slate-800">{view.company_name}</span></div>}
            {view.email && <div><span className="font-medium text-slate-600">Courriel :</span> <a href={`mailto:${view.email}`} className="text-blue-600">{view.email}</a></div>}
            {view.phone && <div><span className="font-medium text-slate-600">Téléphone :</span> <span className="text-slate-800">{view.phone}</span></div>}
            {view.address && <div><span className="font-medium text-slate-600">Adresse :</span> <span className="text-slate-800">{[view.address, view.city, view.province, view.postal_code].filter(Boolean).join(', ')}</span></div>}
            <div><span className="font-medium text-slate-600">Type :</span> <span className="text-slate-800">{typeLabel[view.type]}</span></div>
            <div><span className="font-medium text-slate-600">Statut :</span> <span className="text-slate-800">{statusLabel[view.status]}</span></div>
            {view.notes && <div><span className="font-medium text-slate-600">Notes :</span> <p className="text-slate-800 mt-1 bg-slate-50 rounded-lg p-3">{view.notes}</p></div>}
            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
              <button onClick={() => { setView(null); openEdit(view); }} className="px-4 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition">Modifier</button>
            </div>
          </div>
        </Modal>
      )}
      <Toast toast={toast} />
    </div>
  );
}
