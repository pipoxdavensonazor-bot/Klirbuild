import { useEffect, useState } from 'react';
import { Shield, Search, UserCheck, UserX, Edit2, Plus, Copy, Check, Trash2, KeyRound, Link } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import type { Profile } from '../lib/auth';
import Header from '../components/Header';
import { Modal, Badge, EmptyState, LoadingSpinner, FormField, selectCls } from '../components/ui';

const roleOptions = [
  { value: 'admin', label: 'Administrateur', color: 'purple' as const },
  { value: 'manager', label: 'Gestionnaire', color: 'blue' as const },
  { value: 'accountant', label: 'Comptable', color: 'orange' as const },
  { value: 'employee', label: 'Employé', color: 'green' as const },
];

const accessMap: Record<string, string[]> = {
  admin: ['Tous les modules'],
  manager: ['Dashboard', 'CRM', 'Chantiers', 'Présences', 'Employés', 'RH', 'Facturation', 'Paiements', 'Documents', 'Chat', 'Email Hub', 'Klir AI', 'Rapports'],
  accountant: ['Dashboard', 'Clients', 'Facturation', 'Paiements', 'Comptabilité', 'Documents', 'Chat', 'Klir AI', 'Rapports'],
  employee: ['Dashboard', 'Présences', 'Calendrier', 'Documents', 'Chat', 'Klir AI'],
};

interface InviteCode {
  id: string;
  code: string;
  role: string;
  used_by: string | null;
  used_at: string | null;
  expires_at: string | null;
  created_at: string;
}

function generateCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const part = (n: number) => Array.from({ length: n }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `${part(4)}-${part(4)}`;
}

function InviteCodesPanel() {
  const { user } = useAuth();
  const [codes, setCodes] = useState<InviteCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [newRole, setNewRole] = useState('employee');
  const [creating, setCreating] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  const fetchCodes = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('invite_codes')
      .select('*')
      .order('created_at', { ascending: false });
    setCodes((data as InviteCode[]) ?? []);
    setLoading(false);
  };

  useEffect(() => { fetchCodes(); }, []);

  const createCode = async () => {
    if (!user) return;
    setCreating(true);
    const code = generateCode();
    await supabase.from('invite_codes').insert({
      code,
      role: newRole,
      created_by: user.id,
    });
    setCreating(false);
    fetchCodes();
  };

  const deleteCode = async (id: string) => {
    await supabase.from('invite_codes').delete().eq('id', id);
    fetchCodes();
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code).catch(() => {});
    setCopied(code);
    setTimeout(() => setCopied(null), 2000);
  };

  const copyLink = (code: string) => {
    const url = `${window.location.origin}/?invite=${code}`;
    navigator.clipboard.writeText(url).catch(() => {});
    setCopied(`link-${code}`);
    setTimeout(() => setCopied(null), 2000);
  };

  const roleOpt = (role: string) => roleOptions.find(r => r.value === role);

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
          <KeyRound size={16} className="text-orange-600" />
        </div>
        <div>
          <h3 className="text-sm font-bold text-slate-900">Codes d'accès</h3>
          <p className="text-xs text-slate-500">Générez des codes pour inviter vos employés. Copiez le lien <Link size={10} className="inline" /> et envoyez-le par courriel ou messagerie.</p>
        </div>
      </div>

      {/* Create new code */}
      <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl mb-4">
        <select
          value={newRole}
          onChange={e => setNewRole(e.target.value)}
          className="flex-1 text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white"
        >
          {roleOptions.filter(r => r.value !== 'admin').map(r => (
            <option key={r.value} value={r.value}>{r.label}</option>
          ))}
        </select>
        <button
          onClick={createCode}
          disabled={creating}
          className="flex items-center gap-1.5 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold rounded-lg transition disabled:opacity-50"
        >
          {creating ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Plus size={14} />}
          Générer
        </button>
      </div>

      {/* Code list */}
      {loading ? (
        <div className="flex justify-center py-4"><div className="w-6 h-6 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" /></div>
      ) : codes.length === 0 ? (
        <p className="text-xs text-slate-400 text-center py-4">Aucun code généré pour l'instant.</p>
      ) : (
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {codes.map(c => {
            const r = roleOpt(c.role);
            const isUsed = !!c.used_by;
            return (
              <div key={c.id} className={`flex items-center gap-3 px-3 py-2.5 rounded-xl border ${isUsed ? 'border-slate-100 bg-slate-50 opacity-60' : 'border-slate-200 bg-white'}`}>
                <code className={`flex-1 text-sm font-mono font-bold tracking-widest ${isUsed ? 'text-slate-400' : 'text-slate-800'}`}>{c.code}</code>
                {r && <Badge label={r.label} color={r.color} />}
                {isUsed ? (
                  <span className="text-xs text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">Utilisé</span>
                ) : (
                  <>
                    <button
                      onClick={() => copyCode(c.code)}
                      className="p-1.5 text-slate-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition"
                      title="Copier le code"
                    >
                      {copied === c.code ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                    </button>
                    <button
                      onClick={() => copyLink(c.code)}
                      className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                      title="Copier le lien d'inscription"
                    >
                      {copied === `link-${c.code}` ? <Check size={14} className="text-emerald-500" /> : <Link size={14} />}
                    </button>
                    <button
                      onClick={() => deleteCode(c.id)}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                      title="Supprimer"
                    >
                      <Trash2 size={14} />
                    </button>
                  </>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function UsersAdminPage() {
  const { profile: currentProfile } = useAuth();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<Profile | null>(null);
  const [editForm, setEditForm] = useState<{ role: string; is_active: boolean }>({ role: 'employee', is_active: true });
  const [saving, setSaving] = useState(false);

  const fetchProfiles = async () => {
    setLoading(true);
    const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    setProfiles(data as Profile[] ?? []);
    setLoading(false);
  };

  useEffect(() => { fetchProfiles(); }, []);

  const openEdit = (p: Profile) => {
    setEditing(p);
    setEditForm({ role: p.role, is_active: p.is_active });
  };

  const handleSave = async () => {
    if (!editing) return;
    setSaving(true);
    await supabase.from('profiles').update(editForm).eq('id', editing.id);
    setSaving(false);
    setEditing(null);
    fetchProfiles();
  };

  const toggleActive = async (p: Profile) => {
    await supabase.from('profiles').update({ is_active: !p.is_active }).eq('id', p.id);
    fetchProfiles();
  };

  const filtered = profiles.filter(p => {
    const q = search.toLowerCase();
    return [p.full_name, p.email, p.role].some(v => v?.toLowerCase().includes(q));
  });

  const initials = (p: Profile) =>
    p.full_name?.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) ?? p.email?.[0]?.toUpperCase() ?? '?';

  return (
    <div className="flex flex-col h-full">
      <Header title="Gestion des utilisateurs" subtitle={`${profiles.length} compte${profiles.length !== 1 ? 's' : ''} enregistré${profiles.length !== 1 ? 's' : ''}`} />
      <div className="flex-1 p-6 overflow-auto space-y-4">
        {/* Info banner */}
        <div className="flex items-start gap-3 bg-blue-50 border border-blue-200 rounded-2xl px-5 py-4 text-sm text-blue-800">
          <Shield size={18} className="flex-shrink-0 mt-0.5 text-blue-600" />
          <div>
            <p className="font-semibold mb-1">Gestion des accès</p>
            <p>Générez des codes d'accès pour inviter vos employés. Modifiez leur rôle et leur statut depuis le tableau ci-dessous.</p>
          </div>
        </div>

        {/* Two-column layout: invite codes + role legend */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <InviteCodesPanel />

          {/* Role access legend */}
          <div className="grid grid-cols-2 gap-3">
            {roleOptions.map(r => (
              <div key={r.value} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Badge label={r.label} color={r.color} />
                </div>
                <ul className="space-y-1">
                  {accessMap[r.value].map(mod => (
                    <li key={mod} className="text-xs text-slate-500 flex items-center gap-1.5">
                      <div className="w-1 h-1 rounded-full bg-slate-300" />{mod}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-sm">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher un utilisateur..." className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white transition" />
        </div>

        {loading ? <LoadingSpinner /> : filtered.length === 0 ? (
          <EmptyState icon={<Shield size={28} />} title="Aucun utilisateur" description="Les utilisateurs apparaissent ici après leur inscription." />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Utilisateur</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Rôle</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden lg:table-cell">Accès</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Statut</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden md:table-cell">Inscription</th>
                  <th className="px-5 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map(p => {
                  const roleOpt = roleOptions.find(r => r.value === p.role);
                  const isMe = p.id === currentProfile?.id;
                  return (
                    <tr key={p.id} className={`hover:bg-slate-50/80 transition ${!p.is_active ? 'opacity-50' : ''}`}>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                            {initials(p)}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                              {p.full_name ?? '—'}
                              {isMe && <span className="text-[10px] bg-orange-100 text-orange-700 px-1.5 py-0.5 rounded-full font-bold">Vous</span>}
                            </div>
                            <div className="text-xs text-slate-400">{p.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        {roleOpt && <Badge label={roleOpt.label} color={roleOpt.color} />}
                      </td>
                      <td className="px-5 py-3.5 hidden lg:table-cell">
                        <div className="text-xs text-slate-400 max-w-48 truncate">
                          {accessMap[p.role]?.slice(0, 3).join(', ')}{(accessMap[p.role]?.length ?? 0) > 3 ? '…' : ''}
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <Badge
                          label={p.is_active ? 'Actif' : 'Désactivé'}
                          color={p.is_active ? 'green' : 'red'}
                        />
                      </td>
                      <td className="px-5 py-3.5 hidden md:table-cell text-slate-500 text-xs">
                        {new Date(p.created_at).toLocaleDateString('fr-CA')}
                      </td>
                      <td className="px-5 py-3.5 text-right space-x-1">
                        <button onClick={() => openEdit(p)} className="p-1.5 text-slate-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition" title="Modifier le rôle">
                          <Edit2 size={14} />
                        </button>
                        {!isMe && (
                          <button onClick={() => toggleActive(p)} className={`p-1.5 rounded-lg transition ${p.is_active ? 'text-slate-400 hover:text-red-600 hover:bg-red-50' : 'text-slate-400 hover:text-emerald-600 hover:bg-emerald-50'}`} title={p.is_active ? 'Désactiver' : 'Réactiver'}>
                            {p.is_active ? <UserX size={14} /> : <UserCheck size={14} />}
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {editing && (
        <Modal title={`Modifier — ${editing.full_name ?? editing.email}`} onClose={() => setEditing(null)} size="sm">
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white font-bold">
                {initials(editing)}
              </div>
              <div>
                <div className="font-semibold text-slate-900">{editing.full_name ?? '—'}</div>
                <div className="text-xs text-slate-400">{editing.email}</div>
              </div>
            </div>
            <FormField label="Rôle">
              <select className={selectCls} value={editForm.role} onChange={e => setEditForm(f => ({ ...f, role: e.target.value }))}>
                {roleOptions.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
              </select>
            </FormField>
            <div className="bg-slate-50 rounded-xl p-3">
              <p className="text-xs font-semibold text-slate-600 mb-2">Accès avec ce rôle :</p>
              <div className="flex flex-wrap gap-1">
                {accessMap[editForm.role]?.map(mod => (
                  <span key={mod} className="text-xs bg-white border border-slate-200 text-slate-600 px-2 py-0.5 rounded-full">{mod}</span>
                ))}
              </div>
            </div>
            <FormField label="Statut du compte">
              <div className="flex gap-3">
                {[{ v: true, l: 'Actif' }, { v: false, l: 'Désactivé' }].map(opt => (
                  <label key={String(opt.v)} className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 cursor-pointer transition text-sm font-medium ${editForm.is_active === opt.v ? 'border-orange-400 bg-orange-50 text-orange-700' : 'border-slate-100 text-slate-500 hover:border-slate-300'}`}>
                    <input type="radio" className="sr-only" checked={editForm.is_active === opt.v} onChange={() => setEditForm(f => ({ ...f, is_active: opt.v }))} />
                    {opt.l}
                  </label>
                ))}
              </div>
            </FormField>
            <div className="flex justify-end gap-3 pt-2 border-t border-slate-100">
              <button onClick={() => setEditing(null)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
              <button onClick={handleSave} disabled={saving} className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50">
                {saving ? 'Enregistrement...' : 'Sauvegarder'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
