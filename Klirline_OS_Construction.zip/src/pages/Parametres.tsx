import { useState, useEffect } from 'react';
import {
  Building2, Bell, Shield, Palette, Globe, CreditCard,
  CheckCircle, XCircle, Loader2, ExternalLink, LogOut, AlertCircle, Save,
} from 'lucide-react';
import Header from '../components/Header';
import { FormField, inputCls, selectCls } from '../components/ui';
import { useAuth } from '../lib/auth';
import { supabase } from '../lib/supabase';
import { useCompanySettings, type CompanySettings } from '../lib/useCompanySettings';

// ── Navigation helper (dispatches to App.tsx handler) ───────────────────────
function navigateTo(page: string) {
  window.dispatchEvent(new CustomEvent('klirline:navigate', { detail: page }));
}

// ── Types ────────────────────────────────────────────────────────────────────
interface IntegrationStatus {
  connected: boolean;
  email?: string;
  loading: boolean;
  error?: string;
}

// ── Gmail logo ───────────────────────────────────────────────────────────────
function GmailLogo({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}

// ── Microsoft logo ───────────────────────────────────────────────────────────
function MsLogo({ size = 20 }: { size?: number }) {
  const s = size / 2 - 1;
  return (
    <svg width={size} height={size} viewBox="0 0 21 21" fill="none">
      <rect x="1" y="1" width={s} height={s} fill="#F25022"/>
      <rect x={s + 2} y="1" width={s} height={s} fill="#7FBA00"/>
      <rect x="1" y={s + 2} width={s} height={s} fill="#00A4EF"/>
      <rect x={s + 2} y={s + 2} width={s} height={s} fill="#FFB900"/>
    </svg>
  );
}

const tabs = [
  { id: 'company', label: 'Entreprise', icon: Building2 },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'security', label: 'Sécurité', icon: Shield },
  { id: 'appearance', label: 'Apparence', icon: Palette },
  { id: 'integrations', label: 'Intégrations', icon: Globe },
  { id: 'billing', label: 'Facturation', icon: CreditCard },
];

// ── Integrations tab ─────────────────────────────────────────────────────────
function IntegrationsTab() {
  const { session, user } = useAuth();
  const [gmail, setGmail] = useState<IntegrationStatus>({ connected: false, loading: true });
  const [m365, setM365] = useState<IntegrationStatus>({ connected: false, loading: true });
  const [stripe, setStripe] = useState<{ plan: string; status: string; loading: boolean }>({
    plan: 'none', status: 'none', loading: true,
  });
  const [connectingGmail, setConnectingGmail] = useState(false);
  const [connectingM365, setConnectingM365] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  const showToast = (type: 'success' | 'error', msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 3500);
  };

  // Handle OAuth callback params on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('gmail_connected') === 'true') {
      showToast('success', `Gmail connecté : ${params.get('gmail_email') ?? ''}`);
      window.history.replaceState({}, '', window.location.pathname);
    } else if (params.get('gmail_error')) {
      showToast('error', `Erreur Gmail : ${params.get('gmail_error')}`);
      window.history.replaceState({}, '', window.location.pathname);
    }
    if (params.get('m365_connected') === 'true') {
      showToast('success', `Microsoft 365 connecté : ${params.get('ms_email') ?? ''}`);
      window.history.replaceState({}, '', window.location.pathname);
    } else if (params.get('m365_error')) {
      showToast('error', `Erreur Microsoft 365 : ${params.get('m365_error')}`);
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, []);

  // Load connection statuses
  useEffect(() => {
    if (!user) return;

    // Gmail status — query DB directly
    supabase
      .from('gmail_tokens')
      .select('gmail_email')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        setGmail({ connected: !!data, email: data?.gmail_email, loading: false });
      });

    // M365 status — query DB directly
    supabase
      .from('m365_tokens')
      .select('ms_email')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        setM365({ connected: !!data, email: data?.ms_email, loading: false });
      });

    // Stripe subscription
    supabase
      .from('subscriptions')
      .select('plan, status')
      .eq('owner_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        setStripe({ plan: data?.plan ?? 'none', status: data?.status ?? 'none', loading: false });
      });
  }, [user]);

  // ── Connect Gmail ──────────────────────────────────────────────────────────
  const handleConnectGmail = async () => {
    if (!session?.access_token) {
      showToast('error', 'Session expirée. Veuillez vous reconnecter.');
      return;
    }
    setConnectingGmail(true);
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
      const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
      const resp = await fetch(`${supabaseUrl}/functions/v1/gmail-oauth?action=auth-url`, {
        headers: {
          Authorization: `Bearer ${session.access_token}`,
          apikey: anonKey,
        },
      });
      const data = await resp.json();
      if (!resp.ok || data.error) throw new Error(data.error ?? 'Erreur connexion');
      if (data.url) window.location.href = data.url;
    } catch (e: unknown) {
      showToast('error', (e as Error)?.message ?? 'Impossible de démarrer la connexion Gmail.');
      setConnectingGmail(false);
    }
  };

  // ── Disconnect Gmail ───────────────────────────────────────────────────────
  const handleDisconnectGmail = async () => {
    if (!user || !confirm('Déconnecter Gmail ?')) return;
    await supabase.from('gmail_tokens').delete().eq('user_id', user.id);
    setGmail({ connected: false, loading: false });
    showToast('success', 'Gmail déconnecté.');
  };

  // ── Connect Microsoft 365 ─────────────────────────────────────────────────
  const handleConnectM365 = async () => {
    if (!session?.access_token) {
      showToast('error', 'Session expirée. Veuillez vous reconnecter.');
      return;
    }
    setConnectingM365(true);
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
      const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
      const resp = await fetch(`${supabaseUrl}/functions/v1/m365-oauth?action=auth-url`, {
        headers: {
          Authorization: `Bearer ${session.access_token}`,
          apikey: anonKey,
        },
      });
      const data = await resp.json();
      if (!resp.ok || data.error) throw new Error(data.error ?? 'Erreur connexion');
      if (data.url) window.location.href = data.url;
    } catch (e: unknown) {
      showToast('error', (e as Error)?.message ?? 'Impossible de démarrer la connexion Microsoft 365.');
      setConnectingM365(false);
    }
  };

  // ── Disconnect Microsoft 365 ──────────────────────────────────────────────
  const handleDisconnectM365 = async () => {
    if (!user || !confirm('Déconnecter Microsoft 365 ?')) return;
    await supabase.from('m365_tokens').delete().eq('user_id', user.id);
    setM365({ connected: false, loading: false });
    showToast('success', 'Microsoft 365 déconnecté.');
  };

  const stripeStatusLabel: Record<string, string> = {
    active: 'Actif', trialing: "Période d'essai", past_due: 'Paiement en retard',
    canceled: 'Annulé', none: 'Aucun abonnement',
  };
  const stripeStatusColor: Record<string, string> = {
    active: 'text-emerald-600 bg-emerald-50', trialing: 'text-blue-600 bg-blue-50',
    past_due: 'text-red-600 bg-red-50', canceled: 'text-slate-500 bg-slate-100',
    none: 'text-slate-400 bg-slate-100',
  };

  return (
    <div className="space-y-4 max-w-2xl">
      <div>
        <h2 className="font-bold text-slate-900 text-base">Intégrations</h2>
        <p className="text-sm text-slate-400 mt-0.5">
          Connectez vos outils externes pour les utiliser directement dans Klirline OS.
        </p>
      </div>

      {/* Toast */}
      {toast && (
        <div className={`flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-semibold ${toast.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          {toast.type === 'success' ? <CheckCircle size={15} /> : <AlertCircle size={15} />}
          {toast.msg}
        </div>
      )}

      {/* Gmail */}
      <IntegrationCard
        logo={<GmailLogo size={22} />}
        name="Gmail"
        description="Lisez et envoyez vos courriels directement depuis Email Hub."
        status={gmail}
        onConnect={handleConnectGmail}
        onDisconnect={handleDisconnectGmail}
        connecting={connectingGmail}
      />

      {/* Microsoft 365 */}
      <IntegrationCard
        logo={<MsLogo size={20} />}
        name="Microsoft 365"
        description="Outlook, Exchange — intégrez votre messagerie Microsoft."
        status={m365}
        onConnect={handleConnectM365}
        onDisconnect={handleDisconnectM365}
        connecting={connectingM365}
      />

      {/* Stripe */}
      <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-white font-black text-sm flex-shrink-0">
              S
            </div>
            <div>
              <div className="font-semibold text-slate-900 text-sm">Stripe</div>
              <div className="text-xs text-slate-400">Paiements en ligne pour vos abonnements</div>
            </div>
          </div>
          <div className="flex items-center gap-3 flex-shrink-0">
            {stripe.loading ? (
              <Loader2 size={15} className="animate-spin text-slate-300" />
            ) : (
              <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${stripeStatusColor[stripe.status] ?? stripeStatusColor.none}`}>
                {stripe.plan !== 'none' ? `Plan ${stripe.plan} — ` : ''}{stripeStatusLabel[stripe.status] ?? stripe.status}
              </span>
            )}
            <button
              onClick={() => navigateTo('abonnements')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-orange-600 bg-orange-50 hover:bg-orange-100 rounded-lg transition"
            >
              <ExternalLink size={12} />
              Gérer
            </button>
          </div>
        </div>
      </div>

      {/* Info box */}
      <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 text-xs text-blue-700 leading-relaxed">
        <strong>Configuration requise :</strong> Pour activer Gmail, ajoutez <code className="bg-blue-100 px-1 rounded">GOOGLE_CLIENT_ID</code> et <code className="bg-blue-100 px-1 rounded">GOOGLE_CLIENT_SECRET</code> dans vos secrets Supabase. Pour Microsoft 365, ajoutez <code className="bg-blue-100 px-1 rounded">MICROSOFT_CLIENT_ID</code> et <code className="bg-blue-100 px-1 rounded">MICROSOFT_CLIENT_SECRET</code>.
      </div>
    </div>
  );
}

// ── Integration card component ────────────────────────────────────────────────
interface IntegrationCardProps {
  logo: React.ReactNode;
  name: string;
  description: string;
  status: IntegrationStatus;
  onConnect: () => void;
  onDisconnect: () => void;
  connecting: boolean;
}

function IntegrationCard({
  logo, name, description, status, onConnect, onDisconnect, connecting,
}: IntegrationCardProps) {
  return (
    <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center flex-shrink-0">
            {logo}
          </div>
          <div>
            <div className="font-semibold text-slate-900 text-sm">{name}</div>
            <div className="text-xs text-slate-400">{description}</div>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          {status.loading ? (
            <Loader2 size={15} className="animate-spin text-slate-300" />
          ) : status.connected ? (
            <>
              <div className="flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full font-medium">
                <CheckCircle size={12} />
                <span className="max-w-[140px] truncate">{status.email ?? 'Connecté'}</span>
              </div>
              <button
                onClick={onDisconnect}
                className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition"
                title={`Déconnecter ${name}`}
              >
                <LogOut size={14} />
              </button>
            </>
          ) : (
            <button
              onClick={onConnect}
              disabled={connecting}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-900 hover:bg-slate-700 text-white rounded-lg transition disabled:opacity-50"
            >
              {connecting ? (
                <><Loader2 size={12} className="animate-spin" />Redirection...</>
              ) : (
                <>Connecter</>
              )}
            </button>
          )}
          {!status.loading && !status.connected && (
            <div className="w-2 h-2 rounded-full bg-slate-300" title="Non connecté" />
          )}
          {!status.loading && status.connected && status.error && (
            <XCircle size={14} className="text-red-400" title={status.error} />
          )}
        </div>
      </div>
    </div>
  );
}

// ── Company tab ───────────────────────────────────────────────────────────────
function CompanyTab() {
  const { user } = useAuth();
  const { settings: loaded, loading } = useCompanySettings();
  const [form, setForm] = useState<CompanySettings>(loaded);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!loading) setForm(loaded);
  }, [loading]);

  const set = (k: keyof CompanySettings, v: string) =>
    setForm(prev => ({ ...prev, [k]: v }));

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    setError(null);
    const { error: err } = await supabase
      .from('company_settings')
      .upsert({ ...form, owner_id: user.id }, { onConflict: 'owner_id' });
    setSaving(false);
    if (err) { setError(err.message); return; }
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 max-w-2xl flex items-center justify-center h-40">
        <Loader2 size={22} className="animate-spin text-slate-300" />
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-5 max-w-2xl">
      <div>
        <h2 className="font-bold text-slate-900 text-base">Informations de l'entreprise</h2>
        <p className="text-xs text-slate-400 mt-0.5">Ces données apparaissent automatiquement sur vos factures, soumissions et documents imprimés.</p>
      </div>

      {error && (
        <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-100 rounded-xl px-4 py-3">
          <AlertCircle size={14} /> {error}
        </div>
      )}

      {/* Identity */}
      <div>
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3">Identité</p>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <FormField label="Nom de l'entreprise">
              <input className={inputCls} value={form.nom_entreprise} onChange={e => set('nom_entreprise', e.target.value)} placeholder="Construction Klirline Inc." />
            </FormField>
          </div>
          <FormField label="NEQ">
            <input className={inputCls} value={form.neq} onChange={e => set('neq', e.target.value)} placeholder="1234567890" />
          </FormField>
          <FormField label="Licence RBQ">
            <input className={inputCls} value={form.rbq} onChange={e => set('rbq', e.target.value)} placeholder="8367-1234-01" />
          </FormField>
          <FormField label="No. TPS (RT)">
            <input className={inputCls} value={form.tps_no} onChange={e => set('tps_no', e.target.value)} placeholder="123456789 RT0001" />
          </FormField>
          <FormField label="No. TVQ (TQ)">
            <input className={inputCls} value={form.tvq_no} onChange={e => set('tvq_no', e.target.value)} placeholder="1234567890 TQ0001" />
          </FormField>
        </div>
      </div>

      {/* Coordinates */}
      <div>
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3">Coordonnées</p>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <FormField label="Adresse">
              <input className={inputCls} value={form.adresse} onChange={e => set('adresse', e.target.value)} placeholder="123 rue des Entrepreneurs" />
            </FormField>
          </div>
          <FormField label="Ville">
            <input className={inputCls} value={form.ville} onChange={e => set('ville', e.target.value)} placeholder="Montréal" />
          </FormField>
          <FormField label="Province">
            <select className={selectCls} value={form.province} onChange={e => set('province', e.target.value)}>
              <option value="QC">Québec</option>
              <option value="ON">Ontario</option>
              <option value="BC">Colombie-Britannique</option>
              <option value="AB">Alberta</option>
              <option value="MB">Manitoba</option>
              <option value="SK">Saskatchewan</option>
              <option value="NS">Nouvelle-Écosse</option>
              <option value="NB">Nouveau-Brunswick</option>
              <option value="NL">Terre-Neuve</option>
              <option value="PE">Î.-P.-É.</option>
            </select>
          </FormField>
          <FormField label="Code postal">
            <input className={inputCls} value={form.code_postal} onChange={e => set('code_postal', e.target.value)} placeholder="H1H 1H1" />
          </FormField>
          <FormField label="Téléphone">
            <input className={inputCls} value={form.telephone} onChange={e => set('telephone', e.target.value)} placeholder="514 555-0000" />
          </FormField>
          <FormField label="Courriel">
            <input className={inputCls} type="email" value={form.courriel} onChange={e => set('courriel', e.target.value)} placeholder="info@entreprise.ca" />
          </FormField>
          <FormField label="Site web">
            <input className={inputCls} type="url" value={form.site_web} onChange={e => set('site_web', e.target.value)} placeholder="https://entreprise.ca" />
          </FormField>
        </div>
      </div>

      {/* Logo */}
      <div>
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3">Logo</p>
        <FormField label="URL du logo (apparaît sur les documents imprimés)">
          <input className={inputCls} type="url" value={form.logo_url} onChange={e => set('logo_url', e.target.value)} placeholder="https://..." />
        </FormField>
        {form.logo_url && (
          <div className="mt-2 flex items-center gap-3">
            <img src={form.logo_url} alt="Logo" className="h-12 w-auto rounded-lg border border-slate-100 object-contain bg-slate-50 p-1" onError={e => (e.currentTarget.style.display = 'none')} />
            <span className="text-xs text-slate-400">Aperçu du logo</span>
          </div>
        )}
      </div>

      <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100">
        {saved && (
          <span className="flex items-center gap-1.5 text-sm text-emerald-600 font-medium">
            <CheckCircle size={14} /> Sauvegardé
          </span>
        )}
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 disabled:opacity-60 text-white rounded-lg transition"
        >
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
          {saving ? 'Sauvegarde...' : 'Sauvegarder'}
        </button>
      </div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function ParametresPage() {
  const [activeTab, setActiveTab] = useState('company');
  const [saved, setSaved] = useState(false);

  const save = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="flex flex-col h-full">
      <Header title="Paramètres" subtitle="Configuration de Klirline OS" />

      {/* Mobile: horizontal scrolling tab bar */}
      <div className="flex md:hidden overflow-x-auto flex-shrink-0 px-4 pt-3 pb-0 gap-1 bg-slate-50 border-b border-slate-200">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-t-lg text-xs font-medium whitespace-nowrap transition border-b-2 -mb-px ${
              activeTab === t.id
                ? 'border-orange-500 text-orange-600 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <t.icon size={13} />
            {t.label}
          </button>
        ))}
      </div>

      <div className="flex flex-1 overflow-hidden p-4 md:p-6 gap-6">
        {/* Desktop: vertical tab sidebar */}
        <div className="hidden md:block w-52 flex-shrink-0 space-y-0.5">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition text-left ${activeTab === t.id ? 'bg-orange-500 text-white' : 'text-slate-600 hover:bg-white border border-transparent hover:border-slate-100'}`}>
              <t.icon size={16} />
              {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {activeTab === 'company' && <CompanyTab />}


          {activeTab === 'notifications' && (
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-5 max-w-2xl">
              <h2 className="font-bold text-slate-900 text-base">Préférences de notifications</h2>
              {[
                { label: 'Nouvelle présence enregistrée', desc: 'Quand un employé pointe son entrée' },
                { label: 'Facture payée', desc: 'Confirmation de paiement reçu' },
                { label: 'Nouveau message chat', desc: 'Message non lu dans les canaux' },
                { label: 'Facture en retard', desc: "Rappel d'échéance dépassée" },
                { label: 'Nouveau lead', desc: 'Prospect ajouté au CRM' },
                { label: 'Fin de chantier prévue', desc: '3 jours avant la date de fin' },
              ].map(n => (
                <div key={n.label} className="flex items-center justify-between py-3 border-b border-slate-50 last:border-0">
                  <div>
                    <div className="text-sm font-medium text-slate-800">{n.label}</div>
                    <div className="text-xs text-slate-400">{n.desc}</div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-10 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-5 peer-checked:bg-orange-500 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all" />
                  </label>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'security' && (
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-5 max-w-2xl">
              <h2 className="font-bold text-slate-900 text-base">Sécurité</h2>
              <div className="space-y-4">
                <FormField label="Mot de passe actuel">
                  <input className={inputCls} type="password" />
                </FormField>
                <FormField label="Nouveau mot de passe">
                  <input className={inputCls} type="password" />
                </FormField>
                <FormField label="Confirmer le nouveau mot de passe">
                  <input className={inputCls} type="password" />
                </FormField>
                <div className="flex justify-end pt-2 border-t border-slate-100">
                  <button onClick={save} className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition">
                    Mettre à jour
                  </button>
                </div>
              </div>
              <div className="bg-slate-50 rounded-xl p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-slate-800 text-sm">Authentification à 2 facteurs</div>
                    <div className="text-xs text-slate-400">Sécurité renforcée pour votre compte</div>
                  </div>
                  <button className="px-3 py-1.5 text-xs font-semibold text-orange-600 bg-orange-50 hover:bg-orange-100 rounded-lg transition">Activer</button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'appearance' && (
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-5 max-w-2xl">
              <h2 className="font-bold text-slate-900 text-base">Apparence</h2>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-3">Thème</label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: 'Clair', desc: 'Thème par défaut' },
                    { label: 'Sombre', desc: 'Mode nuit' },
                    { label: 'Système', desc: 'Automatique' },
                  ].map((t, i) => (
                    <button key={t.label} className={`p-3 rounded-xl border-2 text-left transition ${i === 0 ? 'border-orange-500 bg-orange-50' : 'border-slate-100 hover:border-slate-300'}`}>
                      <div className="text-sm font-semibold text-slate-800">{t.label}</div>
                      <div className="text-xs text-slate-400">{t.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
              <FormField label="Langue">
                <select className={selectCls} defaultValue="fr">
                  <option value="fr">Français (Canada)</option>
                  <option value="en">English</option>
                </select>
              </FormField>
            </div>
          )}

          {activeTab === 'integrations' && <IntegrationsTab />}

          {activeTab === 'billing' && (
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-5 max-w-2xl">
              <h2 className="font-bold text-slate-900 text-base">Abonnement</h2>
              <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl border border-orange-100 p-5">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-bold text-orange-800 text-lg">Plan Pro</div>
                    <div className="text-sm text-orange-600 mt-1">149 $/mois · Facturé annuellement</div>
                    <div className="text-xs text-orange-500 mt-2">Renouvellement le 1 janvier 2027</div>
                  </div>
                  <span className="px-3 py-1 bg-emerald-500 text-white text-xs font-bold rounded-full">Actif</span>
                </div>
              </div>
              <div className="space-y-3">
                <h3 className="font-semibold text-slate-800 text-sm">Inclus dans votre plan</h3>
                {['Utilisateurs illimités', 'Tous les modules', 'Support prioritaire', 'Sauvegardes automatiques', 'API et intégrations', 'Rapports avancés'].map(f => (
                  <div key={f} className="flex items-center gap-2 text-sm text-slate-600">
                    <div className="w-4 h-4 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 text-xs font-bold flex-shrink-0">✓</div>
                    {f}
                  </div>
                ))}
              </div>
              <div className="pt-2 border-t border-slate-100">
                <button
                  onClick={() => navigateTo('abonnements')}
                  className="flex items-center gap-2 text-sm font-semibold text-orange-600 hover:text-orange-700 transition"
                >
                  <ExternalLink size={14} />
                  Gérer l'abonnement
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
