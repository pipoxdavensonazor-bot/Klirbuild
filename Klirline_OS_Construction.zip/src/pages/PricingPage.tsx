import React from 'react';
import { PricingGrid } from '../components/pricing/PricingGrid';
import { useSubscription } from '../hooks/useSubscription';
import { Crown, Sparkles } from 'lucide-react';

export function PricingPage() {
  const { subscription } = useSubscription();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-indigo-50 px-4 py-1.5 text-sm font-medium text-indigo-700 ring-1 ring-indigo-200">
            <Sparkles className="h-4 w-4" />
            Simple, transparent pricing
          </div>
          <h1 className="text-5xl font-extrabold tracking-tight text-gray-900">
            Plans for every scale
          </h1>
          <p className="mt-5 text-xl text-gray-500">
            Start free, upgrade as you grow. All plans include a 14-day trial with no credit card required.
          </p>

          {subscription.isActive && subscription.planName && (
            <div className="mt-6 inline-flex items-center gap-2 rounded-xl bg-emerald-50 px-5 py-2.5 text-sm font-medium text-emerald-700 ring-1 ring-emerald-200">
              <Crown className="h-4 w-4" />
              You're on the <strong>{subscription.planName}</strong> plan
              {subscription.cancelAtPeriodEnd && (
                <span className="ml-2 rounded-full bg-amber-100 px-2 py-0.5 text-xs text-amber-700">
                  Cancels at period end
                </span>
              )}
            </div>
          )}
        </div>

        {/* Pricing Grid */}
        <div className="mt-16">
          <PricingGrid />
        </div>

        {/* Footer note */}
        <p className="mt-12 text-center text-sm text-gray-400">
          All prices are in USD unless stated otherwise. Taxes may apply. You can cancel your subscription at any time.
        </p>
      </div>
    </div>
  );
}