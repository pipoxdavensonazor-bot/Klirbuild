import { useState, useEffect } from 'react';
import { Crown, Check, Zap, Building2, AlertCircle, ExternalLink, Shield, Settings } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { supabase } from '../lib/supabase';
import Header from '../components/Header';

interface Subscription {
  plan: string;
  status: string;
  current_period_end: string | null;
  cancel_at_period_end: boolean;
  stripe_subscription_id: string | null;
}

const PLANS = [
  {
    id: 'starter',
    name: 'Starter',
    price: 49,
    period: '/mois',
    icon: Zap,
    color: 'from-blue-500 to-blue-600',
    badge: null,
    description: 'Idéal pour les petites équipes de 1 à 5 personnes.',
    features: [
      'Jusqu\'à 5 utilisateurs',
      'Clients & Leads (CRM)',
      'Gestion de 3 chantiers actifs',
      'Présences & Calendrier',
      'Chat interne',
      'Klir AI (30 req./jour)',
      'Documents (1 GB)',
      'Support par courriel',
    ],
    missing: ['Facturation avancée', 'Rapports', 'API & Intégrations'],
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 149,
    period: '/mois',
    icon: Crown,
    color: 'from-orange-500 to-amber-500',
    badge: 'Populaire',
    description: 'Accès complet pour les entreprises en croissance.',
    features: [
      'Utilisateurs illimités',
      'Tous les modules CRM',
      'Chantiers illimités',
      'Facturation & Paiements',
      'Comptabilité',
      'Email Hub (Gmail / M365)',
      'Klir AI illimité',
      'Rapports avancés',
      'Documents (50 GB)',
      'Support prioritaire',
    ],
    missing: ['White label', 'API dédiée'],
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 299,
    period: '/mois',
    icon: Building2,
    color: 'from-slate-700 to-slate-800',
    badge: null,
    description: 'Pour les grandes entreprises avec des besoins sur mesure.',
    features: [
      'Tout le plan Pro',
      'White label (votre marque)',
      'API dédiée + webhooks',
      'SSO / SAML',
      'Intégrations personnalisées',
      'Formation & onboarding',
      'SLA garanti 99,9%',
      'Support dédié 24/7',
      'Documents illimités',
      'Accès multi-entreprises',
    ],
    missing: [],
  },
];

export default function AbonnementsPage() {
  const { user, profile } = useAuth();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [checkoutLoading, setCheckoutLoading] = useState<string | null>(null);
  const [portalLoading, setPortalLoading] = useState(false);
  const [error, setError] = useState('');
  const [billingAnnual, setBillingAnnual] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('subscriptions')
      .select('plan, status, current_period_end, cancel_at_period_end, stripe_subscription_id')
      .eq('owner_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        setSubscription(data as Subscription | null);
        setLoading(false);
      });
  }, [user]);

  const handleCheckout = async (planId: string) => {
    setError('');
    setCheckoutLoading(planId);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;

      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/stripe-checkout`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            plan: planId,
            annual: billingAnnual,
            successUrl: window.location.origin + '/?checkout=success',
            cancelUrl: window.location.origin + '/?checkout=cancel',
          }),
        }
      );

      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error ?? 'Erreur lors de la création de la session de paiement.');
        return;
      }
      if (data.url) window.location.href = data.url;
    } catch (e: any) {
      setError(e.message ?? 'Erreur réseau.');
    } finally {
      setCheckoutLoading(null);
    }
  };

  const handlePortal = async () => {
    setError('');
    setPortalLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/stripe-portal`,
        {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ returnUrl: window.location.href }),
        }
      );
      const data = await res.json();
      if (!res.ok || data.error) { setError(data.error ?? 'Erreur portail Stripe.'); return; }
      if (data.url) window.location.href = data.url;
    } catch (e: any) {
      setError(e.message ?? 'Erreur réseau.');
    } finally {
      setPortalLoading(false);
    }
  };

  const statusLabel: Record<string, { label: string; color: string }> = {
    trialing: { label: 'Période d\'essai', color: 'bg-blue-100 text-blue-700' },
    active:   { label: 'Actif', color: 'bg-emerald-100 text-emerald-700' },
    past_due: { label: 'Paiement en retard', color: 'bg-red-100 text-red-700' },
    canceled: { label: 'Annulé', color: 'bg-slate-100 text-slate-600' },
    none:     { label: 'Aucun abonnement', color: 'bg-slate-100 text-slate-500' },
  };

  const currentPlanId = subscription?.plan ?? 'none';
  const subStatus = subscription?.status ?? profile?.subscription_status ?? 'none';
  const statusInfo = statusLabel[subStatus] ?? statusLabel.none;

  const discountedPrice = (price: number) => billingAnnual ? Math.round(price * 0.8) : price;

  return (
    <div className="flex flex-col h-full">
      <Header title="Abonnement" subtitle="Gérez votre plan Klirline OS" />
      <div className="flex-1 overflow-y-auto p-6 space-y-8">

        {/* Current plan banner */}
        {!loading && (
          <div className={`rounded-2xl border p-5 flex items-start justify-between flex-wrap gap-4 ${subStatus === 'active' || subStatus === 'trialing' ? 'bg-emerald-50 border-emerald-200' : 'bg-slate-50 border-slate-200'}`}>
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${subStatus === 'active' || subStatus === 'trialing' ? 'bg-emerald-500' : 'bg-slate-400'}`}>
                <Crown size={22} className="text-white" />
              </div>
              <div>
                <div className="font-bold text-slate-900 text-base">
                  Plan actuel : <span className="capitalize">{currentPlanId !== 'none' ? currentPlanId : 'Aucun'}</span>
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${statusInfo.color}`}>{statusInfo.label}</span>
                  {subscription?.current_period_end && (
                    <span className="text-xs text-slate-500">
                      · Renouvellement le {new Date(subscription.current_period_end).toLocaleDateString('fr-CA')}
                    </span>
                  )}
                  {subscription?.cancel_at_period_end && (
                    <span className="text-xs text-amber-600 font-medium">· Annulation programmée</span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {subscription?.stripe_customer_id && (
                <button
                  onClick={handlePortal}
                  disabled={portalLoading}
                  className="flex items-center gap-2 bg-white border border-slate-200 hover:border-slate-300 hover:bg-slate-50 rounded-xl px-4 py-2.5 text-sm font-medium text-slate-700 transition disabled:opacity-60"
                >
                  {portalLoading
                    ? <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    : <Settings size={15} />}
                  Gérer mon abonnement
                </button>
              )}
              <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm">
                <Shield size={16} className="text-slate-400" />
                <span className="text-slate-600">Paiements sécurisés par</span>
                <span className="font-bold text-slate-800">Stripe</span>
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="flex items-start gap-3 bg-red-50 border border-red-200 text-red-700 px-5 py-4 rounded-2xl text-sm">
            <AlertCircle size={18} className="flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold mb-1">Erreur de paiement</p>
              <p>{error}</p>
              {error.includes('non configuré') && (
                <p className="mt-2 text-red-600">Pour activer Stripe, ajoutez les secrets <code className="bg-red-100 px-1 rounded">STRIPE_SECRET_KEY</code>, <code className="bg-red-100 px-1 rounded">STRIPE_PRICE_STARTER</code>, <code className="bg-red-100 px-1 rounded">STRIPE_PRICE_PRO</code> et <code className="bg-red-100 px-1 rounded">STRIPE_PRICE_ENTERPRISE</code> dans vos variables d'environnement Supabase.</p>
              )}
            </div>
          </div>
        )}

        {/* Billing toggle */}
        <div className="flex items-center justify-center gap-4">
          <span className={`text-sm font-medium ${!billingAnnual ? 'text-slate-900' : 'text-slate-400'}`}>Mensuel</span>
          <button
            onClick={() => setBillingAnnual(!billingAnnual)}
            className={`relative w-12 h-6 rounded-full transition-colors ${billingAnnual ? 'bg-orange-500' : 'bg-slate-200'}`}
          >
            <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${billingAnnual ? 'translate-x-6' : 'translate-x-0.5'}`} />
          </button>
          <span className={`text-sm font-medium ${billingAnnual ? 'text-slate-900' : 'text-slate-400'}`}>
            Annuel <span className="ml-1 text-xs font-bold text-emerald-600 bg-emerald-100 px-1.5 py-0.5 rounded-full">-20%</span>
          </span>
        </div>

        {/* Plans grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto w-full">
          {PLANS.map((plan) => {
            const Icon = plan.icon;
            const isCurrentPlan = currentPlanId === plan.id && (subStatus === 'active' || subStatus === 'trialing');
            const isPopular = plan.badge === 'Populaire';
            const price = discountedPrice(plan.price);

            return (
              <div
                key={plan.id}
                className={`relative rounded-3xl border overflow-hidden flex flex-col transition-shadow hover:shadow-xl ${
                  isPopular
                    ? 'border-orange-400 shadow-lg shadow-orange-100'
                    : isCurrentPlan
                    ? 'border-emerald-400 shadow-lg shadow-emerald-100'
                    : 'border-slate-200'
                }`}
              >
                {/* Header gradient */}
                <div className={`bg-gradient-to-br ${plan.color} p-6 text-white`}>
                  {plan.badge && (
                    <div className="absolute top-4 right-4 bg-white text-orange-600 text-xs font-black px-2.5 py-1 rounded-full shadow">
                      {plan.badge}
                    </div>
                  )}
                  {isCurrentPlan && (
                    <div className="absolute top-4 right-4 bg-emerald-500 text-white text-xs font-black px-2.5 py-1 rounded-full shadow flex items-center gap-1">
                      <Check size={10} />Plan actuel
                    </div>
                  )}
                  <div className="w-10 h-10 bg-white/20 rounded-2xl flex items-center justify-center mb-4">
                    <Icon size={22} className="text-white" />
                  </div>
                  <h3 className="text-xl font-black">{plan.name}</h3>
                  <p className="text-white/70 text-xs mt-1 leading-relaxed">{plan.description}</p>
                  <div className="mt-4 flex items-end gap-1">
                    <span className="text-4xl font-black">{price}$</span>
                    <span className="text-white/70 text-sm mb-1">{plan.period}</span>
                  </div>
                  {billingAnnual && (
                    <p className="text-white/60 text-xs mt-1">facturé {price * 12}$/an</p>
                  )}
                </div>

                {/* Features */}
                <div className="bg-white flex-1 p-5 space-y-2.5">
                  {plan.features.map((f) => (
                    <div key={f} className="flex items-start gap-2.5 text-sm text-slate-700">
                      <div className="w-4 h-4 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Check size={10} className="text-emerald-600" />
                      </div>
                      {f}
                    </div>
                  ))}
                  {plan.missing.map((f) => (
                    <div key={f} className="flex items-start gap-2.5 text-sm text-slate-300 line-through">
                      <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-slate-300 text-xs">×</span>
                      </div>
                      {f}
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <div className="bg-white px-5 pb-6">
                  <button
                    onClick={() => handleCheckout(plan.id)}
                    disabled={isCurrentPlan || !!checkoutLoading}
                    className={`w-full py-3 rounded-2xl font-bold text-sm transition flex items-center justify-center gap-2 ${
                      isCurrentPlan
                        ? 'bg-emerald-100 text-emerald-700 cursor-default'
                        : isPopular
                        ? 'bg-orange-500 hover:bg-orange-600 text-white shadow-lg shadow-orange-200'
                        : 'bg-slate-900 hover:bg-slate-800 text-white'
                    } disabled:opacity-60`}
                  >
                    {checkoutLoading === plan.id ? (
                      <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    ) : isCurrentPlan ? (
                      <><Check size={15} />Plan actuel</>
                    ) : (
                      <><ExternalLink size={14} />Choisir {plan.name}</>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto w-full space-y-4">
          <h3 className="font-bold text-slate-900 text-lg text-center mb-6">Questions fréquentes</h3>
          {[
            { q: 'Puis-je annuler à tout moment ?', a: 'Oui. Vous pouvez annuler votre abonnement à tout moment depuis cette page. Votre accès reste actif jusqu\'à la fin de la période de facturation en cours.' },
            { q: 'Y a-t-il une période d\'essai ?', a: 'Tous les plans incluent un essai gratuit de 14 jours sans carte de crédit requise.' },
            { q: 'Comment fonctionne la facturation annuelle ?', a: 'En choisissant la facturation annuelle, vous économisez 20% sur le prix mensuel. Le montant annuel est facturé en une seule fois.' },
            { q: 'Puis-je changer de plan ?', a: 'Oui, vous pouvez passer à un plan supérieur ou inférieur à tout moment. Les changements prennent effet immédiatement.' },
          ].map((item, i) => (
            <div key={i} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
              <div className="font-semibold text-slate-900 text-sm mb-2">{item.q}</div>
              <div className="text-sm text-slate-500 leading-relaxed">{item.a}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
