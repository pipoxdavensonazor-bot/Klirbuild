import { useEffect, useState } from 'react';
import {
  Users, FileText, TrendingUp, DollarSign,
  AlertCircle, ClipboardList, ArrowRight, CheckCircle, Clock,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { StatCard, SectionCard, Badge, LoadingSpinner } from '../components/ui';

interface InvoiceRow {
  id: string;
  number: string;
  status: string;
  issue_date: string;
  total: number;
  tax_amount: number;
  clients?: { name: string; company: string | null } | null;
}

interface SoumissionRow {
  id: string;
  status: string;
  total: number;
  issue_date: string;
}

interface ActivityRow {
  id: string;
  title: string;
  status: string;
  priority: string;
  due_date: string | null;
  category: string | null;
}

const fmt = (n: number) =>
  new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD', maximumFractionDigits: 0 }).format(n);

function MonthlyBarChart({ invoices }: { invoices: InvoiceRow[] }) {
  const months = Array.from({ length: 6 }, (_, i) => {
    const d = new Date();
    d.setDate(1);
    d.setMonth(d.getMonth() - (5 - i));
    return {
      key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`,
      label: d.toLocaleDateString('fr-CA', { month: 'short' }),
      amount: 0,
    };
  });

  invoices
    .filter(inv => inv.status === 'paid' && inv.issue_date)
    .forEach(inv => {
      const d = new Date(inv.issue_date);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const bucket = months.find(m => m.key === key);
      if (bucket) bucket.amount += inv.total || 0;
    });

  const maxVal = Math.max(...months.map(m => m.amount), 1);
  const chartH = 96;
  const barW = 38;
  const gap = 16;
  const totalW = months.length * (barW + gap) - gap + 24;

  return (
    <div className="px-5 pt-5 pb-4">
      <svg
        viewBox={`0 0 ${totalW} ${chartH + 38}`}
        className="w-full overflow-visible"
        style={{ maxHeight: 160 }}
      >
        {months.map((m, i) => {
          const barH = m.amount > 0 ? Math.max((m.amount / maxVal) * chartH, 6) : 2;
          const x = 12 + i * (barW + gap);
          const y = chartH - barH + 2;
          return (
            <g key={m.key}>
              <rect x={x} y={2} width={barW} height={chartH} rx={6} fill="#f1f5f9" />
              <rect x={x} y={y} width={barW} height={barH} rx={6} fill={m.amount > 0 ? '#f97316' : '#e2e8f0'} />
              {m.amount > 0 && (
                <text x={x + barW / 2} y={y - 5} textAnchor="middle" fill="#64748b" fontSize={9} fontWeight="600">
                  {m.amount >= 1000 ? `${(m.amount / 1000).toFixed(0)}k` : m.amount.toFixed(0)}
                </text>
              )}
              <text x={x + barW / 2} y={chartH + 20} textAnchor="middle" fill="#94a3b8" fontSize={11}>
                {m.label}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

const SOUM_STATUSES = [
  { key: 'brouillon', label: 'Brouillon', bar: '#94a3b8', badge: 'slate' as const },
  { key: 'envoyée',   label: 'Envoyée',   bar: '#3b82f6', badge: 'blue' as const },
  { key: 'approuvée', label: 'Approuvée', bar: '#10b981', badge: 'green' as const },
  { key: 'refusée',   label: 'Refusée',   bar: '#ef4444', badge: 'red' as const },
  { key: 'expirée',   label: 'Expirée',   bar: '#f59e0b', badge: 'yellow' as const },
];

function SoumissionFunnel({ soumissions }: { soumissions: SoumissionRow[] }) {
  const maxCount = Math.max(...SOUM_STATUSES.map(s => soumissions.filter(x => x.status === s.key).length), 1);
  return (
    <div className="px-4 py-3 space-y-2.5">
      {SOUM_STATUSES.map(s => {
        const items = soumissions.filter(x => x.status === s.key);
        const total = items.reduce((a, b) => a + (b.total || 0), 0);
        const pct = Math.round((items.length / maxCount) * 100);
        return (
          <div key={s.key} className="flex items-center gap-3">
            <div className="w-[82px] flex-shrink-0 text-right">
              <Badge label={s.label} color={s.badge} />
            </div>
            <div className="flex-1 bg-slate-100 rounded-full h-1.5 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${pct}%`, backgroundColor: s.bar }}
              />
            </div>
            <div className="w-[56px] text-right flex-shrink-0">
              <div className="text-xs font-semibold text-slate-700">{items.length}</div>
              {total > 0 && <div className="text-[10px] text-slate-400">{fmt(total)}</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

const INV_LABEL: Record<string, string> = {
  draft: 'Brouillon', sent: 'Envoyée', paid: 'Payée', overdue: 'En retard', cancelled: 'Annulée',
};
const INV_COLOR: Record<string, 'slate' | 'blue' | 'green' | 'red' | 'yellow'> = {
  draft: 'slate', sent: 'blue', paid: 'green', overdue: 'red', cancelled: 'slate',
};
const PRIO_LABEL: Record<string, string> = { low: 'Faible', medium: 'Normal', high: 'Haute', urgent: 'Urgent' };
const PRIO_COLOR: Record<string, 'green' | 'yellow' | 'orange' | 'red'> = {
  low: 'green', medium: 'yellow', high: 'orange', urgent: 'red',
};

export default function Dashboard() {
  const [invoices, setInvoices] = useState<InvoiceRow[]>([]);
  const [soumissions, setSoumissions] = useState<SoumissionRow[]>([]);
  const [recentInvoices, setRecentInvoices] = useState<InvoiceRow[]>([]);
  const [activities, setActivities] = useState<ActivityRow[]>([]);
  const [clientsCount, setClientsCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchAll() {
      const [
        { data: invAll },
        { data: soumAll },
        { count: cCount },
        { data: invRecent },
        { data: actData },
      ] = await Promise.all([
        supabase.from('invoices').select('id, number, status, issue_date, total, tax_amount'),
        supabase.from('soumissions').select('id, status, total, issue_date'),
        supabase.from('clients').select('*', { count: 'exact', head: true }),
        supabase
          .from('invoices')
          .select('id, number, status, issue_date, total, clients(name, company)')
          .order('created_at', { ascending: false })
          .limit(5),
        supabase
          .from('activities')
          .select('id, title, status, priority, due_date, category')
          .neq('status', 'done')
          .order('due_date', { ascending: true, nullsFirst: false })
          .limit(6),
      ]);

      setInvoices((invAll as InvoiceRow[]) ?? []);
      setSoumissions((soumAll as SoumissionRow[]) ?? []);
      setClientsCount(cCount ?? 0);
      setRecentInvoices((invRecent as InvoiceRow[]) ?? []);
      setActivities((actData as ActivityRow[]) ?? []);
      setLoading(false);
    }
    fetchAll();
  }, []);

  if (loading) return <div className="p-6"><LoadingSpinner /></div>;

  const revenue = invoices.filter(i => i.status === 'paid').reduce((s, i) => s + (i.total || 0), 0);
  const pending = invoices.filter(i => i.status === 'sent' || i.status === 'overdue').reduce((s, i) => s + (i.total || 0), 0);
  const taxesCollected = invoices.filter(i => i.status === 'paid').reduce((s, i) => s + (i.tax_amount || 0), 0);

  const pipeline = soumissions.filter(s => s.status === 'envoyée');
  const pipelineValue = pipeline.reduce((a, b) => a + (b.total || 0), 0);
  const approuvees = soumissions.filter(s => s.status === 'approuvée');
  const nonBrouillon = soumissions.filter(s => s.status !== 'brouillon');
  const tauxConversion = nonBrouillon.length > 0 ? Math.round((approuvees.length / nonBrouillon.length) * 100) : 0;

  const overdueCount = activities.filter(a => a.due_date && new Date(a.due_date) < new Date()).length;

  const navigate = (page: string) =>
    window.dispatchEvent(new CustomEvent('klirline:navigate', { detail: page }));

  return (
    <div className="p-6 space-y-6">
      {/* KPI Row 1 */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Revenus encaissés"
          value={fmt(revenue)}
          sub="factures payées"
          icon={<DollarSign size={20} className="text-emerald-600" />}
          color="bg-emerald-50"
        />
        <StatCard
          label="À recevoir"
          value={fmt(pending)}
          sub="factures envoyées / retard"
          icon={<AlertCircle size={20} className="text-amber-600" />}
          color="bg-amber-50"
        />
        <StatCard
          label="Pipeline soumissions"
          value={fmt(pipelineValue)}
          sub={`${pipeline.length} soumission${pipeline.length !== 1 ? 's' : ''} envoyée${pipeline.length !== 1 ? 's' : ''}`}
          icon={<TrendingUp size={20} className="text-blue-600" />}
          color="bg-blue-50"
        />
        <StatCard
          label="Clients"
          value={clientsCount}
          sub="comptes enregistrés"
          icon={<Users size={20} className="text-violet-600" />}
          color="bg-violet-50"
        />
      </div>

      {/* KPI Row 2 */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Taxes perçues"
          value={fmt(taxesCollected)}
          sub="TPS + TVQ (factures payées)"
          icon={<DollarSign size={20} className="text-orange-600" />}
          color="bg-orange-50"
        />
        <StatCard
          label="Soumissions"
          value={soumissions.length}
          sub="total créées"
          icon={<FileText size={20} className="text-slate-600" />}
          color="bg-slate-100"
        />
        <StatCard
          label="Approuvées"
          value={approuvees.length}
          sub={`${tauxConversion}% taux de conversion`}
          icon={<CheckCircle size={20} className="text-emerald-600" />}
          color="bg-emerald-50"
        />
        <StatCard
          label="Tâches en attente"
          value={activities.length}
          sub={overdueCount > 0 ? `${overdueCount} en retard` : 'aucune en retard'}
          icon={<ClipboardList size={20} className={overdueCount > 0 ? 'text-red-500' : 'text-slate-600'} />}
          color={overdueCount > 0 ? 'bg-red-50' : 'bg-slate-100'}
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SectionCard title="Revenus mensuels — 6 derniers mois">
            <MonthlyBarChart invoices={invoices} />
          </SectionCard>
        </div>
        <SectionCard title="Soumissions par statut">
          <SoumissionFunnel soumissions={soumissions} />
        </SectionCard>
      </div>

      {/* Detail row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent invoices */}
        <SectionCard
          title="Factures récentes"
          action={
            <button
              onClick={() => navigate('facturation')}
              className="text-xs text-orange-500 hover:text-orange-600 font-medium flex items-center gap-1 transition"
            >
              Voir tout <ArrowRight size={12} />
            </button>
          }
        >
          {recentInvoices.length === 0 ? (
            <div className="py-10 text-center text-slate-400 text-sm">Aucune facture</div>
          ) : (
            <div className="divide-y divide-slate-50">
              {recentInvoices.map(inv => {
                const client = inv.clients as any;
                return (
                  <div key={inv.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50/70 transition">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-orange-100 flex items-center justify-center flex-shrink-0">
                        <FileText size={14} className="text-orange-600" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-slate-900 truncate">
                          {client ? (client.company || client.name || '—') : '—'}
                        </div>
                        <div className="text-xs text-slate-400">{inv.number || 'Sans numéro'}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0">
                      <span className="text-sm font-semibold text-slate-700">{fmt(inv.total || 0)}</span>
                      <Badge label={INV_LABEL[inv.status] ?? inv.status} color={INV_COLOR[inv.status] ?? 'slate'} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </SectionCard>

        {/* Activities */}
        <SectionCard
          title="Tâches récentes"
          action={
            <button
              onClick={() => navigate('activites')}
              className="text-xs text-orange-500 hover:text-orange-600 font-medium flex items-center gap-1 transition"
            >
              Voir tout <ArrowRight size={12} />
            </button>
          }
        >
          {activities.length === 0 ? (
            <div className="py-10 text-center text-slate-400 text-sm">Aucune tâche en cours</div>
          ) : (
            <div className="divide-y divide-slate-50">
              {activities.map(act => {
                const isOverdue = act.due_date && new Date(act.due_date) < new Date();
                return (
                  <div key={act.id} className="flex items-center gap-3 px-5 py-3.5 hover:bg-slate-50/70 transition">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${isOverdue ? 'bg-red-100' : 'bg-slate-100'}`}>
                      <Clock size={14} className={isOverdue ? 'text-red-500' : 'text-slate-400'} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium text-slate-900 truncate">{act.title}</div>
                      <div className="text-xs text-slate-400">
                        {act.due_date
                          ? new Date(act.due_date).toLocaleDateString('fr-CA')
                          : 'Sans échéance'}
                        {act.category ? ` · ${act.category}` : ''}
                      </div>
                    </div>
                    {act.priority && (
                      <Badge
                        label={PRIO_LABEL[act.priority] ?? act.priority}
                        color={PRIO_COLOR[act.priority] ?? 'slate'}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </SectionCard>
      </div>
    </div>
  );
}
