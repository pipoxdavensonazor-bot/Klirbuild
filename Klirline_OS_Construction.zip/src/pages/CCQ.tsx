import React, { useState, useEffect, useCallback } from 'react';
import {
  HardHat, Award, FileText, AlertTriangle, Plus, Search, ChevronDown,
  X, CheckCircle, Clock, Calendar, DollarSign, Users, TrendingUp,
  RefreshCw, Download, Eye, Edit2, Trash2, AlertCircle, Shield,
  BookOpen, Zap, ChevronRight, Activity
} from 'lucide-react';
import { supabase } from '../lib/supabase';

// ── Types ─────────────────────────────────────────────────────────────────────

interface CcqCertificate {
  id: string;
  employee_id: string | null;
  numero_certificat: string;
  type_certificat: 'apprenti' | 'compagnon' | 'occupation';
  metier: string;
  specialite: string | null;
  niveau_apprentissage: number | null;
  secteur: string;
  region: string;
  date_emission: string | null;
  date_expiration: string | null;
  date_renouvellement: string | null;
  status: 'actif' | 'expiré' | 'suspendu' | 'révoqué';
  formations_obligatoires: string[];
  notes: string | null;
  created_at: string;
  // joined
  employee_name?: string;
}

interface CcqConvention {
  id: string;
  secteur: string;
  region: string;
  nom: string;
  annee: number;
  date_entree_vigueur: string | null;
  date_expiration: string | null;
  status: 'active' | 'expired' | 'pending';
  notes: string | null;
}

interface CcqWageRate {
  id: string;
  convention_id: string;
  metier: string;
  classification: string;
  taux_horaire_base: number;
  taux_vacances_pct: number;
  prime_nuit: number;
  prime_fin_semaine: number;
  prime_ferie: number;
  indemnite_deplacement: number;
  indemnite_repas: number;
  indemnite_hebergement: number;
  supp_ot_50pct_after_h: number;
  supp_ot_100pct_after_h: number;
}

interface CcqDeclaration {
  id: string;
  periode_mois: string;
  statut: 'brouillon' | 'soumis' | 'payé' | 'rejeté';
  nb_travailleurs: number;
  total_heures: number;
  total_salaires_bruts: number;
  total_cotisations_employee: number;
  total_cotisations_employer: number;
  date_soumission: string | null;
  date_paiement: string | null;
  reference_ccq: string | null;
  notes: string | null;
  created_at: string;
}

interface CnessstIncident {
  id: string;
  employee_id: string | null;
  date_incident: string;
  type_incident: 'accident' | 'quasi_accident' | 'premiers_soins' | 'temps_perdu' | 'maladie_professionnelle';
  description: string;
  nature_lesion: string | null;
  partie_corps_atteinte: string | null;
  jours_perdus: number;
  cout_estimatif: number;
  statut: 'ouvert' | 'en_enquete' | 'ferme' | 'conteste';
  date_fermeture: string | null;
  mesures_preventives: string[];
  notes: string | null;
  created_at: string;
  employee_name?: string;
}

interface PayEmployee {
  id: string;
  first_name: string;
  last_name: string;
  ccq_classification: string | null;
  ccq_number: string | null;
}

// ── Seed data ─────────────────────────────────────────────────────────────────

const SEED_CONVENTIONS: Omit<CcqConvention, 'id'>[] = [
  { secteur: 'Résidentiel', region: 'Montréal', nom: 'Convention collective résidentielle 2024', annee: 2024, date_entree_vigueur: '2024-05-01', date_expiration: '2026-04-30', status: 'active', notes: null },
  { secteur: 'CII', region: 'Montréal', nom: 'Convention collective CII 2024', annee: 2024, date_entree_vigueur: '2024-05-01', date_expiration: '2026-04-30', status: 'active', notes: null },
  { secteur: 'ITM', region: 'Montréal', nom: 'Convention collective ITM 2024', annee: 2024, date_entree_vigueur: '2024-05-01', date_expiration: '2026-04-30', status: 'active', notes: null },
  { secteur: 'Génie civil', region: 'Province', nom: 'Convention collective génie civil 2024', annee: 2024, date_entree_vigueur: '2024-05-01', date_expiration: '2026-04-30', status: 'active', notes: null },
];

// 2024 Résidentiel Montréal reference rates (approximate)
const SEED_WAGE_RATES_TEMPLATES = [
  { metier: 'Charpentier-menuisier', classification: 'compagnon', taux_horaire_base: 33.68 },
  { metier: 'Charpentier-menuisier', classification: 'apprenti_1', taux_horaire_base: 13.47 },
  { metier: 'Charpentier-menuisier', classification: 'apprenti_2', taux_horaire_base: 16.84 },
  { metier: 'Charpentier-menuisier', classification: 'apprenti_3', taux_horaire_base: 20.21 },
  { metier: 'Charpentier-menuisier', classification: 'apprenti_4', taux_horaire_base: 23.58 },
  { metier: 'Charpentier-menuisier', classification: 'apprenti_5', taux_horaire_base: 26.94 },
  { metier: 'Électricien', classification: 'compagnon', taux_horaire_base: 38.42 },
  { metier: 'Électricien', classification: 'apprenti_1', taux_horaire_base: 15.37 },
  { metier: 'Électricien', classification: 'apprenti_3', taux_horaire_base: 23.05 },
  { metier: 'Plombier', classification: 'compagnon', taux_horaire_base: 37.10 },
  { metier: 'Plombier', classification: 'apprenti_1', taux_horaire_base: 14.84 },
  { metier: 'Journalier', classification: 'compagnon', taux_horaire_base: 22.68 },
  { metier: 'Peintre', classification: 'compagnon', taux_horaire_base: 30.15 },
  { metier: 'Ferblantier', classification: 'compagnon', taux_horaire_base: 36.80 },
  { metier: 'Briqueteur-maçon', classification: 'compagnon', taux_horaire_base: 35.50 },
];

const METIERS = [
  'Charpentier-menuisier', 'Électricien', 'Plombier', 'Journalier',
  'Peintre', 'Ferblantier', 'Briqueteur-maçon', 'Couvreur', 'Cimentier-applicateur',
  'Mécanicien de chantier', 'Opérateur d\'équipement lourd', 'Tuyauteur',
  'Soudeur', 'Vitrier', 'Carreleur',
];

const REGIONS = [
  'Montréal', 'Québec', 'Mauricie', 'Estrie', 'Outaouais', 'Abitibi-Témiscamingue',
  'Côte-Nord', 'Saguenay-Lac-Saint-Jean', 'Bas-Saint-Laurent', 'Province',
];

const SECTEURS = ['Résidentiel', 'CII', 'ITM', 'Génie civil', 'Industriel'];

const CLASSIFICATIONS = [
  { value: 'compagnon', label: 'Compagnon' },
  { value: 'occupation', label: 'Occupation' },
  { value: 'apprenti_1', label: 'Apprenti — Niveau 1 (40%)' },
  { value: 'apprenti_2', label: 'Apprenti — Niveau 2 (50%)' },
  { value: 'apprenti_3', label: 'Apprenti — Niveau 3 (60%)' },
  { value: 'apprenti_4', label: 'Apprenti — Niveau 4 (70%)' },
  { value: 'apprenti_5', label: 'Apprenti — Niveau 5 (80%)' },
];

const TYPE_INCIDENT_LABELS: Record<string, string> = {
  accident: 'Accident avec lésion',
  quasi_accident: 'Quasi-accident',
  premiers_soins: 'Premiers soins seulement',
  temps_perdu: 'Accident avec temps perdu',
  maladie_professionnelle: 'Maladie professionnelle',
};

const STATUT_INCIDENT_COLORS: Record<string, string> = {
  ouvert: 'bg-red-100 text-red-700',
  en_enquete: 'bg-amber-100 text-amber-700',
  ferme: 'bg-emerald-100 text-emerald-700',
  conteste: 'bg-violet-100 text-violet-700',
};

const STATUT_DECL_COLORS: Record<string, string> = {
  brouillon: 'bg-slate-100 text-slate-600',
  soumis: 'bg-blue-100 text-blue-700',
  payé: 'bg-emerald-100 text-emerald-700',
  rejeté: 'bg-red-100 text-red-700',
};

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmtMoney(n: number) {
  return new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD' }).format(n);
}

function fmtDate(s: string | null) {
  if (!s) return '—';
  return new Date(s + (s.length === 10 ? 'T00:00:00' : '')).toLocaleDateString('fr-CA');
}

function daysUntil(dateStr: string | null): number | null {
  if (!dateStr) return null;
  const diff = new Date(dateStr + 'T00:00:00').getTime() - Date.now();
  return Math.ceil(diff / 86400000);
}

function expiryBadge(dateStr: string | null) {
  const days = daysUntil(dateStr);
  if (days === null) return null;
  if (days < 0) return <span className="text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-700 font-semibold">Expiré</span>;
  if (days <= 30) return <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 font-semibold">Expire dans {days}j</span>;
  if (days <= 90) return <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-700 font-semibold">{days}j restants</span>;
  return <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-semibold">Valide</span>;
}

// ── Modal backdrop ─────────────────────────────────────────────────────────────

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h3 className="text-lg font-bold text-slate-900">{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors"><X size={18} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-6">{children}</div>
      </div>
    </div>
  );
}

// ── Certificate Modal ──────────────────────────────────────────────────────────

function CertModal({
  cert, employees, onClose, onSave,
}: {
  cert: CcqCertificate | null;
  employees: PayEmployee[];
  onClose: () => void;
  onSave: () => void;
}) {
  const [form, setForm] = useState({
    employee_id: cert?.employee_id ?? '',
    numero_certificat: cert?.numero_certificat ?? '',
    type_certificat: cert?.type_certificat ?? 'compagnon',
    metier: cert?.metier ?? '',
    specialite: cert?.specialite ?? '',
    niveau_apprentissage: cert?.niveau_apprentissage ?? '',
    secteur: cert?.secteur ?? 'Résidentiel',
    region: cert?.region ?? 'Montréal',
    date_emission: cert?.date_emission ?? '',
    date_expiration: cert?.date_expiration ?? '',
    status: cert?.status ?? 'actif',
    notes: cert?.notes ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  async function handleSave() {
    if (!form.numero_certificat.trim()) { setErr('Numéro de certificat requis'); return; }
    if (!form.metier) { setErr('Métier requis'); return; }
    setSaving(true);
    const payload: Record<string, unknown> = {
      employee_id: form.employee_id || null,
      numero_certificat: form.numero_certificat.trim(),
      type_certificat: form.type_certificat,
      metier: form.metier,
      specialite: form.specialite || null,
      niveau_apprentissage: form.type_certificat === 'apprenti' && form.niveau_apprentissage ? Number(form.niveau_apprentissage) : null,
      secteur: form.secteur,
      region: form.region,
      date_emission: form.date_emission || null,
      date_expiration: form.date_expiration || null,
      status: form.status,
      notes: form.notes || null,
      updated_at: new Date().toISOString(),
    };
    const { error } = cert
      ? await supabase.from('ccq_certificates').update(payload).eq('id', cert.id)
      : await supabase.from('ccq_certificates').insert(payload);
    setSaving(false);
    if (error) { setErr(error.message); return; }
    onSave();
  }

  return (
    <Modal title={cert ? 'Modifier le certificat' : 'Nouveau certificat CCQ'} onClose={onClose}>
      {err && <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-700 text-sm">{err}</div>}
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="block text-xs font-semibold text-slate-600 mb-1">Employé lié</label>
            <select value={form.employee_id} onChange={e => set('employee_id', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              <option value="">— Aucun employé lié —</option>
              {employees.map(e => (
                <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Numéro de certificat *</label>
            <input value={form.numero_certificat} onChange={e => set('numero_certificat', e.target.value)}
              placeholder="ex: 12345678" className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Type</label>
            <select value={form.type_certificat} onChange={e => set('type_certificat', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              <option value="compagnon">Compagnon</option>
              <option value="apprenti">Apprenti</option>
              <option value="occupation">Occupation</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Métier *</label>
            <select value={form.metier} onChange={e => set('metier', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              <option value="">Sélectionner…</option>
              {METIERS.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          {form.type_certificat === 'apprenti' && (
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Niveau apprentissage</label>
              <select value={form.niveau_apprentissage} onChange={e => set('niveau_apprentissage', e.target.value)}
                className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
                <option value="">—</option>
                {[1,2,3,4,5].map(n => <option key={n} value={n}>Niveau {n}</option>)}
              </select>
            </div>
          )}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Secteur</label>
            <select value={form.secteur} onChange={e => set('secteur', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              {SECTEURS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Région</label>
            <select value={form.region} onChange={e => set('region', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Date d'émission</label>
            <input type="date" value={form.date_emission} onChange={e => set('date_emission', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Date d'expiration</label>
            <input type="date" value={form.date_expiration} onChange={e => set('date_expiration', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Statut</label>
            <select value={form.status} onChange={e => set('status', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              <option value="actif">Actif</option>
              <option value="expiré">Expiré</option>
              <option value="suspendu">Suspendu</option>
              <option value="révoqué">Révoqué</option>
            </select>
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-semibold text-slate-600 mb-1">Notes</label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)} rows={2}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 resize-none" />
          </div>
        </div>
        <div className="flex gap-3 pt-2">
          <button onClick={onClose} className="flex-1 py-2.5 border border-slate-200 rounded-xl text-slate-700 text-sm font-semibold hover:bg-slate-50 transition-colors">Annuler</button>
          <button onClick={handleSave} disabled={saving}
            className="flex-1 py-2.5 bg-orange-500 text-white rounded-xl text-sm font-semibold hover:bg-orange-600 disabled:opacity-60 transition-colors">
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ── Declaration Modal ─────────────────────────────────────────────────────────

function DeclModal({
  decl, onClose, onSave,
}: {
  decl: CcqDeclaration | null;
  onClose: () => void;
  onSave: () => void;
}) {
  const [form, setForm] = useState({
    periode_mois: decl?.periode_mois ?? new Date().toISOString().slice(0, 7),
    statut: decl?.statut ?? 'brouillon',
    nb_travailleurs: String(decl?.nb_travailleurs ?? '0'),
    total_heures: String(decl?.total_heures ?? '0'),
    total_salaires_bruts: String(decl?.total_salaires_bruts ?? '0'),
    total_cotisations_employee: String(decl?.total_cotisations_employee ?? '0'),
    total_cotisations_employer: String(decl?.total_cotisations_employer ?? '0'),
    reference_ccq: decl?.reference_ccq ?? '',
    notes: decl?.notes ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  async function handleSave() {
    if (!form.periode_mois) { setErr('Période requise'); return; }
    setSaving(true);
    const payload = {
      periode_mois: form.periode_mois,
      statut: form.statut,
      nb_travailleurs: Number(form.nb_travailleurs) || 0,
      total_heures: Number(form.total_heures) || 0,
      total_salaires_bruts: Number(form.total_salaires_bruts) || 0,
      total_cotisations_employee: Number(form.total_cotisations_employee) || 0,
      total_cotisations_employer: Number(form.total_cotisations_employer) || 0,
      reference_ccq: form.reference_ccq || null,
      notes: form.notes || null,
      date_soumission: form.statut !== 'brouillon' ? (decl?.date_soumission ?? new Date().toISOString()) : null,
      updated_at: new Date().toISOString(),
    };
    const { error } = decl
      ? await supabase.from('ccq_declarations').update(payload).eq('id', decl.id)
      : await supabase.from('ccq_declarations').insert(payload);
    setSaving(false);
    if (error) { setErr(error.message); return; }
    onSave();
  }

  const totalCotisations = (Number(form.total_cotisations_employee) || 0) + (Number(form.total_cotisations_employer) || 0);

  return (
    <Modal title={decl ? 'Modifier la déclaration' : 'Nouvelle déclaration CCQ'} onClose={onClose}>
      {err && <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-700 text-sm">{err}</div>}
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Période (AAAA-MM) *</label>
            <input type="month" value={form.periode_mois} onChange={e => set('periode_mois', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Statut</label>
            <select value={form.statut} onChange={e => set('statut', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              <option value="brouillon">Brouillon</option>
              <option value="soumis">Soumis</option>
              <option value="payé">Payé</option>
              <option value="rejeté">Rejeté</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Nb travailleurs</label>
            <input type="number" min="0" value={form.nb_travailleurs} onChange={e => set('nb_travailleurs', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Total heures</label>
            <input type="number" min="0" step="0.25" value={form.total_heures} onChange={e => set('total_heures', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Total salaires bruts ($)</label>
            <input type="number" min="0" step="0.01" value={form.total_salaires_bruts} onChange={e => set('total_salaires_bruts', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Cotisations employé ($)</label>
            <input type="number" min="0" step="0.01" value={form.total_cotisations_employee} onChange={e => set('total_cotisations_employee', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Cotisations employeur ($)</label>
            <input type="number" min="0" step="0.01" value={form.total_cotisations_employer} onChange={e => set('total_cotisations_employer', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Réf. CCQ e-services</label>
            <input value={form.reference_ccq} onChange={e => set('reference_ccq', e.target.value)}
              placeholder="Numéro de confirmation"
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div className="col-span-2 p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
            <span className="text-sm text-slate-600">Total cotisations combinées</span>
            <span className="text-lg font-bold text-slate-900">{fmtMoney(totalCotisations)}</span>
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-semibold text-slate-600 mb-1">Notes</label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)} rows={2}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 resize-none" />
          </div>
        </div>
        <div className="flex gap-3 pt-2">
          <button onClick={onClose} className="flex-1 py-2.5 border border-slate-200 rounded-xl text-slate-700 text-sm font-semibold hover:bg-slate-50 transition-colors">Annuler</button>
          <button onClick={handleSave} disabled={saving}
            className="flex-1 py-2.5 bg-orange-500 text-white rounded-xl text-sm font-semibold hover:bg-orange-600 disabled:opacity-60 transition-colors">
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ── Incident Modal ─────────────────────────────────────────────────────────────

function IncidentModal({
  incident, employees, onClose, onSave,
}: {
  incident: CnessstIncident | null;
  employees: PayEmployee[];
  onClose: () => void;
  onSave: () => void;
}) {
  const [form, setForm] = useState({
    employee_id: incident?.employee_id ?? '',
    date_incident: incident?.date_incident ?? new Date().toISOString().slice(0, 10),
    type_incident: incident?.type_incident ?? 'premiers_soins',
    description: incident?.description ?? '',
    nature_lesion: incident?.nature_lesion ?? '',
    partie_corps_atteinte: incident?.partie_corps_atteinte ?? '',
    jours_perdus: String(incident?.jours_perdus ?? '0'),
    cout_estimatif: String(incident?.cout_estimatif ?? '0'),
    statut: incident?.statut ?? 'ouvert',
    notes: incident?.notes ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  async function handleSave() {
    if (!form.description.trim()) { setErr('Description requise'); return; }
    if (!form.date_incident) { setErr('Date requise'); return; }
    setSaving(true);
    const payload = {
      employee_id: form.employee_id || null,
      date_incident: form.date_incident,
      type_incident: form.type_incident,
      description: form.description.trim(),
      nature_lesion: form.nature_lesion || null,
      partie_corps_atteinte: form.partie_corps_atteinte || null,
      jours_perdus: Number(form.jours_perdus) || 0,
      cout_estimatif: Number(form.cout_estimatif) || 0,
      statut: form.statut,
      date_fermeture: form.statut === 'ferme' ? (incident?.date_fermeture ?? new Date().toISOString().slice(0, 10)) : null,
      notes: form.notes || null,
      updated_at: new Date().toISOString(),
    };
    const { error } = incident
      ? await supabase.from('cnesst_incidents').update(payload).eq('id', incident.id)
      : await supabase.from('cnesst_incidents').insert(payload);
    setSaving(false);
    if (error) { setErr(error.message); return; }
    onSave();
  }

  return (
    <Modal title={incident ? 'Modifier l\'incident' : 'Déclarer un incident CNESST'} onClose={onClose}>
      {err && <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-700 text-sm">{err}</div>}
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="block text-xs font-semibold text-slate-600 mb-1">Travailleur impliqué</label>
            <select value={form.employee_id} onChange={e => set('employee_id', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              <option value="">— Travailleur non identifié —</option>
              {employees.map(e => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Date de l'incident *</label>
            <input type="date" value={form.date_incident} onChange={e => set('date_incident', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Type d'incident</label>
            <select value={form.type_incident} onChange={e => set('type_incident', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              {Object.entries(TYPE_INCIDENT_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-semibold text-slate-600 mb-1">Description *</label>
            <textarea value={form.description} onChange={e => set('description', e.target.value)} rows={3}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 resize-none" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Nature de la lésion</label>
            <select value={form.nature_lesion} onChange={e => set('nature_lesion', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              <option value="">—</option>
              {['contusion','coupure','fracture','brulure','entorse','strain','autre'].map(v => (
                <option key={v} value={v}>{v.charAt(0).toUpperCase() + v.slice(1)}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Partie du corps atteinte</label>
            <input value={form.partie_corps_atteinte} onChange={e => set('partie_corps_atteinte', e.target.value)}
              placeholder="ex: Main droite, Dos, Œil…"
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Jours perdus</label>
            <input type="number" min="0" value={form.jours_perdus} onChange={e => set('jours_perdus', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Coût estimatif ($)</label>
            <input type="number" min="0" step="0.01" value={form.cout_estimatif} onChange={e => set('cout_estimatif', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Statut</label>
            <select value={form.statut} onChange={e => set('statut', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
              <option value="ouvert">Ouvert</option>
              <option value="en_enquete">En enquête</option>
              <option value="ferme">Fermé</option>
              <option value="conteste">Contesté</option>
            </select>
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-semibold text-slate-600 mb-1">Notes / mesures correctives</label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)} rows={2}
              className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 resize-none" />
          </div>
        </div>
        <div className="flex gap-3 pt-2">
          <button onClick={onClose} className="flex-1 py-2.5 border border-slate-200 rounded-xl text-slate-700 text-sm font-semibold hover:bg-slate-50 transition-colors">Annuler</button>
          <button onClick={handleSave} disabled={saving}
            className="flex-1 py-2.5 bg-orange-500 text-white rounded-xl text-sm font-semibold hover:bg-orange-600 disabled:opacity-60 transition-colors">
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ── Wage Calculator ────────────────────────────────────────────────────────────

function WageCalculator({ rates }: { rates: CcqWageRate[] }) {
  const [selRate, setSelRate] = useState<CcqWageRate | null>(null);
  const [hours, setHours] = useState('8');
  const [shift, setShift] = useState<'normal' | 'nuit' | 'fin_semaine' | 'ferie'>('normal');

  const r = selRate;
  const h = Number(hours) || 0;

  function calcPay() {
    if (!r || h <= 0) return null;
    const base = r.taux_horaire_base;
    const prime = shift === 'nuit' ? r.prime_nuit : shift === 'fin_semaine' ? r.prime_fin_semaine : shift === 'ferie' ? r.prime_ferie : 0;
    const effective = base + prime;
    const normalH = Math.min(h, r.supp_ot_50pct_after_h);
    const ot1H = Math.max(0, Math.min(h, r.supp_ot_100pct_after_h) - r.supp_ot_50pct_after_h);
    const ot2H = Math.max(0, h - r.supp_ot_100pct_after_h);
    const gross = normalH * effective + ot1H * effective * 1.5 + ot2H * effective * 2;
    const vac = gross * (r.taux_vacances_pct / 100);
    return { gross, vac, total: gross + vac, normalH, ot1H, ot2H, effective };
  }

  const calc = calcPay();

  return (
    <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
      <div className="flex items-center gap-2 mb-4">
        <Zap size={16} className="text-orange-500" />
        <span className="font-bold text-slate-900 text-sm">Calculateur rapide</span>
      </div>
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="col-span-2">
          <label className="block text-xs font-semibold text-slate-600 mb-1">Taux salarial</label>
          <select value={selRate?.id ?? ''} onChange={e => setSelRate(rates.find(r => r.id === e.target.value) ?? null)}
            className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white">
            <option value="">Sélectionner métier / classification…</option>
            {rates.map(r => (
              <option key={r.id} value={r.id}>
                {r.metier} — {CLASSIFICATIONS.find(c => c.value === r.classification)?.label ?? r.classification} ({fmtMoney(r.taux_horaire_base)}/h)
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-600 mb-1">Heures travaillées</label>
          <input type="number" min="0" max="24" step="0.5" value={hours} onChange={e => setHours(e.target.value)}
            className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white" />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-600 mb-1">Type de quart</label>
          <select value={shift} onChange={e => setShift(e.target.value as typeof shift)}
            className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white">
            <option value="normal">Normal</option>
            <option value="nuit">Nuit</option>
            <option value="fin_semaine">Fin de semaine</option>
            <option value="ferie">Férié</option>
          </select>
        </div>
      </div>
      {calc && selRate ? (
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-slate-500">
            <span>Taux effectif</span>
            <span className="font-semibold text-slate-700">{fmtMoney(calc.effective)}/h</span>
          </div>
          {calc.normalH > 0 && (
            <div className="flex justify-between text-xs text-slate-500">
              <span>{calc.normalH.toFixed(2)}h × {fmtMoney(calc.effective)}</span>
              <span>{fmtMoney(calc.normalH * calc.effective)}</span>
            </div>
          )}
          {calc.ot1H > 0 && (
            <div className="flex justify-between text-xs text-amber-600">
              <span>{calc.ot1H.toFixed(2)}h × {fmtMoney(calc.effective * 1.5)} (1.5×)</span>
              <span>{fmtMoney(calc.ot1H * calc.effective * 1.5)}</span>
            </div>
          )}
          {calc.ot2H > 0 && (
            <div className="flex justify-between text-xs text-red-600">
              <span>{calc.ot2H.toFixed(2)}h × {fmtMoney(calc.effective * 2)} (2×)</span>
              <span>{fmtMoney(calc.ot2H * calc.effective * 2)}</span>
            </div>
          )}
          <div className="flex justify-between text-xs text-slate-500">
            <span>Vacances ({selRate.taux_vacances_pct}%)</span>
            <span>{fmtMoney(calc.vac)}</span>
          </div>
          <div className="flex justify-between font-bold text-sm text-slate-900 pt-2 border-t border-slate-200">
            <span>Total brut</span>
            <span className="text-orange-600">{fmtMoney(calc.total)}</span>
          </div>
        </div>
      ) : (
        <p className="text-xs text-slate-400 text-center py-4">Sélectionnez un taux pour calculer</p>
      )}
    </div>
  );
}

// ── Tab: Certificats ──────────────────────────────────────────────────────────

function CertificatsTab({ employees }: { employees: PayEmployee[] }) {
  const [certs, setCerts] = useState<CcqCertificate[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editCert, setEditCert] = useState<CcqCertificate | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('ccq_certificates').select('*').order('created_at', { ascending: false });
    if (data) {
      const enriched = data.map(c => ({
        ...c,
        employee_name: employees.find(e => e.id === c.employee_id)
          ? `${employees.find(e => e.id === c.employee_id)!.first_name} ${employees.find(e => e.id === c.employee_id)!.last_name}`
          : null,
      }));
      setCerts(enriched as CcqCertificate[]);
    }
    setLoading(false);
  }, [employees]);

  useEffect(() => { load(); }, [load]);

  async function deleteCert(id: string) {
    if (!confirm('Supprimer ce certificat ?')) return;
    await supabase.from('ccq_certificates').delete().eq('id', id);
    load();
  }

  const filtered = certs.filter(c => {
    const q = search.toLowerCase();
    const matchQ = !q || c.numero_certificat.toLowerCase().includes(q) || c.metier.toLowerCase().includes(q) || (c.employee_name ?? '').toLowerCase().includes(q);
    const matchS = !filterStatus || c.status === filterStatus;
    return matchQ && matchS;
  });

  const expiringSoon = certs.filter(c => { const d = daysUntil(c.date_expiration); return d !== null && d >= 0 && d <= 30; });
  const expired = certs.filter(c => { const d = daysUntil(c.date_expiration); return d !== null && d < 0; });

  return (
    <div className="space-y-6">
      {/* Alerts */}
      {(expiringSoon.length > 0 || expired.length > 0) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {expired.length > 0 && (
            <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-2xl">
              <AlertCircle size={18} className="text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-red-800 text-sm">{expired.length} certificat{expired.length > 1 ? 's' : ''} expiré{expired.length > 1 ? 's' : ''}</p>
                <p className="text-red-600 text-xs mt-0.5">Action requise — renouvellement immédiat</p>
              </div>
            </div>
          )}
          {expiringSoon.length > 0 && (
            <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-2xl">
              <AlertTriangle size={18} className="text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-amber-800 text-sm">{expiringSoon.length} certificat{expiringSoon.length > 1 ? 's' : ''} expire dans 30 jours</p>
                <p className="text-amber-600 text-xs mt-0.5">Planifier le renouvellement rapidement</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher numéro, métier, employé…"
            className="w-full pl-9 pr-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white" />
        </div>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white">
          <option value="">Tous les statuts</option>
          <option value="actif">Actif</option>
          <option value="expiré">Expiré</option>
          <option value="suspendu">Suspendu</option>
          <option value="révoqué">Révoqué</option>
        </select>
        <button onClick={() => { setEditCert(null); setShowModal(true); }}
          className="flex items-center gap-2 px-4 py-2.5 bg-orange-500 text-white rounded-xl text-sm font-semibold hover:bg-orange-600 transition-colors">
          <Plus size={16} /> Nouveau certificat
        </button>
      </div>

      {/* List */}
      {loading ? (
        <div className="text-center py-16 text-slate-400 text-sm">Chargement…</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <Award size={40} className="mx-auto text-slate-300 mb-3" />
          <p className="text-slate-500 font-semibold">Aucun certificat CCQ</p>
          <p className="text-slate-400 text-sm mt-1">Ajoutez les certificats de compétence de vos travailleurs</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Certificat</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Travailleur</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Métier / Classification</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Secteur / Région</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Expiration</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Statut</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(c => (
                <tr key={c.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="font-semibold text-slate-900">{c.numero_certificat}</div>
                    <div className="text-xs text-slate-500 capitalize">{c.type_certificat}{c.niveau_apprentissage ? ` — Niv. ${c.niveau_apprentissage}` : ''}</div>
                  </td>
                  <td className="px-4 py-3 text-slate-700">{c.employee_name ?? <span className="text-slate-400 italic">Non assigné</span>}</td>
                  <td className="px-4 py-3">
                    <div className="font-medium text-slate-900">{c.metier}</div>
                    {c.specialite && <div className="text-xs text-slate-500">{c.specialite}</div>}
                  </td>
                  <td className="px-4 py-3 text-slate-600 text-xs">{c.secteur}<br />{c.region}</td>
                  <td className="px-4 py-3">
                    <div className="text-slate-700 text-xs mb-1">{fmtDate(c.date_expiration)}</div>
                    {expiryBadge(c.date_expiration)}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-semibold capitalize ${
                      c.status === 'actif' ? 'bg-emerald-100 text-emerald-700' :
                      c.status === 'expiré' ? 'bg-red-100 text-red-700' :
                      c.status === 'suspendu' ? 'bg-amber-100 text-amber-700' :
                      'bg-slate-100 text-slate-600'
                    }`}>{c.status}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => { setEditCert(c); setShowModal(true); }}
                        className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors">
                        <Edit2 size={14} />
                      </button>
                      <button onClick={() => deleteCert(c.id)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition-colors">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <CertModal cert={editCert} employees={employees} onClose={() => setShowModal(false)} onSave={() => { setShowModal(false); load(); }} />
      )}
    </div>
  );
}

// ── Tab: Conventions & Taux ───────────────────────────────────────────────────

function ConventionsTab() {
  const [conventions, setConventions] = useState<CcqConvention[]>([]);
  const [wageRates, setWageRates] = useState<CcqWageRate[]>([]);
  const [selConv, setSelConv] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [seeding, setSeeding] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: convs }, { data: wages }] = await Promise.all([
      supabase.from('ccq_conventions').select('*').order('annee', { ascending: false }),
      supabase.from('ccq_wage_rates').select('*').order('metier'),
    ]);
    const convList = (convs ?? []) as CcqConvention[];
    setConventions(convList);
    setWageRates((wages ?? []) as CcqWageRate[]);
    if (convList.length > 0 && !selConv) setSelConv(convList[0].id);
    setLoading(false);
  }, [selConv]);

  useEffect(() => { load(); }, [load]);

  async function seedData() {
    setSeeding(true);
    const { data: inserted } = await supabase.from('ccq_conventions').insert(SEED_CONVENTIONS).select('id, secteur');
    if (inserted && inserted.length > 0) {
      const resConvId = inserted.find((c: { secteur: string }) => c.secteur === 'Résidentiel')?.id;
      if (resConvId) {
        const wagePayload = SEED_WAGE_RATES_TEMPLATES.map(w => ({
          convention_id: resConvId,
          metier: w.metier,
          classification: w.classification,
          taux_horaire_base: w.taux_horaire_base,
          taux_vacances_pct: 8.33,
          prime_nuit: 2.50,
          prime_fin_semaine: 3.00,
          prime_ferie: 0,
          indemnite_deplacement: 21.80,
          indemnite_repas: 13.50,
          indemnite_hebergement: 0,
          supp_ot_50pct_after_h: 8,
          supp_ot_100pct_after_h: 10,
        }));
        await supabase.from('ccq_wage_rates').insert(wagePayload);
      }
      await supabase.from('ccq_social_contributions').insert(
        inserted.map((c: { id: string }) => ({ convention_id: c.id }))
      );
    }
    await load();
    setSeeding(false);
  }

  const convRates = wageRates.filter(r => r.convention_id === selConv);
  const selectedConv = conventions.find(c => c.id === selConv);

  if (loading) return <div className="text-center py-16 text-slate-400 text-sm">Chargement…</div>;

  if (conventions.length === 0) {
    return (
      <div className="text-center py-20">
        <BookOpen size={40} className="mx-auto text-slate-300 mb-3" />
        <p className="text-slate-500 font-semibold text-lg">Aucune convention chargée</p>
        <p className="text-slate-400 text-sm mt-1 mb-6">Chargez les conventions CCQ 2024 pour accéder aux taux salariaux de référence</p>
        <button onClick={seedData} disabled={seeding}
          className="inline-flex items-center gap-2 px-6 py-3 bg-orange-500 text-white rounded-xl font-semibold hover:bg-orange-600 disabled:opacity-60 transition-colors">
          {seeding ? <><RefreshCw size={16} className="animate-spin" /> Chargement…</> : <><Download size={16} /> Charger données CCQ 2024</>}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Convention selector */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {conventions.map(c => (
          <button key={c.id} onClick={() => setSelConv(c.id)}
            className={`p-4 rounded-2xl border-2 text-left transition-all ${
              selConv === c.id ? 'border-orange-400 bg-orange-50' : 'border-slate-200 bg-white hover:border-slate-300'
            }`}>
            <div className="font-bold text-slate-900 text-sm">{c.secteur}</div>
            <div className="text-xs text-slate-500 mt-0.5">{c.region}</div>
            <div className="text-xs text-slate-400 mt-1">{c.annee}</div>
            <span className={`text-xs px-1.5 py-0.5 rounded-full font-semibold mt-2 inline-block ${
              c.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'
            }`}>{c.status === 'active' ? 'Active' : c.status}</span>
          </button>
        ))}
      </div>

      {selectedConv && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Wage rates table */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-slate-900 text-sm">{selectedConv.nom}</h4>
                <p className="text-xs text-slate-500 mt-0.5">En vigueur depuis le {fmtDate(selectedConv.date_entree_vigueur)}</p>
              </div>
            </div>
            {convRates.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-sm">Aucun taux défini pour cette convention</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Métier</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Classification</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Taux base</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase">+ Vacances</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Prime nuit</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Indemnité dép.</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {convRates.map(r => (
                      <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-2.5 font-medium text-slate-900">{r.metier}</td>
                        <td className="px-4 py-2.5 text-slate-600 text-xs">{CLASSIFICATIONS.find(c => c.value === r.classification)?.label ?? r.classification}</td>
                        <td className="px-4 py-2.5 text-right font-semibold text-slate-900">{fmtMoney(r.taux_horaire_base)}/h</td>
                        <td className="px-4 py-2.5 text-right text-slate-500 text-xs">{r.taux_vacances_pct}%</td>
                        <td className="px-4 py-2.5 text-right text-slate-500 text-xs">{r.prime_nuit > 0 ? fmtMoney(r.prime_nuit) : '—'}</td>
                        <td className="px-4 py-2.5 text-right text-slate-500 text-xs">{r.indemnite_deplacement > 0 ? fmtMoney(r.indemnite_deplacement) : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Calculator */}
          <WageCalculator rates={convRates} />
        </div>
      )}
    </div>
  );
}

// ── Tab: Déclarations ─────────────────────────────────────────────────────────

function DeclarationsTab() {
  const [decls, setDecls] = useState<CcqDeclaration[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editDecl, setEditDecl] = useState<CcqDeclaration | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('ccq_declarations').select('*').order('periode_mois', { ascending: false });
    setDecls((data ?? []) as CcqDeclaration[]);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function deleteDecl(id: string) {
    if (!confirm('Supprimer cette déclaration ?')) return;
    await supabase.from('ccq_declarations').delete().eq('id', id);
    load();
  }

  const totalSalaires = decls.reduce((s, d) => s + d.total_salaires_bruts, 0);
  const totalCotisations = decls.reduce((s, d) => s + d.total_cotisations_employee + d.total_cotisations_employer, 0);
  const ytdHeures = decls.filter(d => d.periode_mois.startsWith(String(new Date().getFullYear()))).reduce((s, d) => s + d.total_heures, 0);

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total salaires déclarés', value: fmtMoney(totalSalaires), icon: DollarSign, color: 'text-emerald-500' },
          { label: 'Total cotisations CCQ', value: fmtMoney(totalCotisations), icon: TrendingUp, color: 'text-orange-500' },
          { label: 'Heures déclarées (année)', value: ytdHeures.toFixed(0) + 'h', icon: Clock, color: 'text-blue-500' },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-2xl p-4 border border-slate-200">
            <div className={`${s.color} mb-2`}><s.icon size={18} /></div>
            <div className="text-xl font-bold text-slate-900">{s.value}</div>
            <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex justify-end">
        <button onClick={() => { setEditDecl(null); setShowModal(true); }}
          className="flex items-center gap-2 px-4 py-2.5 bg-orange-500 text-white rounded-xl text-sm font-semibold hover:bg-orange-600 transition-colors">
          <Plus size={16} /> Nouvelle déclaration
        </button>
      </div>

      {loading ? (
        <div className="text-center py-16 text-slate-400 text-sm">Chargement…</div>
      ) : decls.length === 0 ? (
        <div className="text-center py-20">
          <FileText size={40} className="mx-auto text-slate-300 mb-3" />
          <p className="text-slate-500 font-semibold">Aucune déclaration CCQ</p>
          <p className="text-slate-400 text-sm mt-1">Créez votre première déclaration mensuelle</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Période</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Travailleurs</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Heures</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Salaires bruts</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Cotisations</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Statut</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase">Réf. CCQ</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {decls.map(d => (
                <tr key={d.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 font-semibold text-slate-900">{d.periode_mois}</td>
                  <td className="px-4 py-3 text-right text-slate-700">{d.nb_travailleurs}</td>
                  <td className="px-4 py-3 text-right text-slate-700">{d.total_heures.toFixed(1)}h</td>
                  <td className="px-4 py-3 text-right font-semibold text-slate-900">{fmtMoney(d.total_salaires_bruts)}</td>
                  <td className="px-4 py-3 text-right text-slate-700">{fmtMoney(d.total_cotisations_employee + d.total_cotisations_employer)}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-semibold capitalize ${STATUT_DECL_COLORS[d.statut] ?? 'bg-slate-100 text-slate-600'}`}>
                      {d.statut}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs">{d.reference_ccq ?? '—'}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => { setEditDecl(d); setShowModal(true); }}
                        className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors">
                        <Edit2 size={14} />
                      </button>
                      <button onClick={() => deleteDecl(d.id)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition-colors">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <DeclModal decl={editDecl} onClose={() => setShowModal(false)} onSave={() => { setShowModal(false); load(); }} />
      )}
    </div>
  );
}

// ── Tab: CNESST ───────────────────────────────────────────────────────────────

function CnesstTab({ employees }: { employees: PayEmployee[] }) {
  const [incidents, setIncidents] = useState<CnessstIncident[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editIncident, setEditIncident] = useState<CnessstIncident | null>(null);
  const [filterStatut, setFilterStatut] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('cnesst_incidents').select('*').order('date_incident', { ascending: false });
    if (data) {
      const enriched = data.map(i => ({
        ...i,
        employee_name: employees.find(e => e.id === i.employee_id)
          ? `${employees.find(e => e.id === i.employee_id)!.first_name} ${employees.find(e => e.id === i.employee_id)!.last_name}`
          : null,
      }));
      setIncidents(enriched as CnessstIncident[]);
    }
    setLoading(false);
  }, [employees]);

  useEffect(() => { load(); }, [load]);

  async function deleteIncident(id: string) {
    if (!confirm('Supprimer cet incident ?')) return;
    await supabase.from('cnesst_incidents').delete().eq('id', id);
    load();
  }

  const filtered = filterStatut ? incidents.filter(i => i.statut === filterStatut) : incidents;

  const ytd = incidents.filter(i => i.date_incident.startsWith(String(new Date().getFullYear())));
  const jours = ytd.reduce((s, i) => s + i.jours_perdus, 0);
  const ouverts = incidents.filter(i => i.statut === 'ouvert' || i.statut === 'en_enquete').length;
  const cout = incidents.reduce((s, i) => s + i.cout_estimatif, 0);

  // Frequency rate (simplified): (incidents × 200,000) / total hours worked (using 40h/week × 50 weeks × ouverts+fermes)
  const tauxFreq = ytd.length > 0 ? ((ytd.length * 200000) / Math.max(ytd.length * 2000, 1)).toFixed(1) : '0.0';

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Incidents YTD', value: String(ytd.length), icon: Activity, color: 'text-red-500', bg: 'bg-red-50' },
          { label: 'Jours perdus YTD', value: String(jours), icon: Calendar, color: 'text-amber-500', bg: 'bg-amber-50' },
          { label: 'Dossiers ouverts', value: String(ouverts), icon: AlertCircle, color: 'text-orange-500', bg: 'bg-orange-50' },
          { label: 'Coût estimatif', value: fmtMoney(cout), icon: DollarSign, color: 'text-slate-500', bg: 'bg-slate-50' },
        ].map(s => (
          <div key={s.label} className={`${s.bg} rounded-2xl p-4 border border-slate-200`}>
            <div className={`${s.color} mb-2`}><s.icon size={18} /></div>
            <div className="text-xl font-bold text-slate-900">{s.value}</div>
            <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Safety message */}
      {ouverts === 0 && incidents.length > 0 && (
        <div className="flex items-center gap-3 p-4 bg-emerald-50 border border-emerald-200 rounded-2xl">
          <CheckCircle size={18} className="text-emerald-500 flex-shrink-0" />
          <div>
            <p className="font-bold text-emerald-800 text-sm">Aucun dossier CNESST ouvert</p>
            <p className="text-emerald-600 text-xs">Tous les incidents sont fermés ou résolus</p>
          </div>
        </div>
      )}

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between">
        <select value={filterStatut} onChange={e => setFilterStatut(e.target.value)}
          className="border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white">
          <option value="">Tous les statuts ({incidents.length})</option>
          <option value="ouvert">Ouverts</option>
          <option value="en_enquete">En enquête</option>
          <option value="ferme">Fermés</option>
          <option value="conteste">Contestés</option>
        </select>
        <button onClick={() => { setEditIncident(null); setShowModal(true); }}
          className="flex items-center gap-2 px-4 py-2.5 bg-orange-500 text-white rounded-xl text-sm font-semibold hover:bg-orange-600 transition-colors">
          <Plus size={16} /> Déclarer un incident
        </button>
      </div>

      {loading ? (
        <div className="text-center py-16 text-slate-400 text-sm">Chargement…</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <Shield size={40} className="mx-auto text-slate-300 mb-3" />
          <p className="text-slate-500 font-semibold">Aucun incident CNESST</p>
          <p className="text-slate-400 text-sm mt-1">Déclarez un incident ou accident pour assurer la traçabilité</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(i => (
            <div key={i.id} className="bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${STATUT_INCIDENT_COLORS[i.statut] ?? 'bg-slate-100 text-slate-600'}`}>
                      {i.statut.replace('_', ' ')}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">
                      {TYPE_INCIDENT_LABELS[i.type_incident]}
                    </span>
                    {i.jours_perdus > 0 && (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-700 font-semibold">
                        {i.jours_perdus} jour{i.jours_perdus > 1 ? 's' : ''} perdu{i.jours_perdus > 1 ? 's' : ''}
                      </span>
                    )}
                  </div>
                  <p className="font-semibold text-slate-900 mb-1">{i.description}</p>
                  <div className="flex items-center gap-4 text-xs text-slate-500">
                    <span className="flex items-center gap-1"><Calendar size={11} />{fmtDate(i.date_incident)}</span>
                    {i.employee_name && <span className="flex items-center gap-1"><Users size={11} />{i.employee_name}</span>}
                    {i.nature_lesion && <span className="capitalize">{i.nature_lesion}{i.partie_corps_atteinte ? ` — ${i.partie_corps_atteinte}` : ''}</span>}
                    {i.cout_estimatif > 0 && <span>{fmtMoney(i.cout_estimatif)}</span>}
                  </div>
                  {i.notes && <p className="text-xs text-slate-400 mt-2 italic">{i.notes}</p>}
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => { setEditIncident(i); setShowModal(true); }}
                    className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors">
                    <Edit2 size={14} />
                  </button>
                  <button onClick={() => deleteIncident(i.id)}
                    className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition-colors">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Taux de fréquence */}
      {incidents.length > 0 && (
        <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
          <h4 className="font-bold text-slate-900 text-sm mb-3 flex items-center gap-2">
            <TrendingUp size={16} className="text-orange-500" />
            Indicateurs SST (Santé et Sécurité au travail)
          </h4>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <div className="text-2xl font-bold text-slate-900">{tauxFreq}</div>
              <div className="text-xs text-slate-500">Taux de fréquence (p. 200k h)</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">{jours}</div>
              <div className="text-xs text-slate-500">Jours perdus total YTD</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">{ytd.filter(i => i.type_incident === 'accident' || i.type_incident === 'temps_perdu').length}</div>
              <div className="text-xs text-slate-500">Accidents avec lésion YTD</div>
            </div>
          </div>
        </div>
      )}

      {showModal && (
        <IncidentModal incident={editIncident} employees={employees} onClose={() => setShowModal(false)} onSave={() => { setShowModal(false); load(); }} />
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

type Tab = 'certificats' | 'conventions' | 'declarations' | 'cnesst';

export default function CcqPage() {
  const [tab, setTab] = useState<Tab>('certificats');
  const [employees, setEmployees] = useState<PayEmployee[]>([]);

  useEffect(() => {
    supabase.from('payroll_employees')
      .select('id, first_name, last_name, ccq_classification, ccq_number')
      .eq('status', 'active')
      .order('last_name')
      .then(({ data }) => setEmployees((data ?? []) as PayEmployee[]));
  }, []);

  const TABS: { id: Tab; label: string; icon: React.FC<{ size?: number; className?: string }> }[] = [
    { id: 'certificats', label: 'Certificats CCQ', icon: Award },
    { id: 'conventions', label: 'Conventions & Taux', icon: BookOpen },
    { id: 'declarations', label: 'Déclarations', icon: FileText },
    { id: 'cnesst', label: 'CNESST', icon: Shield },
  ];

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-orange-500 flex items-center justify-center shadow-md shadow-orange-200">
              <HardHat size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-xl font-black text-slate-900">Module CCQ</h1>
              <p className="text-slate-500 text-sm">Commission de la construction du Québec — conformité et gestion</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-full">
            <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
            <span className="text-xs font-semibold text-blue-700">Données CCQ 2024</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-slate-200 px-6">
        <div className="flex gap-1">
          {TABS.map(t => {
            const Icon = t.icon;
            return (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 px-4 py-3.5 text-sm font-semibold border-b-2 transition-colors ${
                  tab === t.id
                    ? 'border-orange-500 text-orange-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}>
                <Icon size={15} />
                {t.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {tab === 'certificats' && <CertificatsTab employees={employees} />}
        {tab === 'conventions' && <ConventionsTab />}
        {tab === 'declarations' && <DeclarationsTab />}
        {tab === 'cnesst' && <CnesstTab employees={employees} />}
      </div>
    </div>
  );
}
