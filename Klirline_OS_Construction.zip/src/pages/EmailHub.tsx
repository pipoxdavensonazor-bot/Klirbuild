import { useEffect, useState, useCallback } from 'react';
import {
  Mail, Inbox, Send, Edit3, Search, Plus, RefreshCw,
  Wifi, WifiOff, Trash2, Reply, ChevronLeft, AlertCircle, CheckCircle,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import Header from '../components/Header';
import { Modal, EmptyState, LoadingSpinner, FormField, inputCls, textareaCls } from '../components/ui';

// ── Types ─────────────────────────────────────────────────────────────────────

interface GmailMessage {
  id: string;
  threadId: string;
  from: string;
  to: string;
  subject: string;
  date: string;
  snippet: string;
  body?: string;
  isUnread: boolean;
  labelIds: string[];
}

interface LocalEmail {
  id: string;
  direction: 'inbound' | 'outbound';
  from_addr: string;
  to_addr: string;
  subject: string;
  body: string | null;
  status: 'draft' | 'sent' | 'received';
  created_at: string;
}

type Folder = 'inbox' | 'sent' | 'draft';

// ── Helpers ───────────────────────────────────────────────────────────────────

function displayName(addr: string): string {
  const match = addr.match(/^(.+?)\s*<[^>]+>$/);
  return match ? match[1].trim() : addr;
}

function fmtDate(d: string): string {
  if (!d) return '';
  const date = new Date(d);
  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();
  if (isToday) return date.toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit' });
  return date.toLocaleDateString('fr-CA', { month: 'short', day: 'numeric' });
}

// ── Gmail proxy helper ────────────────────────────────────────────────────────

async function gmailProxy<T>(session: string, action: string, extra: Record<string, unknown> = {}): Promise<T> {
  const { data, error } = await supabase.functions.invoke('gmail-proxy', {
    body: { action, ...extra },
    headers: { Authorization: `Bearer ${session}` },
  });
  if (error) throw error;
  return data as T;
}

// ── Connection banner ─────────────────────────────────────────────────────────

function ConnectGmailBanner({ onConnect }: { onConnect: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center flex-1 p-8 text-center">
      <div className="w-16 h-16 rounded-2xl bg-red-50 border border-red-100 flex items-center justify-center mb-4">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
        </svg>
      </div>
      <h3 className="text-slate-900 font-bold text-base mb-1">Connectez votre Gmail</h3>
      <p className="text-slate-500 text-sm mb-5 max-w-xs">
        Lisez et envoyez vos courriels directement depuis Klirline OS sans quitter l'application.
      </p>
      <button
        onClick={onConnect}
        className="flex items-center gap-2 px-5 py-2.5 bg-white border-2 border-slate-200 hover:border-slate-400 rounded-xl text-slate-700 font-semibold text-sm transition shadow-sm"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
        </svg>
        Connecter Gmail
      </button>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

export default function EmailHubPage() {
  const { session } = useAuth();

  // Gmail connection state
  const [gmailConnected, setGmailConnected] = useState(false);
  const [gmailEmail, setGmailEmail] = useState('');
  const [connectingGmail, setConnectingGmail] = useState(false);

  // Email list state
  const [messages, setMessages] = useState<GmailMessage[]>([]);
  const [localEmails, setLocalEmails] = useState<LocalEmail[]>([]);
  const [loading, setLoading] = useState(false);
  const [folder, setFolder] = useState<Folder>('inbox');
  const [selected, setSelected] = useState<GmailMessage | null>(null);
  const [selectedBody, setSelectedBody] = useState('');
  const [loadingBody, setLoadingBody] = useState(false);
  const [search, setSearch] = useState('');

  // Compose state
  const [showCompose, setShowCompose] = useState(false);
  const [composeForm, setComposeForm] = useState({ to: '', subject: '', body: '' });
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');

  // Toast
  const [toast, setToast] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  const showToast = (type: 'success' | 'error', msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 3500);
  };

  // ── Check Gmail connection on mount + handle OAuth callback ────────────────
  useEffect(() => {
    if (!session?.access_token) return;

    const params = new URLSearchParams(window.location.search);
    if (params.get('gmail_connected') === 'true') {
      const email = params.get('gmail_email') ?? '';
      setGmailConnected(true);
      setGmailEmail(email);
      showToast('success', `Gmail connecté : ${email}`);
      window.history.replaceState({}, '', window.location.pathname);
    } else if (params.get('gmail_error')) {
      const err = params.get('gmail_error');
      showToast('error', `Erreur connexion Gmail : ${err}`);
      window.history.replaceState({}, '', window.location.pathname);
    }

    // Check existing connection
    gmailProxy<{ connected: boolean; accounts: Array<{ gmail_email: string }> }>(
      session.access_token, 'get_status'
    ).then(({ connected, accounts }) => {
      setGmailConnected(connected);
      if (connected && accounts.length > 0) setGmailEmail(accounts[0].gmail_email);
    }).catch(() => {});
  }, [session?.access_token]);

  // ── Fetch emails whenever folder or connection changes ─────────────────────
  const fetchEmails = useCallback(async () => {
    if (!session?.access_token) return;
    setLoading(true);
    setSelected(null);

    if (gmailConnected) {
      try {
        const { messages: msgs } = await gmailProxy<{ messages: GmailMessage[] }>(
          session.access_token, 'list_messages', { folder }
        );
        setMessages(msgs ?? []);
      } catch {
        showToast('error', 'Impossible de charger les courriels Gmail.');
      }
    } else {
      const { data } = await supabase
        .from('emails')
        .select('*')
        .order('created_at', { ascending: false });
      setLocalEmails((data as LocalEmail[]) ?? []);
    }

    setLoading(false);
  }, [session?.access_token, gmailConnected, folder]);

  useEffect(() => { fetchEmails(); }, [fetchEmails]);

  // ── Load full message body when selected ───────────────────────────────────
  useEffect(() => {
    if (!selected || !session?.access_token) return;
    setLoadingBody(true);
    setSelectedBody('');
    gmailProxy<{ body: string }>(session.access_token, 'get_message', { messageId: selected.id })
      .then(({ body }) => setSelectedBody(body ?? selected.snippet))
      .catch(() => setSelectedBody(selected.snippet))
      .finally(() => setLoadingBody(false));
  }, [selected?.id]);

  // ── Connect Gmail ──────────────────────────────────────────────────────────
  const handleConnectGmail = async () => {
    if (!session?.access_token) return;
    setConnectingGmail(true);
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
      const resp = await fetch(`${supabaseUrl}/functions/v1/gmail-oauth?action=auth-url`, {
        headers: { Authorization: `Bearer ${session.access_token}` },
      });
      const data = await resp.json();
      if (!resp.ok || data.error) throw new Error(data.error ?? 'Erreur connexion');
      if (data.url) window.location.href = data.url;
    } catch (e: unknown) {
      showToast('error', (e as Error)?.message ?? 'Impossible de démarrer la connexion Gmail.');
      setConnectingGmail(false);
    }
  };

  // ── Disconnect Gmail ───────────────────────────────────────────────────────
  const handleDisconnect = async () => {
    if (!session?.access_token || !confirm('Déconnecter ce compte Gmail ?')) return;
    await gmailProxy(session.access_token, 'disconnect');
    setGmailConnected(false);
    setGmailEmail('');
    setMessages([]);
    showToast('success', 'Gmail déconnecté.');
  };

  // ── Send email ─────────────────────────────────────────────────────────────
  const handleSend = async () => {
    if (!composeForm.to || !composeForm.subject) return;
    setSending(true);
    setSendError('');
    try {
      if (gmailConnected && session?.access_token) {
        const result = await gmailProxy<{ success?: boolean; error?: string }>(
          session.access_token, 'send_email',
          { to: composeForm.to, subject: composeForm.subject, body: composeForm.body }
        );
        if (result.error) throw new Error(result.error);
      } else {
        const { data: { user } } = await supabase.auth.getUser();
        await supabase.from('emails').insert({
          user_id: user?.id,
          direction: 'outbound',
          from_addr: 'noreply@klirline.ca',
          to_addr: composeForm.to,
          subject: composeForm.subject,
          body: composeForm.body,
          status: 'sent',
          sent_at: new Date().toISOString(),
        });
      }
      showToast('success', 'Courriel envoyé !');
      setShowCompose(false);
      setComposeForm({ to: '', subject: '', body: '' });
      fetchEmails();
    } catch (e: unknown) {
      setSendError((e as Error)?.message ?? 'Erreur lors de l\'envoi.');
    }
    setSending(false);
  };

  const handleReply = (msg: GmailMessage) => {
    setComposeForm({ to: msg.from, subject: `RE: ${msg.subject}`, body: '' });
    setShowCompose(true);
  };

  // ── Filtered list ──────────────────────────────────────────────────────────
  const filtered = gmailConnected
    ? messages.filter(m => {
        if (!search) return true;
        const q = search.toLowerCase();
        return m.from.toLowerCase().includes(q) || m.subject.toLowerCase().includes(q) || m.snippet.toLowerCase().includes(q);
      })
    : localEmails.filter(e => {
        const matchFolder =
          folder === 'inbox' ? e.direction === 'inbound' :
          folder === 'sent' ? e.direction === 'outbound' && e.status === 'sent' :
          e.status === 'draft';
        if (!matchFolder) return true;
        if (!search) return true;
        const q = search.toLowerCase();
        return e.subject.toLowerCase().includes(q) || (e.body ?? '').toLowerCase().includes(q);
      });

  const unreadCount = messages.filter(m => m.isUnread).length;

  const folders: Array<{ id: Folder; label: string; icon: typeof Inbox; count: number }> = [
    { id: 'inbox', label: 'Boîte de réception', icon: Inbox, count: gmailConnected ? unreadCount : localEmails.filter(e => e.direction === 'inbound').length },
    { id: 'sent', label: 'Envoyés', icon: Send, count: gmailConnected ? 0 : localEmails.filter(e => e.status === 'sent').length },
    { id: 'draft', label: 'Brouillons', icon: Edit3, count: gmailConnected ? 0 : localEmails.filter(e => e.status === 'draft').length },
  ];

  return (
    <div className="flex flex-col h-full">
      <Header
        title="Email Hub"
        subtitle={gmailConnected ? gmailEmail : 'Centre de messagerie'}
        action={{ label: 'Nouveau message', onClick: () => { setComposeForm({ to: '', subject: '', body: '' }); setShowCompose(true); } }}
      />

      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg text-sm font-semibold animate-fade-in ${toast.type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
          {toast.type === 'success' ? <CheckCircle size={15} /> : <AlertCircle size={15} />}
          {toast.msg}
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* ── Sidebar ── */}
        <div className="w-52 flex-shrink-0 bg-slate-50 border-r border-slate-100 p-3 flex flex-col gap-1">
          {folders.map(f => (
            <button key={f.id} onClick={() => { setFolder(f.id); setSelected(null); }}
              className={`w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl text-sm font-medium transition ${folder === f.id ? 'bg-orange-500 text-white' : 'text-slate-600 hover:bg-white'}`}>
              <div className="flex items-center gap-2">
                <f.icon size={15} />
                <span>{f.label}</span>
              </div>
              {f.count > 0 && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${folder === f.id ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-600'}`}>{f.count}</span>
              )}
            </button>
          ))}

          <div className="mt-auto pt-3 border-t border-slate-200">
            {gmailConnected ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2 p-2.5 bg-white rounded-xl border border-green-200">
                  <Wifi size={13} className="text-green-500 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-700 truncate">{gmailEmail}</p>
                    <p className="text-[10px] text-green-600">Gmail connecté</p>
                  </div>
                </div>
                <button onClick={handleDisconnect} className="w-full flex items-center justify-center gap-1.5 py-1.5 text-xs text-slate-400 hover:text-red-500 transition rounded-lg hover:bg-red-50">
                  <WifiOff size={12} />Déconnecter
                </button>
              </div>
            ) : (
              <button
                onClick={handleConnectGmail}
                disabled={connectingGmail}
                className="w-full flex items-center gap-2 p-2.5 bg-white rounded-xl border border-slate-200 hover:border-slate-400 text-xs text-slate-600 hover:text-slate-800 font-semibold transition disabled:opacity-50"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                {connectingGmail ? 'Redirection...' : 'Connecter Gmail'}
              </button>
            )}
          </div>
        </div>

        {/* ── Email list ── */}
        <div className={`flex flex-col border-r border-slate-100 overflow-hidden ${selected ? 'w-80 flex-shrink-0' : 'flex-1'}`}>
          <div className="px-4 py-3 border-b border-slate-100 flex items-center gap-2">
            <div className="relative flex-1">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                className="w-full pl-8 pr-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-400 transition"
                placeholder="Rechercher..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
            <button onClick={fetchEmails} className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition" title="Actualiser">
              <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-50">
            {loading ? (
              <LoadingSpinner />
            ) : !gmailConnected && folder === 'inbox' && localEmails.length === 0 ? (
              <ConnectGmailBanner onConnect={handleConnectGmail} />
            ) : filtered.length === 0 ? (
              <EmptyState icon={<Mail size={24} />} title="Aucun courriel" description="Cette boîte est vide." action={{ label: 'Nouveau message', onClick: () => setShowCompose(true) }} />
            ) : gmailConnected ? (
              filtered.map((m) => (
                <button key={m.id} onClick={() => setSelected(m as GmailMessage)}
                  className={`w-full text-left px-4 py-3.5 hover:bg-slate-50 transition ${selected?.id === m.id ? 'bg-orange-50 border-l-2 border-l-orange-500' : ''}`}>
                  <div className="flex justify-between items-start mb-0.5">
                    <span className={`text-sm truncate ${m.isUnread ? 'font-bold text-slate-900' : 'font-medium text-slate-700'}`}>
                      {displayName((m as GmailMessage).from)}
                    </span>
                    <span className="text-xs text-slate-400 flex-shrink-0 ml-2">{fmtDate((m as GmailMessage).date)}</span>
                  </div>
                  <div className={`text-sm truncate ${m.isUnread ? 'font-semibold text-slate-800' : 'text-slate-600'}`}>{m.subject}</div>
                  <div className="text-xs text-slate-400 truncate mt-0.5">{m.snippet}</div>
                  {m.isUnread && <span className="inline-block w-2 h-2 rounded-full bg-blue-500 mt-1" />}
                </button>
              ))
            ) : (
              filtered.map((e) => (
                <div key={(e as LocalEmail).id} className="px-4 py-3.5 border-b border-slate-50">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-semibold text-slate-900 text-sm truncate">{(e as LocalEmail).from_addr}</span>
                    <span className="text-xs text-slate-400">{fmtDate((e as LocalEmail).created_at)}</span>
                  </div>
                  <div className="text-sm text-slate-700 truncate">{(e as LocalEmail).subject}</div>
                  <div className="text-xs text-slate-400 truncate mt-0.5">{(e as LocalEmail).body?.substring(0, 80)}</div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* ── Email detail ── */}
        {selected && (
          <div className="flex-1 flex flex-col overflow-hidden bg-white">
            <div className="px-6 py-4 border-b border-slate-100">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <button onClick={() => setSelected(null)} className="flex items-center gap-1 text-xs text-slate-400 hover:text-slate-600 mb-2 transition lg:hidden">
                    <ChevronLeft size={13} />Retour
                  </button>
                  <h2 className="font-bold text-slate-900 text-base leading-tight">{selected.subject}</h2>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-0.5 mt-1.5 text-xs text-slate-500">
                    <span>De : <strong className="text-slate-700">{displayName(selected.from)}</strong></span>
                    <span>À : <strong className="text-slate-700">{displayName(selected.to)}</strong></span>
                    <span>{fmtDate(selected.date)}</span>
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <button
                    onClick={() => handleReply(selected)}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition"
                  >
                    <Reply size={13} />Répondre
                  </button>
                  <button
                    onClick={() => setSelected(null)}
                    className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition"
                    title="Fermer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto px-6 py-5">
              {loadingBody ? (
                <div className="flex items-center gap-2 text-slate-400 text-sm">
                  <div className="w-4 h-4 border-2 border-slate-300 border-t-transparent rounded-full animate-spin" />
                  Chargement...
                </div>
              ) : (
                <div className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap font-mono">
                  {selectedBody || selected.snippet}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ── Compose modal ── */}
      {showCompose && (
        <Modal title="Nouveau message" onClose={() => setShowCompose(false)} size="lg">
          <div className="space-y-3">
            {sendError && (
              <div className="flex items-start gap-2 bg-red-50 border border-red-200 text-red-700 px-3 py-2.5 rounded-xl text-xs">
                <AlertCircle size={13} className="flex-shrink-0 mt-0.5" />
                {sendError}
              </div>
            )}
            {gmailConnected && (
              <div className="flex items-center gap-2 px-3 py-2 bg-green-50 border border-green-200 rounded-xl text-xs text-green-700 font-medium">
                <Wifi size={12} />
                Envoi via Gmail : {gmailEmail}
              </div>
            )}
            <FormField label="À" required>
              <input className={inputCls} type="email" value={composeForm.to} onChange={e => setComposeForm(f => ({ ...f, to: e.target.value }))} placeholder="destinataire@exemple.com" />
            </FormField>
            <FormField label="Sujet" required>
              <input className={inputCls} value={composeForm.subject} onChange={e => setComposeForm(f => ({ ...f, subject: e.target.value }))} placeholder="Objet du message" />
            </FormField>
            <FormField label="Message">
              <textarea className={textareaCls} rows={8} value={composeForm.body} onChange={e => setComposeForm(f => ({ ...f, body: e.target.value }))} placeholder="Bonjour,&#10;&#10;..." />
            </FormField>
          </div>
          <div className="flex justify-end gap-3 mt-5 pt-4 border-t border-slate-100">
            <button onClick={() => setShowCompose(false)} className="px-4 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
            <button
              onClick={handleSend}
              disabled={sending || !composeForm.to || !composeForm.subject}
              className="px-5 py-2 text-sm font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition disabled:opacity-50 flex items-center gap-2"
            >
              <Send size={13} />
              {sending ? 'Envoi...' : 'Envoyer'}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
