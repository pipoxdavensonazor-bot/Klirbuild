import { useEffect, useState, useCallback } from 'react';
import {
  Users, Calendar, DollarSign, Plus, ChevronRight, Check,
  AlertCircle, FileText, X, ChevronDown, ChevronUp, Edit3,
  ArrowLeft, TrendingUp, Clock, Info,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Modal, Badge, LoadingSpinner, FormField, inputCls, selectCls, SectionCard } from '../components/ui';

// ─── Types ────────────────────────────────────────────────────────────────────

interface PayEmployee {
  id: string;
  first_name: string;
  last_name: string;
  email: string | null;
  sin: string | null;
  status: string;
  pay_type: string;
  pay_frequency: string;
  hourly_rate: number | null;
  annual_salary: number | null;
  department: string | null;
  position: string | null;
  ccq_classification: string | null;
  ccq_number: string | null;
  federal_td1_credits: number;
  provincial_td1_credits: number;
  hire_date: string | null;
}

interface PayPeriod {
  id: string;
  period_start: string;
  period_end: string;
  pay_date: string;
  status: string;
  notes: string | null;
}

interface PayEntry {
  id: string;
  employee_id: string;
  period_id: string;
  hours_regular: number;
  hours_overtime: number;
  hours_double: number;
  hours_vacation: number;
  hours_sick: number;
  hours_holiday: number;
  regular_rate: number | null;
  gross_pay: number;
  vacation_pay: number;
  bonus: number;
  commission: number;
  expense_reimbursement: number;
  federal_tax: number;
  provincial_tax: number;
  rrq_employee: number;
  ei_employee: number;
  rqap_employee: number;
  collective_insurance: number;
  rrsp_employee: number;
  union_dues: number;
  other_deductions: number;
  total_deductions: number;
  rrq_employer: number;
  ei_employer: number;
  rqap_employer: number;
  cnesst_employer: number;
  net_pay: number;
  status: string;
}

interface FiscalRates {
  year: number;
  tps_rate: number;
  tvq_rate: number;
  rrq_employee_rate: number;
  rrq_employer_rate: number;
  rrq_max_pensionable: number;
  rrq_exemption: number;
  ei_employee_rate: number;
  ei_employer_multiplier: number;
  ei_max_insurable: number;
  rqap_employee_rate: number;
  rqap_employer_rate: number;
  rqap_max_insurable: number;
  cnesst_rate: number;
  federal_basic_personal: number;
  provincial_basic_personal: number;
  federal_brackets: TaxBracket[];
  provincial_brackets: TaxBracket[];
  federal_qc_abatement: number;
}

interface TaxBracket {
  min: number;
  max: number | null;
  rate: number;
  base: number;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const fmt = (n: number) =>
  new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD', maximumFractionDigits: 2 }).format(n);

const fmtPct = (r: number) => `${(r * 100).toFixed(3).replace(/\.?0+$/, '')}%`;

const FREQ_PERIODS: Record<string, number> = {
  weekly: 52, biweekly: 26, semimonthly: 24, monthly: 12,
};

const STATUS_PERIOD: Record<string, { label: string; color: 'slate' | 'blue' | 'green' | 'red' | 'yellow' }> = {
  draft:     { label: 'Brouillon', color: 'slate' },
  approved:  { label: 'Approuvée', color: 'blue' },
  paid:      { label: 'Payée',     color: 'green' },
  cancelled: { label: 'Annulée',   color: 'red' },
};

const STATUS_ENTRY: Record<string, { label: string; color: 'slate' | 'blue' | 'green' | 'red' }> = {
  draft:    { label: 'Brouillon', color: 'slate' },
  approved: { label: 'Approuvé',  color: 'blue' },
  paid:     { label: 'Payé',      color: 'green' },
  void:     { label: 'Annulé',    color: 'red' },
};

const PAY_TYPE_LABEL: Record<string, string> = { hourly: 'Horaire', salary: 'Salarié' };
const FREQ_LABEL: Record<string, string> = {
  weekly: 'Hebdomadaire', biweekly: 'Bihebdomadaire',
  semimonthly: 'Semi-mensuel', monthly: 'Mensuel',
};
const CCQ_CLASSES = [
  'Manoeuvre', 'Journalier', 'Apprenti — Classe A',
  'Apprenti — Classe B', 'Compagnon', 'Contremaître', 'Contremaître général',
];

// ─── 2024 Quebec Payroll Tax Engine ───────────────────────────────────────────

function calcTaxBracket(income: number, brackets: TaxBracket[]): number {
  for (let i = brackets.length - 1; i >= 0; i--) {
    if (income > brackets[i].min) {
      return brackets[i].base + (income - brackets[i].min) * brackets[i].rate;
    }
  }
  return 0;
}

function calcPayrollDeductions(
  grossAnnualized: number,
  rates: FiscalRates,
  federalCredits: number,
  provincialCredits: number,
  periodsPerYear: number,
  ytdRRQ: number = 0,
  ytdEI: number = 0,
  ytdRQAP: number = 0,
): {
  federal_tax: number;
  provincial_tax: number;
  rrq_employee: number;
  ei_employee: number;
  rqap_employee: number;
  rrq_employer: number;
  ei_employer: number;
  rqap_employer: number;
} {
  // Federal income tax (with QC abatement)
  const federalTaxableIncome = Math.max(0, grossAnnualized - federalCredits);
  const federalTaxAnnual = calcTaxBracket(federalTaxableIncome, rates.federal_brackets);
  const federalTaxWithAbatement = federalTaxAnnual * (1 - rates.federal_qc_abatement);
  const federal_tax = Math.max(0, federalTaxWithAbatement / periodsPerYear);

  // Provincial QC tax
  const provTaxableIncome = Math.max(0, grossAnnualized - provincialCredits);
  const provTaxAnnual = calcTaxBracket(provTaxableIncome, rates.provincial_brackets);
  const provincial_tax = Math.max(0, provTaxAnnual / periodsPerYear);

  // RRQ employee (6.4% on earnings between $3,500 and $68,500)
  const rrqMaxEmployee = (rates.rrq_max_pensionable - rates.rrq_exemption) * rates.rrq_employee_rate;
  const rrqEarnablePeriod = (rates.rrq_max_pensionable - rates.rrq_exemption) / periodsPerYear;
  const periodGrossForRRQ = grossAnnualized / periodsPerYear;
  const rrqBase = Math.max(0, Math.min(periodGrossForRRQ, rrqEarnablePeriod));
  const rrqCalc = rrqBase * rates.rrq_employee_rate;
  const rrqRemaining = Math.max(0, rrqMaxEmployee - ytdRRQ);
  const rrq_employee = Math.min(rrqCalc, rrqRemaining);
  const rrq_employer = rrq_employee; // same rate

  // EI (reduced Quebec rate 1.32%)
  const eiMaxEmployee = rates.ei_max_insurable * rates.ei_employee_rate;
  const eiPeriodGross = Math.min(grossAnnualized / periodsPerYear, rates.ei_max_insurable / periodsPerYear);
  const eiCalc = eiPeriodGross * rates.ei_employee_rate;
  const eiRemaining = Math.max(0, eiMaxEmployee - ytdEI);
  const ei_employee = Math.min(eiCalc, eiRemaining);
  const ei_employer = ei_employee * rates.ei_employer_multiplier;

  // RQAP (0.494% employee)
  const rqapMaxEmployee = rates.rqap_max_insurable * rates.rqap_employee_rate;
  const rqapPeriodGross = Math.min(grossAnnualized / periodsPerYear, rates.rqap_max_insurable / periodsPerYear);
  const rqapCalc = rqapPeriodGross * rates.rqap_employee_rate;
  const rqapRemaining = Math.max(0, rqapMaxEmployee - ytdRQAP);
  const rqap_employee = Math.min(rqapCalc, rqapRemaining);
  const rqap_employer = rqap_employee * (rates.rqap_employer_rate / rates.rqap_employee_rate);

  return {
    federal_tax: round2(federal_tax),
    provincial_tax: round2(provincial_tax),
    rrq_employee: round2(rrq_employee),
    ei_employee: round2(ei_employee),
    rqap_employee: round2(rqap_employee),
    rrq_employer: round2(rrq_employer),
    ei_employer: round2(ei_employer),
    rqap_employer: round2(rqap_employer),
  };
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

function computeEntry(emp: PayEmployee, entry: Partial<PayEntry>, rates: FiscalRates): Partial<PayEntry> {
  const h = {
    regular: Number(entry.hours_regular ?? 0),
    overtime: Number(entry.hours_overtime ?? 0),
    double: Number(entry.hours_double ?? 0),
    vacation: Number(entry.hours_vacation ?? 0),
    sick: Number(entry.hours_sick ?? 0),
    holiday: Number(entry.hours_holiday ?? 0),
  };

  const rate = Number(entry.regular_rate ?? emp.hourly_rate ?? 0);
  const periods = FREQ_PERIODS[emp.pay_frequency] ?? 26;

  let grossPay = 0;
  if (emp.pay_type === 'hourly') {
    grossPay =
      h.regular * rate +
      h.overtime * rate * 1.5 +
      h.double * rate * 2 +
      h.vacation * rate +
      h.sick * rate +
      h.holiday * rate;
  } else {
    grossPay = (emp.annual_salary ?? 0) / periods;
  }

  const vacationPay = Number(entry.vacation_pay ?? 0);
  const bonus = Number(entry.bonus ?? 0);
  const commission = Number(entry.commission ?? 0);
  const expense = Number(entry.expense_reimbursement ?? 0);

  const taxableGross = grossPay + vacationPay + bonus + commission;
  const grossAnnualized = taxableGross * periods;

  const deductions = calcPayrollDeductions(
    grossAnnualized,
    rates,
    emp.federal_td1_credits,
    emp.provincial_td1_credits,
    periods,
  );

  const collective_insurance = Number(entry.collective_insurance ?? 0);
  const rrsp_employee = Number(entry.rrsp_employee ?? 0);
  const union_dues = Number(entry.union_dues ?? 0);
  const other_deductions = Number(entry.other_deductions ?? 0);

  const total_deductions = round2(
    deductions.federal_tax +
    deductions.provincial_tax +
    deductions.rrq_employee +
    deductions.ei_employee +
    deductions.rqap_employee +
    collective_insurance +
    rrsp_employee +
    union_dues +
    other_deductions,
  );

  const cnesst_employer = round2(taxableGross * rates.cnesst_rate);
  const net_pay = round2(grossPay + vacationPay + bonus + commission + expense - total_deductions);

  return {
    gross_pay: round2(grossPay),
    ...deductions,
    collective_insurance,
    rrsp_employee,
    union_dues,
    other_deductions,
    total_deductions,
    cnesst_employer,
    net_pay: Math.max(0, net_pay),
  };
}

// ─── Default fiscal rates (2024 QC) ──────────────────────────────────────────

const DEFAULT_RATES: FiscalRates = {
  year: 2024,
  tps_rate: 0.05,
  tvq_rate: 0.09975,
  rrq_employee_rate: 0.064,
  rrq_employer_rate: 0.064,
  rrq_max_pensionable: 68500,
  rrq_exemption: 3500,
  ei_employee_rate: 0.0132,
  ei_employer_multiplier: 1.4,
  ei_max_insurable: 63200,
  rqap_employee_rate: 0.00494,
  rqap_employer_rate: 0.00692,
  rqap_max_insurable: 94000,
  cnesst_rate: 0.04,
  federal_basic_personal: 15705,
  provincial_basic_personal: 17183,
  federal_qc_abatement: 0.165,
  federal_brackets: [
    { min: 0,      max: 55867,   rate: 0.15,   base: 0 },
    { min: 55867,  max: 111733,  rate: 0.205,  base: 8380.05 },
    { min: 111733, max: 154906,  rate: 0.26,   base: 19591.82 },
    { min: 154906, max: 220000,  rate: 0.29,   base: 30823.14 },
    { min: 220000, max: null,    rate: 0.33,   base: 49698.14 },
  ],
  provincial_brackets: [
    { min: 0,      max: 51780,   rate: 0.14,   base: 0 },
    { min: 51780,  max: 103545,  rate: 0.19,   base: 7249.20 },
    { min: 103545, max: 126000,  rate: 0.24,   base: 17083.05 },
    { min: 126000, max: null,    rate: 0.2575, base: 22476.45 },
  ],
};

// ─── Employee Modal ───────────────────────────────────────────────────────────

function EmployeeModal({
  emp,
  onClose,
  onSave,
}: {
  emp: Partial<PayEmployee> | null;
  onClose: () => void;
  onSave: () => void;
}) {
  const isNew = !emp?.id;
  const [form, setForm] = useState<Partial<PayEmployee>>(
    emp ?? {
      status: 'active',
      pay_type: 'hourly',
      pay_frequency: 'biweekly',
      federal_td1_credits: DEFAULT_RATES.federal_basic_personal,
      provincial_td1_credits: DEFAULT_RATES.provincial_basic_personal,
      province: 'QC',
    } as any,
  );
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const set = (k: string, v: string | number) => setForm(f => ({ ...f, [k]: v }));

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.first_name?.trim() || !form.last_name?.trim()) {
      setErr('Le prénom et le nom sont obligatoires.');
      return;
    }
    setSaving(true);
    setErr('');
    const payload = { ...form };
    if (!payload.hourly_rate) payload.hourly_rate = null;
    if (!payload.annual_salary) payload.annual_salary = null;

    let error;
    if (isNew) {
      ({ error } = await supabase.from('payroll_employees').insert(payload));
    } else {
      ({ error } = await supabase.from('payroll_employees').update(payload).eq('id', form.id!));
    }
    setSaving(false);
    if (error) { setErr(error.message); return; }
    onSave();
  }

  return (
    <Modal title={isNew ? 'Nouvel employé' : 'Modifier employé'} onClose={onClose} size="xl">
      <form onSubmit={handleSubmit} className="space-y-5">
        {err && (
          <div className="bg-red-50 text-red-700 text-sm px-3 py-2 rounded-lg flex items-center gap-2">
            <AlertCircle size={14} /> {err}
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <FormField label="Prénom" required>
            <input className={inputCls} value={form.first_name ?? ''} onChange={e => set('first_name', e.target.value)} />
          </FormField>
          <FormField label="Nom" required>
            <input className={inputCls} value={form.last_name ?? ''} onChange={e => set('last_name', e.target.value)} />
          </FormField>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField label="Courriel">
            <input className={inputCls} type="email" value={form.email ?? ''} onChange={e => set('email', e.target.value)} />
          </FormField>
          <FormField label="NAS (numéro d'assurance sociale)">
            <input className={inputCls} value={form.sin ?? ''} onChange={e => set('sin', e.target.value)} placeholder="000-000-000" />
          </FormField>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <FormField label="Statut">
            <select className={selectCls} value={form.status ?? 'active'} onChange={e => set('status', e.target.value)}>
              <option value="active">Actif</option>
              <option value="on_leave">En congé</option>
              <option value="inactive">Inactif</option>
              <option value="terminated">Terminé</option>
            </select>
          </FormField>
          <FormField label="Type d'emploi">
            <select className={selectCls} value={form.employment_type ?? 'permanent'} onChange={e => set('employment_type', e.target.value)}>
              <option value="permanent">Permanent</option>
              <option value="temporary">Temporaire</option>
              <option value="contract">Contractuel</option>
              <option value="seasonal">Saisonnier</option>
            </select>
          </FormField>
          <FormField label="Date d'embauche">
            <input className={inputCls} type="date" value={form.hire_date ?? ''} onChange={e => set('hire_date', e.target.value)} />
          </FormField>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField label="Département">
            <input className={inputCls} value={form.department ?? ''} onChange={e => set('department', e.target.value)} />
          </FormField>
          <FormField label="Poste">
            <input className={inputCls} value={form.position ?? ''} onChange={e => set('position', e.target.value)} />
          </FormField>
        </div>

        <div className="border-t border-slate-100 pt-4">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Paie</p>
          <div className="grid grid-cols-3 gap-4">
            <FormField label="Type de paie">
              <select className={selectCls} value={form.pay_type ?? 'hourly'} onChange={e => set('pay_type', e.target.value)}>
                <option value="hourly">Horaire</option>
                <option value="salary">Salarié</option>
              </select>
            </FormField>
            <FormField label="Fréquence de paie">
              <select className={selectCls} value={form.pay_frequency ?? 'biweekly'} onChange={e => set('pay_frequency', e.target.value)}>
                <option value="weekly">Hebdomadaire (52/an)</option>
                <option value="biweekly">Bihebdomadaire (26/an)</option>
                <option value="semimonthly">Semi-mensuel (24/an)</option>
                <option value="monthly">Mensuel (12/an)</option>
              </select>
            </FormField>
            {form.pay_type === 'hourly' ? (
              <FormField label="Taux horaire ($)">
                <input className={inputCls} type="number" step="0.01" min="0" value={form.hourly_rate ?? ''} onChange={e => set('hourly_rate', parseFloat(e.target.value) || 0)} />
              </FormField>
            ) : (
              <FormField label="Salaire annuel ($)">
                <input className={inputCls} type="number" step="100" min="0" value={form.annual_salary ?? ''} onChange={e => set('annual_salary', parseFloat(e.target.value) || 0)} />
              </FormField>
            )}
          </div>
          <div className="grid grid-cols-2 gap-4 mt-4">
            <FormField label="Crédits TD1 fédéral ($)" hint="Montant personnel de base par défaut: 15 705 $">
              <input className={inputCls} type="number" step="1" min="0" value={form.federal_td1_credits ?? DEFAULT_RATES.federal_basic_personal} onChange={e => set('federal_td1_credits', parseFloat(e.target.value) || 0)} />
            </FormField>
            <FormField label="Crédits TD1 provincial ($)" hint="Montant personnel de base QC par défaut: 17 183 $">
              <input className={inputCls} type="number" step="1" min="0" value={form.provincial_td1_credits ?? DEFAULT_RATES.provincial_basic_personal} onChange={e => set('provincial_td1_credits', parseFloat(e.target.value) || 0)} />
            </FormField>
          </div>
        </div>

        <div className="border-t border-slate-100 pt-4">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">CCQ — Commission de la construction du Québec</p>
          <div className="grid grid-cols-2 gap-4">
            <FormField label="Classification CCQ">
              <select className={selectCls} value={form.ccq_classification ?? ''} onChange={e => set('ccq_classification', e.target.value)}>
                <option value="">-- Aucune --</option>
                {CCQ_CLASSES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </FormField>
            <FormField label="Numéro de carte CCQ">
              <input className={inputCls} value={form.ccq_number ?? ''} onChange={e => set('ccq_number', e.target.value)} placeholder="XXXX-XXXX-XXXX" />
            </FormField>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 transition">
            Annuler
          </button>
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold rounded-lg transition disabled:opacity-50"
          >
            {saving ? 'Enregistrement…' : isNew ? 'Créer employé' : 'Mettre à jour'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

// ─── Period Modal ──────────────────────────────────────────────────────────────

function PeriodModal({ onClose, onSave }: { onClose: () => void; onSave: () => void }) {
  const today = new Date().toISOString().slice(0, 10);
  const twoWeeksLater = new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10);
  const payDate = new Date(Date.now() + 18 * 86400000).toISOString().slice(0, 10);

  const [form, setForm] = useState({
    period_start: today,
    period_end: twoWeeksLater,
    pay_date: payDate,
    notes: '',
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.period_start || !form.period_end || !form.pay_date) {
      setErr('Les dates sont obligatoires.'); return;
    }
    setSaving(true);
    const { error } = await supabase.from('payroll_periods').insert({
      ...form,
      status: 'draft',
    });
    setSaving(false);
    if (error) { setErr(error.message); return; }
    onSave();
  }

  return (
    <Modal title="Nouvelle période de paie" onClose={onClose} size="sm">
      <form onSubmit={handleSubmit} className="space-y-4">
        {err && (
          <div className="bg-red-50 text-red-700 text-sm px-3 py-2 rounded-lg flex items-center gap-2">
            <AlertCircle size={14} /> {err}
          </div>
        )}
        <FormField label="Début de période" required>
          <input className={inputCls} type="date" value={form.period_start} onChange={e => setForm(f => ({ ...f, period_start: e.target.value }))} />
        </FormField>
        <FormField label="Fin de période" required>
          <input className={inputCls} type="date" value={form.period_end} onChange={e => setForm(f => ({ ...f, period_end: e.target.value }))} />
        </FormField>
        <FormField label="Date de paiement" required>
          <input className={inputCls} type="date" value={form.pay_date} onChange={e => setForm(f => ({ ...f, pay_date: e.target.value }))} />
        </FormField>
        <FormField label="Notes">
          <textarea className={`${inputCls} resize-none`} rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
        </FormField>
        <div className="flex justify-end gap-3">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 transition">Annuler</button>
          <button type="submit" disabled={saving} className="px-5 py-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold rounded-lg transition disabled:opacity-50">
            {saving ? 'Création…' : 'Créer période'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

// ─── Pay Stub Modal ────────────────────────────────────────────────────────────

function PayStubModal({
  entry,
  employee,
  period,
  onClose,
}: {
  entry: PayEntry;
  employee: PayEmployee;
  period: PayPeriod;
  onClose: () => void;
}) {
  return (
    <Modal title="Bulletin de paie" onClose={onClose} size="lg">
      <div className="space-y-5 text-sm">
        {/* Header */}
        <div className="flex justify-between items-start bg-slate-50 rounded-xl p-4">
          <div>
            <p className="font-bold text-slate-900 text-base">{employee.first_name} {employee.last_name}</p>
            {employee.position && <p className="text-slate-500">{employee.position}</p>}
            {employee.department && <p className="text-slate-400 text-xs">{employee.department}</p>}
          </div>
          <div className="text-right">
            <p className="text-slate-500 text-xs">Période</p>
            <p className="font-semibold text-slate-800">
              {new Date(period.period_start).toLocaleDateString('fr-CA')} – {new Date(period.period_end).toLocaleDateString('fr-CA')}
            </p>
            <p className="text-slate-500 text-xs mt-1">Paiement le {new Date(period.pay_date).toLocaleDateString('fr-CA')}</p>
          </div>
        </div>

        {/* Revenus */}
        <div>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Revenus</p>
          <div className="space-y-1">
            {[
              { label: 'Salaire régulier', val: entry.gross_pay },
              { label: 'Paie de vacances', val: entry.vacation_pay },
              { label: 'Boni', val: entry.bonus },
              { label: 'Commission', val: entry.commission },
              { label: 'Remboursement dépenses', val: entry.expense_reimbursement },
            ].filter(r => r.val > 0).map(r => (
              <div key={r.label} className="flex justify-between text-slate-700">
                <span>{r.label}</span><span className="font-medium">{fmt(r.val)}</span>
              </div>
            ))}
            <div className="flex justify-between font-semibold text-slate-900 border-t border-slate-100 pt-1 mt-1">
              <span>Revenu brut</span>
              <span>{fmt(entry.gross_pay + entry.vacation_pay + entry.bonus + entry.commission + entry.expense_reimbursement)}</span>
            </div>
          </div>
        </div>

        {/* Déductions */}
        <div>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Déductions</p>
          <div className="space-y-1">
            {[
              { label: 'Impôt fédéral', val: entry.federal_tax },
              { label: 'Impôt provincial (QC)', val: entry.provincial_tax },
              { label: 'RRQ — employé', val: entry.rrq_employee },
              { label: 'AE — employé', val: entry.ei_employee },
              { label: 'RQAP — employé', val: entry.rqap_employee },
              { label: 'Assurance collective', val: entry.collective_insurance },
              { label: 'REER', val: entry.rrsp_employee },
              { label: 'Cotisations syndicales', val: entry.union_dues },
              { label: 'Autres déductions', val: entry.other_deductions },
            ].filter(r => r.val > 0).map(r => (
              <div key={r.label} className="flex justify-between text-slate-700">
                <span>{r.label}</span><span className="font-medium text-red-600">({fmt(r.val)})</span>
              </div>
            ))}
            <div className="flex justify-between font-semibold text-slate-900 border-t border-slate-100 pt-1 mt-1">
              <span>Total déductions</span>
              <span className="text-red-600">({fmt(entry.total_deductions)})</span>
            </div>
          </div>
        </div>

        {/* Net */}
        <div className="bg-emerald-50 rounded-xl p-4 flex justify-between items-center">
          <span className="font-bold text-slate-900 text-base">Paie nette</span>
          <span className="font-black text-emerald-700 text-2xl">{fmt(entry.net_pay)}</span>
        </div>

        {/* Cotisations employeur */}
        <div className="bg-slate-50 rounded-xl p-3">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Charges employeur (information)</p>
          <div className="grid grid-cols-2 gap-1 text-xs text-slate-600">
            {[
              { label: 'RRQ — employeur', val: entry.rrq_employer },
              { label: 'AE — employeur', val: entry.ei_employer },
              { label: 'RQAP — employeur', val: entry.rqap_employer },
              { label: 'CNESST', val: entry.cnesst_employer },
            ].map(r => (
              <div key={r.label} className="flex justify-between">
                <span>{r.label}</span><span className="font-medium">{fmt(r.val)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
}

// ─── Payroll Run View ─────────────────────────────────────────────────────────

function PayrollRunView({
  period,
  employees,
  rates,
  onBack,
  onRefresh,
}: {
  period: PayPeriod;
  employees: PayEmployee[];
  rates: FiscalRates;
  onBack: () => void;
  onRefresh: () => void;
}) {
  const [entries, setEntries] = useState<Record<string, Partial<PayEntry>>>({});
  const [savedEntries, setSavedEntries] = useState<Record<string, PayEntry>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [stubEntry, setStubEntry] = useState<{ entry: PayEntry; emp: PayEmployee } | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  const activeEmps = employees.filter(e => e.status === 'active');

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from('payroll_entries')
        .select('*')
        .eq('period_id', period.id);

      const saved: Record<string, PayEntry> = {};
      const editable: Record<string, Partial<PayEntry>> = {};

      for (const emp of activeEmps) {
        const existing = (data ?? []).find(e => e.employee_id === emp.id) as PayEntry | undefined;
        if (existing) {
          saved[emp.id] = existing;
          editable[emp.id] = { ...existing };
        } else {
          const base: Partial<PayEntry> = {
            employee_id: emp.id,
            period_id: period.id,
            hours_regular: emp.pay_type === 'hourly' ? 80 : 0,
            hours_overtime: 0,
            hours_double: 0,
            hours_vacation: 0,
            hours_sick: 0,
            hours_holiday: 0,
            regular_rate: emp.hourly_rate ?? undefined,
            vacation_pay: 0,
            bonus: 0,
            commission: 0,
            expense_reimbursement: 0,
            collective_insurance: 0,
            rrsp_employee: 0,
            union_dues: 0,
            other_deductions: 0,
            status: 'draft',
          };
          const calc = computeEntry(emp, base, rates);
          editable[emp.id] = { ...base, ...calc };
        }
      }

      setSavedEntries(saved);
      setEntries(editable);
      setLoading(false);
    }
    load();
  }, [period.id]);

  function updateField(empId: string, field: string, value: number) {
    setEntries(prev => {
      const emp = activeEmps.find(e => e.id === empId)!;
      const updated = { ...prev[empId], [field]: value };
      const calc = computeEntry(emp, updated, rates);
      return { ...prev, [empId]: { ...updated, ...calc } };
    });
  }

  async function saveEntry(empId: string) {
    setSaving(empId);
    const entry = entries[empId];
    const existing = savedEntries[empId];
    let error;
    if (existing) {
      ({ error } = await supabase.from('payroll_entries').update(entry).eq('id', existing.id));
    } else {
      ({ error } = await supabase.from('payroll_entries').insert({ ...entry, period_id: period.id, employee_id: empId }));
    }
    setSaving(null);
    if (!error) {
      const { data } = await supabase.from('payroll_entries').select('*').eq('period_id', period.id).eq('employee_id', empId).maybeSingle();
      if (data) setSavedEntries(prev => ({ ...prev, [empId]: data as PayEntry }));
    }
  }

  async function approvePeriod() {
    // Save all unsaved entries first
    for (const emp of activeEmps) {
      if (!savedEntries[emp.id]) await saveEntry(emp.id);
    }
    await supabase.from('payroll_periods').update({ status: 'approved' }).eq('id', period.id);
    onRefresh();
  }

  const totals = activeEmps.reduce(
    (acc, emp) => {
      const e = entries[emp.id];
      if (!e) return acc;
      return {
        gross: acc.gross + (e.gross_pay ?? 0),
        net: acc.net + (e.net_pay ?? 0),
        deductions: acc.deductions + (e.total_deductions ?? 0),
        employer: acc.employer + (e.rrq_employer ?? 0) + (e.ei_employer ?? 0) + (e.rqap_employer ?? 0) + (e.cnesst_employer ?? 0),
      };
    },
    { gross: 0, net: 0, deductions: 0, employer: 0 },
  );

  if (loading) return <div className="p-6"><LoadingSpinner /></div>;

  return (
    <div className="flex-1 overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b border-slate-100 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="p-2 rounded-lg hover:bg-slate-100 transition text-slate-500">
              <ArrowLeft size={16} />
            </button>
            <div>
              <h2 className="font-bold text-slate-900">
                Période {new Date(period.period_start).toLocaleDateString('fr-CA')} – {new Date(period.period_end).toLocaleDateString('fr-CA')}
              </h2>
              <p className="text-xs text-slate-500">Paiement prévu le {new Date(period.pay_date).toLocaleDateString('fr-CA')}</p>
            </div>
            <Badge label={STATUS_PERIOD[period.status]?.label ?? period.status} color={STATUS_PERIOD[period.status]?.color ?? 'slate'} />
          </div>
          {period.status === 'draft' && (
            <button
              onClick={approvePeriod}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold rounded-lg transition"
            >
              <Check size={15} /> Approuver la période
            </button>
          )}
        </div>

        {/* Totals row */}
        <div className="grid grid-cols-4 gap-3 mt-4">
          {[
            { label: 'Masse salariale brute', val: totals.gross, icon: <TrendingUp size={14} className="text-blue-600" />, color: 'bg-blue-50' },
            { label: 'Total déductions', val: totals.deductions, icon: <AlertCircle size={14} className="text-amber-600" />, color: 'bg-amber-50' },
            { label: 'Paie nette totale', val: totals.net, icon: <DollarSign size={14} className="text-emerald-600" />, color: 'bg-emerald-50' },
            { label: 'Charges employeur', val: totals.employer, icon: <FileText size={14} className="text-orange-600" />, color: 'bg-orange-50' },
          ].map(t => (
            <div key={t.label} className={`${t.color} rounded-xl px-3 py-2 flex items-center gap-2`}>
              {t.icon}
              <div>
                <p className="text-[10px] text-slate-500 font-medium">{t.label}</p>
                <p className="text-sm font-bold text-slate-900">{fmt(t.val)}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Employee rows */}
      <div className="p-6 space-y-3">
        {activeEmps.length === 0 && (
          <div className="py-16 text-center text-slate-400">
            <Users size={32} className="mx-auto mb-3 opacity-30" />
            <p>Aucun employé actif. Ajoutez des employés dans l'onglet Employés.</p>
          </div>
        )}
        {activeEmps.map(emp => {
          const e = entries[emp.id] ?? {};
          const isExpanded = expanded === emp.id;
          const isSaved = !!savedEntries[emp.id];

          return (
            <div key={emp.id} className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
              {/* Row header */}
              <div className="flex items-center gap-4 px-5 py-4">
                <div className="w-9 h-9 rounded-full bg-orange-100 flex items-center justify-center text-orange-700 font-bold text-sm flex-shrink-0">
                  {emp.first_name[0]}{emp.last_name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-slate-900">{emp.first_name} {emp.last_name}</p>
                  <p className="text-xs text-slate-400">
                    {PAY_TYPE_LABEL[emp.pay_type]} · {FREQ_LABEL[emp.pay_frequency]}
                    {emp.hourly_rate ? ` · ${fmt(emp.hourly_rate)}/h` : ''}
                    {emp.ccq_classification ? ` · CCQ: ${emp.ccq_classification}` : ''}
                  </p>
                </div>

                {/* Quick hours (hourly only) */}
                {emp.pay_type === 'hourly' && (
                  <div className="flex items-center gap-2">
                    {[
                      { key: 'hours_regular', label: 'Rég.' },
                      { key: 'hours_overtime', label: 'Sup.' },
                    ].map(f => (
                      <div key={f.key} className="text-center">
                        <p className="text-[10px] text-slate-400 mb-0.5">{f.label}</p>
                        <input
                          type="number"
                          step="0.5"
                          min="0"
                          disabled={period.status !== 'draft'}
                          value={(e as any)[f.key] ?? 0}
                          onChange={ev => updateField(emp.id, f.key, parseFloat(ev.target.value) || 0)}
                          className="w-14 text-center text-sm font-medium border border-slate-200 rounded-lg px-1 py-1 focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 disabled:bg-slate-50 disabled:text-slate-400"
                        />
                      </div>
                    ))}
                  </div>
                )}

                <div className="text-right">
                  <p className="text-xs text-slate-400">Brut</p>
                  <p className="font-semibold text-slate-700">{fmt(e.gross_pay ?? 0)}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-400">Net</p>
                  <p className="font-bold text-emerald-700">{fmt(e.net_pay ?? 0)}</p>
                </div>

                <div className="flex items-center gap-2">
                  {period.status === 'draft' && (
                    <button
                      onClick={() => saveEntry(emp.id)}
                      disabled={saving === emp.id}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${isSaved ? 'bg-slate-100 text-slate-600 hover:bg-slate-200' : 'bg-orange-500 text-white hover:bg-orange-600'} disabled:opacity-50`}
                    >
                      {saving === emp.id ? '…' : isSaved ? 'Mettre à jour' : 'Sauvegarder'}
                    </button>
                  )}
                  {savedEntries[emp.id] && (
                    <button
                      onClick={() => setStubEntry({ entry: savedEntries[emp.id], emp })}
                      className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition"
                      title="Bulletin de paie"
                    >
                      <FileText size={14} />
                    </button>
                  )}
                  <button
                    onClick={() => setExpanded(isExpanded ? null : emp.id)}
                    className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition"
                  >
                    {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  </button>
                </div>
              </div>

              {/* Expanded detail */}
              {isExpanded && (
                <div className="border-t border-slate-100 px-5 py-4 bg-slate-50/50 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                  {/* Hours detail */}
                  {emp.pay_type === 'hourly' && (
                    <div className="col-span-2 md:col-span-4 grid grid-cols-3 md:grid-cols-6 gap-3">
                      {[
                        { key: 'hours_regular', label: 'Régulières' },
                        { key: 'hours_overtime', label: 'Supplémentaires (1.5x)' },
                        { key: 'hours_double', label: 'Double temps (2x)' },
                        { key: 'hours_vacation', label: 'Vacances' },
                        { key: 'hours_sick', label: 'Maladie' },
                        { key: 'hours_holiday', label: 'Jours fériés' },
                      ].map(f => (
                        <div key={f.key}>
                          <p className="text-slate-500 mb-1">{f.label}</p>
                          <input
                            type="number"
                            step="0.5"
                            min="0"
                            disabled={period.status !== 'draft'}
                            value={(e as any)[f.key] ?? 0}
                            onChange={ev => updateField(emp.id, f.key, parseFloat(ev.target.value) || 0)}
                            className="w-full text-center text-sm border border-slate-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 disabled:bg-slate-50 bg-white"
                          />
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Extras */}
                  {[
                    { key: 'vacation_pay', label: 'Paie de vacances' },
                    { key: 'bonus', label: 'Boni' },
                    { key: 'commission', label: 'Commission' },
                    { key: 'expense_reimbursement', label: 'Remboursement dépenses' },
                    { key: 'collective_insurance', label: 'Assurance collective' },
                    { key: 'rrsp_employee', label: 'REER employé' },
                    { key: 'union_dues', label: 'Cotisations syndicales' },
                    { key: 'other_deductions', label: 'Autres déductions' },
                  ].map(f => (
                    <div key={f.key}>
                      <p className="text-slate-500 mb-1">{f.label}</p>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        disabled={period.status !== 'draft'}
                        value={(e as any)[f.key] ?? 0}
                        onChange={ev => updateField(emp.id, f.key, parseFloat(ev.target.value) || 0)}
                        className="w-full text-center text-sm border border-slate-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 disabled:bg-slate-50 bg-white"
                      />
                    </div>
                  ))}

                  {/* Calculated deductions */}
                  <div className="col-span-2 md:col-span-4 border-t border-slate-200 pt-3 grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px]">
                    {[
                      { label: 'Impôt fédéral', val: e.federal_tax, deduction: true },
                      { label: 'Impôt provincial', val: e.provincial_tax, deduction: true },
                      { label: 'RRQ employé', val: e.rrq_employee, deduction: true },
                      { label: 'AE employé', val: e.ei_employee, deduction: true },
                      { label: 'RQAP employé', val: e.rqap_employee, deduction: true },
                      { label: 'RRQ employeur', val: e.rrq_employer, deduction: false },
                      { label: 'AE employeur', val: e.ei_employer, deduction: false },
                      { label: 'CNESST employeur', val: e.cnesst_employer, deduction: false },
                    ].map(d => (
                      <div key={d.label} className="flex justify-between bg-white rounded-lg px-2 py-1 border border-slate-100">
                        <span className="text-slate-500">{d.label}</span>
                        <span className={`font-semibold ${d.deduction ? 'text-red-600' : 'text-slate-600'}`}>{fmt(d.val ?? 0)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {stubEntry && (
        <PayStubModal
          entry={stubEntry.entry}
          employee={stubEntry.emp}
          period={period}
          onClose={() => setStubEntry(null)}
        />
      )}
    </div>
  );
}

// ─── Fiscal Rates Tab ─────────────────────────────────────────────────────────

function TauxFiscauxTab({ rates }: { rates: FiscalRates }) {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-start gap-3 bg-blue-50 border border-blue-100 rounded-xl px-4 py-3 text-sm text-blue-700">
        <Info size={16} className="flex-shrink-0 mt-0.5" />
        <p>Taux fiscaux Québec {rates.year} — Ces valeurs sont utilisées automatiquement pour le calcul de la paie. Elles reflètent la législation canadienne et québécoise en vigueur.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <SectionCard title="RRQ — Régime de rentes du Québec">
          <div className="px-4 py-3 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Taux employé</span><span className="font-semibold">{fmtPct(rates.rrq_employee_rate)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Taux employeur</span><span className="font-semibold">{fmtPct(rates.rrq_employer_rate)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Gains max. assurables</span><span className="font-semibold">{fmt(rates.rrq_max_pensionable)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Exemption de base</span><span className="font-semibold">{fmt(rates.rrq_exemption)}</span></div>
            <div className="flex justify-between text-orange-700 font-semibold border-t border-slate-100 pt-2">
              <span>Cotisation max. employé</span>
              <span>{fmt((rates.rrq_max_pensionable - rates.rrq_exemption) * rates.rrq_employee_rate)}</span>
            </div>
          </div>
        </SectionCard>

        <SectionCard title="AE — Assurance-emploi (QC réduit)">
          <div className="px-4 py-3 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Taux employé (QC)</span><span className="font-semibold">{fmtPct(rates.ei_employee_rate)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Multiplicateur employeur</span><span className="font-semibold">{rates.ei_employer_multiplier}x</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Rémunération assurable max.</span><span className="font-semibold">{fmt(rates.ei_max_insurable)}</span></div>
            <div className="flex justify-between text-orange-700 font-semibold border-t border-slate-100 pt-2">
              <span>Cotisation max. employé</span>
              <span>{fmt(rates.ei_max_insurable * rates.ei_employee_rate)}</span>
            </div>
          </div>
        </SectionCard>

        <SectionCard title="RQAP — Assurance parentale">
          <div className="px-4 py-3 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Taux employé</span><span className="font-semibold">{fmtPct(rates.rqap_employee_rate)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Taux employeur</span><span className="font-semibold">{fmtPct(rates.rqap_employer_rate)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Rémunération max. assurable</span><span className="font-semibold">{fmt(rates.rqap_max_insurable)}</span></div>
            <div className="flex justify-between text-orange-700 font-semibold border-t border-slate-100 pt-2">
              <span>Cotisation max. employé</span>
              <span>{fmt(rates.rqap_max_insurable * rates.rqap_employee_rate)}</span>
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Impôt fédéral — Tranches 2024">
          <div className="px-4 py-3 space-y-1.5 text-sm">
            {rates.federal_brackets.map((b, i) => (
              <div key={i} className="flex justify-between">
                <span className="text-slate-500">
                  {fmt(b.min)} – {b.max ? fmt(b.max) : '∞'}
                </span>
                <span className="font-semibold">{(b.rate * 100).toFixed(1)}%</span>
              </div>
            ))}
            <div className="text-xs text-slate-400 mt-2 pt-2 border-t border-slate-100">
              Abattement QC: {(rates.federal_qc_abatement * 100).toFixed(1)}% (résidents québécois)
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Impôt provincial QC — Tranches 2024">
          <div className="px-4 py-3 space-y-1.5 text-sm">
            {rates.provincial_brackets.map((b, i) => (
              <div key={i} className="flex justify-between">
                <span className="text-slate-500">
                  {fmt(b.min)} – {b.max ? fmt(b.max) : '∞'}
                </span>
                <span className="font-semibold">{(b.rate * 100).toFixed(2)}%</span>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Autres taux">
          <div className="px-4 py-3 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">TPS</span><span className="font-semibold">{fmtPct(rates.tps_rate)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">TVQ</span><span className="font-semibold">{fmtPct(rates.tvq_rate)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">CNESST (moy. construction)</span><span className="font-semibold">{fmtPct(rates.cnesst_rate)}</span></div>
            <div className="flex justify-between border-t border-slate-100 pt-2"><span className="text-slate-500">Montant personnel fédéral</span><span className="font-semibold">{fmt(rates.federal_basic_personal)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Montant personnel QC</span><span className="font-semibold">{fmt(rates.provincial_basic_personal)}</span></div>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

type Tab = 'periodes' | 'employes' | 'taux';

export default function PaiePage() {
  const [tab, setTab] = useState<Tab>('periodes');
  const [employees, setEmployees] = useState<PayEmployee[]>([]);
  const [periods, setPeriods] = useState<PayPeriod[]>([]);
  const [rates] = useState<FiscalRates>(DEFAULT_RATES);
  const [loading, setLoading] = useState(true);
  const [showPeriodModal, setShowPeriodModal] = useState(false);
  const [showEmpModal, setShowEmpModal] = useState<Partial<PayEmployee> | null | false>(false);
  const [activePeriod, setActivePeriod] = useState<PayPeriod | null>(null);

  const loadAll = useCallback(async () => {
    setLoading(true);
    const [{ data: emps }, { data: pers }] = await Promise.all([
      supabase.from('payroll_employees').select('*').order('last_name'),
      supabase.from('payroll_periods').select('*').order('period_start', { ascending: false }),
    ]);
    setEmployees((emps as PayEmployee[]) ?? []);
    setPeriods((pers as PayPeriod[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  if (activePeriod) {
    return (
      <div className="flex flex-col h-full overflow-hidden bg-slate-50">
        <PayrollRunView
          period={activePeriod}
          employees={employees}
          rates={rates}
          onBack={() => { setActivePeriod(null); loadAll(); }}
          onRefresh={loadAll}
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full overflow-hidden bg-slate-50">
      {/* Page header */}
      <div className="bg-white border-b border-slate-100 px-6 py-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-slate-900">Gestion de la paie</h1>
            <p className="text-sm text-slate-500 mt-0.5">Module de paie québécois — RRQ, AE, RQAP, CNESST · CCQ</p>
          </div>
          {tab === 'periodes' && (
            <button
              onClick={() => setShowPeriodModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold rounded-lg transition shadow-sm"
            >
              <Plus size={16} /> Nouvelle période
            </button>
          )}
          {tab === 'employes' && (
            <button
              onClick={() => setShowEmpModal({})}
              className="flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold rounded-lg transition shadow-sm"
            >
              <Plus size={16} /> Nouvel employé
            </button>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mt-4">
          {([
            { id: 'periodes', label: 'Périodes de paie', icon: <Calendar size={15} /> },
            { id: 'employes', label: `Employés (${employees.filter(e => e.status === 'active').length})`, icon: <Users size={15} /> },
            { id: 'taux', label: 'Taux fiscaux 2024', icon: <Info size={15} /> },
          ] as { id: Tab; label: string; icon: React.ReactNode }[]).map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition ${
                tab === t.id
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
              }`}
            >
              {t.icon} {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="p-6"><LoadingSpinner /></div>
        ) : tab === 'periodes' ? (
          <PeriodesTab periods={periods} onSelect={setActivePeriod} />
        ) : tab === 'employes' ? (
          <EmployesTab
            employees={employees}
            onEdit={emp => setShowEmpModal(emp)}
          />
        ) : (
          <TauxFiscauxTab rates={rates} />
        )}
      </div>

      {/* Modals */}
      {showPeriodModal && (
        <PeriodModal
          onClose={() => setShowPeriodModal(false)}
          onSave={() => { setShowPeriodModal(false); loadAll(); }}
        />
      )}
      {showEmpModal !== false && (
        <EmployeeModal
          emp={showEmpModal || null}
          onClose={() => setShowEmpModal(false)}
          onSave={() => { setShowEmpModal(false); loadAll(); }}
        />
      )}
    </div>
  );
}

// ─── Periodes Tab ──────────────────────────────────────────────────────────────

function PeriodesTab({ periods, onSelect }: { periods: PayPeriod[]; onSelect: (p: PayPeriod) => void }) {
  if (periods.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center px-6">
        <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mb-4">
          <Calendar size={28} className="text-slate-400" />
        </div>
        <h3 className="text-base font-semibold text-slate-700 mb-1">Aucune période de paie</h3>
        <p className="text-sm text-slate-400 max-w-xs">Créez votre première période de paie pour commencer à calculer les salaires de vos employés.</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-3">
      {periods.map(p => {
        const st = STATUS_PERIOD[p.status] ?? { label: p.status, color: 'slate' as const };
        return (
          <button
            key={p.id}
            onClick={() => onSelect(p)}
            className="w-full bg-white border border-slate-100 rounded-2xl px-5 py-4 flex items-center justify-between hover:border-orange-200 hover:shadow-md transition text-left group"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center">
                <Calendar size={18} className="text-orange-600" />
              </div>
              <div>
                <p className="font-semibold text-slate-900">
                  {new Date(p.period_start).toLocaleDateString('fr-CA', { day: 'numeric', month: 'long' })} – {new Date(p.period_end).toLocaleDateString('fr-CA', { day: 'numeric', month: 'long', year: 'numeric' })}
                </p>
                <p className="text-xs text-slate-400">
                  Paiement le {new Date(p.pay_date).toLocaleDateString('fr-CA', { day: 'numeric', month: 'long', year: 'numeric' })}
                  {p.notes ? ` · ${p.notes}` : ''}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge label={st.label} color={st.color} />
              <ChevronRight size={16} className="text-slate-400 group-hover:text-orange-500 transition" />
            </div>
          </button>
        );
      })}
    </div>
  );
}

// ─── Employes Tab ──────────────────────────────────────────────────────────────

function EmployesTab({ employees, onEdit }: { employees: PayEmployee[]; onEdit: (emp: PayEmployee) => void }) {
  if (employees.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center px-6">
        <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mb-4">
          <Users size={28} className="text-slate-400" />
        </div>
        <h3 className="text-base font-semibold text-slate-700 mb-1">Aucun employé</h3>
        <p className="text-sm text-slate-400 max-w-xs">Ajoutez vos employés pour pouvoir calculer leur paie, incluant toutes les déductions légales obligatoires.</p>
      </div>
    );
  }

  const empStatus: Record<string, { label: string; color: 'green' | 'yellow' | 'red' | 'slate' }> = {
    active: { label: 'Actif', color: 'green' },
    on_leave: { label: 'En congé', color: 'yellow' },
    inactive: { label: 'Inactif', color: 'slate' },
    terminated: { label: 'Terminé', color: 'red' },
  };

  return (
    <div className="p-6">
      <div className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
        <div className="divide-y divide-slate-50">
          {employees.map(emp => {
            const st = empStatus[emp.status] ?? { label: emp.status, color: 'slate' as const };
            return (
              <div key={emp.id} className="flex items-center gap-4 px-5 py-4 hover:bg-slate-50/70 transition">
                <div className="w-9 h-9 rounded-full bg-orange-100 flex items-center justify-center text-orange-700 font-bold text-sm flex-shrink-0">
                  {emp.first_name[0]}{emp.last_name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-slate-900">{emp.first_name} {emp.last_name}</p>
                  <p className="text-xs text-slate-400">
                    {emp.position ?? '—'}
                    {emp.department ? ` · ${emp.department}` : ''}
                    {emp.ccq_classification ? ` · CCQ: ${emp.ccq_classification}` : ''}
                  </p>
                </div>
                <div className="hidden md:flex items-center gap-6 text-sm">
                  <div className="text-center">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wide">Type</p>
                    <p className="font-medium text-slate-700">{PAY_TYPE_LABEL[emp.pay_type]}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wide">Taux / Salaire</p>
                    <p className="font-medium text-slate-700">
                      {emp.pay_type === 'hourly'
                        ? emp.hourly_rate ? `${fmt(emp.hourly_rate)}/h` : '—'
                        : emp.annual_salary ? fmt(emp.annual_salary) + '/an' : '—'}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wide">Fréquence</p>
                    <p className="font-medium text-slate-700">{FREQ_LABEL[emp.pay_frequency]}</p>
                  </div>
                </div>
                <Badge label={st.label} color={st.color} />
                <button
                  onClick={() => onEdit(emp)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
                >
                  <Edit3 size={15} />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
