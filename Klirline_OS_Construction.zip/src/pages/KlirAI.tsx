import { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, Bot, User, RefreshCw, Copy } from 'lucide-react';
import Header from '../components/Header';

interface Message { role: 'user' | 'assistant'; content: string; ts: Date }

const SUGGESTIONS = [
  'Comment rédiger un devis professionnel ?',
  'Aide-moi à formuler un email de relance client',
  'Quelles sont les meilleures pratiques pour gérer un chantier ?',
  'Comment optimiser la facturation de mon entreprise ?',
  'Génère un modèle de contrat de sous-traitance',
];

const RESPONSES: Record<string, string> = {
  default: `Bonjour ! Je suis **Klir AI**, votre assistant intelligent intégré à Klirline OS. Je peux vous aider avec :

• **Rédaction** — devis, contrats, emails professionnels
• **Gestion de chantier** — planification, ressources, suivi
• **Conseils financiers** — facturation, optimisation, flux de trésorerie
• **RH** — politiques, évaluations, gestion d'équipe

Comment puis-je vous aider aujourd'hui ?`,
};

function getResponse(msg: string): string {
  const lower = msg.toLowerCase();
  if (lower.includes('devis')) return `**Voici la structure d'un devis professionnel :**

1. **En-tête** — Logo, coordonnées, numéro de devis, date
2. **Client** — Nom, adresse, coordonnées
3. **Description des travaux** — Liste détaillée, quantités, unités
4. **Tarification** — Prix unitaires, sous-total, taxes (TPS/TVQ)
5. **Conditions** — Délai de validité (généralement 30-60 jours), modalités de paiement
6. **Signatures** — Acceptation client et entrepreneur

**Conseil :** Mentionnez toujours les exclusions pour éviter les malentendus et incluez une clause de variation de prix pour les matériaux.`;
  if (lower.includes('email') || lower.includes('relance')) return `**Modèle d'email de relance client :**

---
Objet : Rappel — Facture [N° FACTURE] échue le [DATE]

Bonjour [Prénom],

J'espère que vous allez bien. Je me permets de vous contacter au sujet de la facture **[N° FACTURE]** d'un montant de **[MONTANT]$**, qui était due le [DATE ÉCHÉANCE].

Il est possible que ce paiement ait été oublié dans vos activités. Vous pouvez effectuer le règlement par :
• Virement Interac : admin@votreentreprise.ca
• Chèque à l'ordre de : [NOM ENTREPRISE]

N'hésitez pas à me contacter si vous avez des questions.

Cordialement,
[Votre nom]
---

**Conseil :** Restez toujours courtois et professionnel, même pour des relances tardives.`;
  if (lower.includes('chantier') || lower.includes('gestion')) return `**Meilleures pratiques pour gérer un chantier :**

**Avant le démarrage**
• Réunion de démarrage avec toute l'équipe
• Plan de chantier et accès sécurisés
• Commandes de matériaux confirmées

**Pendant les travaux**
• Pointages quotidiens avec le module Présences
• Photos d'avancement (avant/pendant/après)
• Communication quotidienne dans le Chat de projet

**Suivi financier**
• Comparez le budget vs dépenses réelles chaque semaine
• Documentez les travaux supplémentaires immédiatement
• Facturez par avancement pour le flux de trésorerie

**Clôture**
• Liste de vérification finale avec le client
• Photos de réception
• Archivage de tous les documents`;
  if (lower.includes('contrat') || lower.includes('sous-traitance')) return `**Clauses essentielles d'un contrat de sous-traitance :**

1. **Parties** — Identification complète des deux entreprises
2. **Objet** — Description précise des travaux
3. **Délais** — Dates de début, étapes, livraison finale
4. **Prix** — Montant, modalités de paiement, retenue de garantie
5. **Responsabilités** — Qui fournit les matériaux, l'équipement
6. **Assurances** — Preuve d'assurance responsabilité civile obligatoire
7. **Modifications** — Procédure pour les extras et avenants
8. **Résiliation** — Conditions et préavis requis
9. **Litiges** — Mode de résolution (médiation, arbitrage)

⚠️ **Important :** Faites toujours valider vos contrats par un juriste spécialisé en construction.`;
  return `Je comprends votre demande concernant : "*${msg}*"

En tant qu'assistant Klirline OS, je peux vous aider avec la gestion de votre entreprise de construction. Pour une réponse plus précise, pourriez-vous me donner plus de détails sur votre situation spécifique ?

Je suis là pour vous assister avec la rédaction, la gestion de chantier, la facturation, et bien plus encore.`;
}

export default function KlirAIPage() {
  const [messages, setMessages] = useState<Message[]>([{ role: 'assistant', content: RESPONSES.default, ts: new Date() }]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const send = async (text: string) => {
    if (!text.trim() || loading) return;
    const userMsg: Message = { role: 'user', content: text, ts: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    await new Promise(r => setTimeout(r, 800 + Math.random() * 600));
    const response = getResponse(text);
    setMessages(prev => [...prev, { role: 'assistant', content: response, ts: new Date() }]);
    setLoading(false);
  };

  const reset = () => setMessages([{ role: 'assistant', content: RESPONSES.default, ts: new Date() }]);

  const renderContent = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, i) => {
      const parts = line.split(/(\*\*[^*]+\*\*)/g);
      return (
        <span key={i}>
          {parts.map((part, j) => part.startsWith('**') && part.endsWith('**')
            ? <strong key={j} className="font-semibold text-slate-900">{part.slice(2, -2)}</strong>
            : <span key={j}>{part}</span>
          )}
          {i < lines.length - 1 && <br />}
        </span>
      );
    });
  };

  return (
    <div className="flex flex-col h-full">
      <Header title="Klir AI" subtitle="Votre assistant intelligent" />
      <div className="flex flex-1 overflow-hidden">
        {/* Suggestions sidebar */}
        <div className="w-64 flex-shrink-0 bg-slate-50 border-r border-slate-100 p-4 space-y-3 overflow-y-auto">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Suggestions</p>
          <div className="space-y-2">
            {SUGGESTIONS.map((s, i) => (
              <button key={i} onClick={() => send(s)}
                className="w-full text-left text-xs text-slate-600 p-3 bg-white hover:bg-orange-50 hover:text-orange-700 border border-slate-100 hover:border-orange-200 rounded-xl transition">
                {s}
              </button>
            ))}
          </div>
          <div className="pt-4">
            <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-xl border border-orange-100 p-4 text-center">
              <Sparkles size={24} className="text-orange-500 mx-auto mb-2" />
              <p className="text-xs font-semibold text-orange-800 mb-1">Klir AI Pro</p>
              <p className="text-xs text-orange-600">Accès à GPT-4 et analyses avancées</p>
              <button className="mt-3 w-full py-1.5 text-xs font-semibold text-white bg-orange-500 hover:bg-orange-600 rounded-lg transition">Activer</button>
            </div>
          </div>
        </div>

        {/* Chat area */}
        <div className="flex-1 flex flex-col bg-white overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center">
                <Sparkles size={16} className="text-white" />
              </div>
              <div>
                <span className="text-sm font-semibold text-slate-900">Klir AI</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span className="text-xs text-slate-400">En ligne</span>
                </div>
              </div>
            </div>
            <button onClick={reset} className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-600 transition">
              <RefreshCw size={13} />Nouvelle conversation
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-5 py-5 space-y-5">
            {messages.map((msg, i) => (
              <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${msg.role === 'assistant' ? 'bg-gradient-to-br from-orange-400 to-amber-500' : 'bg-slate-200'}`}>
                  {msg.role === 'assistant' ? <Sparkles size={15} className="text-white" /> : <User size={15} className="text-slate-600" />}
                </div>
                <div className={`max-w-[75%] ${msg.role === 'user' ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                  <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${msg.role === 'assistant' ? 'bg-slate-50 text-slate-700 rounded-tl-sm' : 'bg-orange-500 text-white rounded-tr-sm'}`}>
                    {renderContent(msg.content)}
                  </div>
                  <span className="text-[11px] text-slate-400 px-1">{msg.ts.toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center flex-shrink-0">
                  <Sparkles size={15} className="text-white" />
                </div>
                <div className="bg-slate-50 rounded-2xl rounded-tl-sm px-4 py-3">
                  <div className="flex gap-1.5">
                    {[0, 1, 2].map(i => <div key={i} className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />)}
                  </div>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          <div className="px-5 py-4 border-t border-slate-100">
            <div className="flex items-center gap-3 bg-slate-50 rounded-2xl px-4 py-2.5 border border-slate-200 focus-within:border-orange-400 focus-within:ring-2 focus-within:ring-orange-500/20 transition">
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input); } }}
                placeholder="Posez votre question à Klir AI..."
                className="flex-1 bg-transparent text-sm text-slate-800 placeholder-slate-400 focus:outline-none"
                disabled={loading}
              />
              <button onClick={() => send(input)} disabled={!input.trim() || loading} className="text-orange-500 hover:text-orange-600 disabled:text-slate-300 transition flex-shrink-0">
                <Send size={18} />
              </button>
            </div>
            <p className="text-xs text-slate-400 text-center mt-2">Klir AI peut faire des erreurs. Vérifiez les informations importantes.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
