import { UserCheck, TrendingUp, BarChart3, Calendar, Award, Clock } from 'lucide-react';
import Header from '../components/Header';
import { StatCard, SectionCard } from '../components/ui';

export default function RHPage() {
  return (
    <div className="flex flex-col h-full">
      <Header title="Ressources humaines" subtitle="Gestion du personnel et des performances" />
      <div className="flex-1 p-6 overflow-auto space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Taux de présence" value="96%" sub="Ce mois" icon={<Clock size={22} className="text-blue-600" />} color="bg-blue-50" />
          <StatCard label="Congés en cours" value="2" sub="employés" icon={<Calendar size={22} className="text-amber-600" />} color="bg-amber-50" />
          <StatCard label="Formations" value="3" sub="en cours" icon={<Award size={22} className="text-violet-600" />} color="bg-violet-50" />
          <StatCard label="Performance moy." value="4.2/5" sub="équipe" icon={<TrendingUp size={22} className="text-emerald-600" />} color="bg-emerald-50" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SectionCard title="Congés et absences">
            <div className="p-5 space-y-3">
              {[
                { name: 'Marc Leblanc', type: 'Vacances', from: '2026-07-15', to: '2026-07-22', status: 'Approuvé' },
                { name: 'Sophie Bouchard', type: 'Maladie', from: '2026-07-01', to: '2026-07-03', status: 'Approuvé' },
                { name: 'Pierre Gagnon', type: 'Personnel', from: '2026-07-10', to: '2026-07-10', status: 'En attente' },
              ].map((req, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                  <div>
                    <div className="font-medium text-slate-800 text-sm">{req.name}</div>
                    <div className="text-xs text-slate-400">{req.type} · {req.from} → {req.to}</div>
                  </div>
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full ${req.status === 'Approuvé' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                    {req.status}
                  </span>
                </div>
              ))}
              <p className="text-xs text-slate-400 text-center pt-2">Les données réelles se connectent au module Employés</p>
            </div>
          </SectionCard>

          <SectionCard title="Formations">
            <div className="p-5 space-y-3">
              {[
                { title: 'Santé et sécurité chantier', employees: 8, progress: 75 },
                { title: 'Gestion de projet', employees: 3, progress: 40 },
                { title: 'First Aid / RCR', employees: 12, progress: 90 },
              ].map((f, i) => (
                <div key={i} className="p-3 bg-slate-50 rounded-xl">
                  <div className="flex justify-between items-center mb-2">
                    <div className="font-medium text-slate-800 text-sm">{f.title}</div>
                    <div className="text-xs text-slate-500">{f.employees} emp.</div>
                  </div>
                  <div className="h-1.5 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full bg-orange-500 rounded-full" style={{ width: `${f.progress}%` }} />
                  </div>
                  <div className="text-right text-xs text-slate-400 mt-1">{f.progress}%</div>
                </div>
              ))}
            </div>
          </SectionCard>
        </div>

        <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl border border-orange-100 p-6 text-center">
          <UserCheck size={32} className="text-orange-500 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 mb-1">Module RH complet</h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            Le module RH complet inclura la gestion des congés, des évaluations de performance, des formations, des contrats et de la paie. Connectez le module Employés et Présences pour commencer.
          </p>
        </div>
      </div>
    </div>
  );
}
