import { useEffect, useState } from 'react';
import { TrendingUp, Search, Phone, Mail, DollarSign } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Lead, Employee } from '../lib/types';
import Header from '../components/Header';
import { Modal, Badge, EmptyState, LoadingSpinner, FormField, inputCls, selectCls, textareaCls, useToast, Toast } from '../components/ui';

type LeadStage = 'new' | 'contacted' | 'proposal' | 'negotiation' | 'won' | 'lost';

const stages: { id: LeadStage; label: string; color: 'blue' | 'orange' | 'purple' | 'yellow' | 'green' | 'red' }[] = [
  { id: 'new', label: 'Nouveau', color: 'blue' },
  { id: 'contacted', label: 'Contacté', color: 'orange' },
  { id: 'proposal', label: 'Proposition', color: 'purple' },
  { id: 'negotiation', label: 'Négociation', color: 'yellow' },
  { id: 'won', label: 'Gagné', color: 'green' },
  { id: 'lost', label: 'Perdu', color: 'red' },
];

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Lead | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<Lead>>({});
  const { toast, showToast } = useToast();

  const fetchLeads = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('leads').select('*, employees(first_name,last_name)').order('created_at', { ascending: false });
    if (error) showToast('error', 'Impossible de charger les leads.');
    setLeads(data as Lead[] ?? []);
    setLoading(false);
  };

  useEffect(() => {
    fetchLeads();
    supabase.from('employees').select('id, first_name, last_name').then(({ data }) => setEmployees(data as Employee[] ?? []));
  }, []);

  const openCreate = () => { setEditing(null); setForm({ stage: 'new' }); setShowModal(true); };
  const openEdit = (l: Lead) => { setEditing(l); setForm({ ...l }); setShowModal(true); };

  const handleSave = async () => {
    setSaving(true);
    if (editing) {
      const { error } = await supabase.from('leads').update(form).eq('id', editing.id);
      if (error) { showToast('error', 'Erreur lors de la mise à jour.'); setSaving(false); return; }
    } else {
      const { error } = await supabase.from('leads').insert({ ...form, first_name: form.first_name ?? '', last_name: form.last_name ?? '' });
      if (error) { showToast('error', 'Erreur lors de la création.'); setSaving(false); return; }
    }
    showToast('success', editing ? 'Lead mis à jour.' : 'Lead créé.');
    setSaving(false);
    setShowModal(false);
    fetchLeads();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer ce lead ?')) return;
    const { error } = await supabase.from('leads').delete().eq('id', id);
    if (error) { showToast('error', 'Impossible de supprimer ce lead.'); return; }
    showToast('success', 'Lead supprimé.');
    fetchLeads();
  };

  const updateStage = async (id: string, stage: LeadStage) => {
    const { error } = await supabase.from('leads').update({ stage }).eq('id', id);
    if (error) { showToast('error', 'Erreur lors du changement d\'étape.'); return; }
    fetchLeads();
  };

  const filtered = leads.filter((l) => {
    const q = search.toLowerCase();
    const matchSearch = [l.first_name, l.last_name, l.company_name, l.email].some(v => v?.toLowerCase().includes(q));
    const matchStage = stageFilter === 'all' || l.stage === stageFilter;
    return matchSearch && matchStage;
  });

  const fmt = (n: number) => new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD', maximumFractionDigits: 0 }).format(n);
  const totalValue = filtered.filter(l => l.stage !== 'lost').reduce((s, l) => s + (l.value ?? 0), 0);

  return (
    <div className="flex flex-col h-full">
      <Header title="Leads" subtitle={`${leads.length} prospect${leads.length !== 1 ? 's' : ''} · Pipeline: ${fmt(totalValue)}`} action={{ label: 'Nouveau lead', onClick: openCreate }} />
      <div className="flex-1 p-6 overflow-auto">
        {/* Stage tabs */}
        <div className="flex gap-2 mb-4 flex-wrap">
          <button
            onClick={() => setStageFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${stageFilter === 'all' ? 'bg-slate-900 text-white' : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'}`}
          >
            Tous ({leads.length})
          </button>
          {stages.map(s => {
            const count = leads.filter(l => l.stage === s.id).length;
            return (
              <button
                key={s.id}
                onClick={() => setStageFilter(s.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${stageFilter === s.id ? 'bg-slate-900 text-white' : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'}`}
              >
                {s.label} ({count})
              </button>
            );
          })}
        </div>

        <div className="mb-4 relative max-w-sm">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher..." className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white transition" />
        </div>

        {loading ? <LoadingSpinner /> : filtered.length === 0 ? (
          <EmptyState icon={<TrendingUp size={28} />} title="Aucun lead" description="Ajoutez votre premier prospect." action={{ label: 'Nouveau lead', onClick: openCreate }} />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Prospect</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden md:table-cell">Contact</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden lg:table-cell">Source</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Valeur</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Étape</th>
                  <th className="px-5 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map((l) => {
                  const stage = stages.find(s => s.id === l.stage);
                  const emp = l.employees as any;
                  return (
                    <tr key={l.id} className="hover:bg-slate-50/80 transition">
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-sm flex-shrink-0">
                            {l.first_name[0]}
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">{l.first_name} {l.last_name}</div>
                            {l.company_name && <div className="text-xs text-slate-400">{l.company_name}</div>}
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 hidden md:table-cell">
                        <div className="space-y-0.5">
                          {l.email && <div className="flex items-center gap-1.5 text-slate-600"><Mail size={12} className="text-slate-400" />{l.email}</div>}
                          {l.phone && <div className="flex items-center gap-1.5 text-slate-600"><Phone size={12} className="text-slate-400" />{l.phone}</div>}
                        </div>
                      </td>
                      <td className="px-5 py-3.5 hidden lg:table-cell text-slate-500">{l.source ?? '—'}</td>
                      <td className="px-5 py-3.5">
                        {l.value ? (
                          <div className="flex items-center gap-1 font-semibold text-slate-800">
                            <DollarSign size={14} className="text-slate-400" />
                            {fmt(l.value).replace('CA', '').trim()}
                          </div>
                        ) : <span className="text-slate-300">—</span>}
                      </td>
                      <td className="px-5 py-3.5">
                        <select
                          value={l.stage}
                          onChange={e => updateStage(l.id, e.target.value as LeadStage)}
                          className="text-xs font-semibold border-0 bg-transparent focus:outline-none cursor-pointer"
                        >
                          {stages.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
                        </select>
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <button onClick={() => openEdit(l)} className="text-slate-400 hover:text-orange-600 px-2 py-1 rounded transition text-xs font-medium">Modifier</button>
                        <button onClick={() => handleDelete(l.id)} className="text-slate-400 hover:text-red-600 px-2 py-1 rounded transition text-xs font-medium">Suppr.</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showModal && (
        <Modal title={editing ? 'Modifier le lead' : 'Nouveau lead'} onClose={() => setShowModal(false)} size="lg">
          <div className="grid grid-cols-2 gap-4">
            <FormField label="Prénom" required>
              <input className={inputCls} value={form.first_name ?? ''} onChange={e => setForm(f => ({ ...f, first_name: e.target.value }))} />
            </FormField>
            <FormField label="Nom" required>
              <input className={inputCls} value={form.last_name ?? ''} onChange={e => setForm(f => ({ ...f, last_name: e.target.value }))} />
            </FormField>
            <FormField label="Entreprise">
              <input className={inputCls} value={form.company_name ?? ''} onChange={e => setForm(f => ({ ...f, company_name: e.target.value }))} />
            </FormField>
            <FormField label="Courriel">
              <input className={inputCls} type="email" value={form.email ?? ''} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            </FormField>
            <FormField label="Téléphone">
              <input className={inputCls} value={form.phone ?? ''} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
            </FormField>
            <FormField label="Source">
              <input className={inputCls} value={form.source ?? ''} onChange={e => setForm(f => ({ ...f, source: e.target.value }))} placeholder="Référence, Web, Publicité..." />
            </FormField>
            <FormField label="Valeur estimée ($)">
              <input className={inputCls} type="number" value={form.value ?? ''} onChange={e => setForm(f => ({ ...f, value: parseFloat(e.target.value) || undefined }))} />
            </FormField>
            <FormField label="Étape">
              <select className={selectCls} value={form.stage ?? 'new'} onChange={e => setForm(f => ({ ...f, stage: e.target.value as any }))}>
                {stages.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
              </select>
            </FormField>
            <FormField label="Assigné à">
              <select className={selectCls} value={form.assigned_to ?? ''} onChange={e => setForm(f => ({ ...f, assigned_to: e.target.value || undefined }))}>
                <option value="">— Personne —</option>
                {employees.map(e => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}
              </select>
            </FormField>
            <FormField label="Notes">
              <textarea className={textareaCls} rows={3} value={form.notes ?? ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </FormField>
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-slate-100">
            <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
            <button onClick={handleSave} disabled={saving || !form.first_name || !form.last_name} className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed">
              {saving ? 'Enregistrement...' : 'Enregistrer'}
            </button>
          </div>
        </Modal>
      )}
      <Toast toast={toast} />
    </div>
  );
}
