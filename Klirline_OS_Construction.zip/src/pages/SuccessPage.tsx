import React, { useEffect, useState } from 'react';
import { CheckCircle, ArrowRight, Sparkles } from 'lucide-react';

interface SuccessPageProps {
  onContinue?: () => void;
}

export function SuccessPage({ onContinue }: SuccessPageProps) {
  const [planName, setPlanName] = useState<string | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const plan = params.get('plan');
    if (plan) setPlanName(decodeURIComponent(plan));

    // Trigger entrance animation
    const t = setTimeout(() => setVisible(true), 50);
    return () => clearTimeout(t);
  }, []);

  const handleContinue = () => {
    if (onContinue) {
      onContinue();
    } else {
      window.location.href = '/';
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center px-4">
      <div
        className={`max-w-md w-full text-center transition-all duration-700 ${
          visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}
      >
        {/* Icon */}
        <div className="relative mx-auto mb-6 flex h-24 w-24 items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping" />
          <div className="relative rounded-full bg-emerald-500/20 p-5">
            <CheckCircle className="h-12 w-12 text-emerald-400" />
          </div>
        </div>

        {/* Heading */}
        <h1 className="text-3xl font-bold text-white mb-3">
          You're all set!
        </h1>

        {planName ? (
          <p className="text-gray-400 text-base leading-relaxed">
            Your{' '}
            <span className="font-semibold text-white">{planName}</span>{' '}
            subscription is now active. Enjoy all the features included in your plan.
          </p>
        ) : (
          <p className="text-gray-400 text-base leading-relaxed">
            Your subscription is now active. Welcome aboard!
          </p>
        )}

        {/* Feature highlights */}
        <div className="mt-8 rounded-2xl border border-white/10 bg-white/5 p-6 text-left space-y-3">
          {[
            'Subscription confirmed and active',
            'Billing managed securely via Stripe',
            'Cancel or upgrade anytime from settings',
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 text-sm text-gray-300">
              <Sparkles className="h-4 w-4 flex-shrink-0 text-emerald-400" />
              <span>{item}</span>
            </div>
          ))}
        </div>

        {/* CTA */}
        <button
          onClick={handleContinue}
          className="mt-8 w-full inline-flex items-center justify-center gap-2 rounded-xl bg-white px-6 py-3 text-sm font-semibold text-gray-900 hover:bg-gray-100 active:scale-[0.98] transition-all duration-150"
        >
          Continue to App
          <ArrowRight className="h-4 w-4" />
        </button>

        <p className="mt-4 text-xs text-gray-600">
          A receipt has been sent to your email address.
        </p>
      </div>
    </div>
  );
}