import { useState } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import Header from '../components/Header';
import { Badge } from '../components/ui';

const DAYS = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
const MONTHS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];

interface CalEvent { day: number; title: string; color: string; type: string }

const SAMPLE_EVENTS: CalEvent[] = [
  { day: 1, title: 'Réunion équipe', color: 'bg-blue-500', type: 'Réunion' },
  { day: 3, title: 'Début chantier Tremblay', color: 'bg-orange-500', type: 'Chantier' },
  { day: 7, title: 'Livraison matériaux', color: 'bg-emerald-500', type: 'Logistique' },
  { day: 10, title: 'Inspection sécurité', color: 'bg-amber-500', type: 'Inspection' },
  { day: 14, title: 'Réunion direction', color: 'bg-violet-500', type: 'Réunion' },
  { day: 15, title: 'Soumission client Bouchard', color: 'bg-blue-400', type: 'Client' },
  { day: 18, title: 'Paiement facture #0023', color: 'bg-emerald-500', type: 'Finance' },
  { day: 21, title: 'Fin phase 1 — Laurier', color: 'bg-orange-500', type: 'Chantier' },
  { day: 24, title: 'Formation SST équipe', color: 'bg-rose-500', type: 'Formation' },
  { day: 28, title: 'Réunion mensuelle', color: 'bg-violet-500', type: 'Réunion' },
];

export default function CalendrierPage() {
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const prev = () => { if (month === 0) { setMonth(11); setYear(y => y - 1); } else setMonth(m => m - 1); };
  const next = () => { if (month === 11) { setMonth(0); setYear(y => y + 1); } else setMonth(m => m + 1); };

  const isToday = (d: number) => d === today.getDate() && month === today.getMonth() && year === today.getFullYear();
  const eventsForDay = (d: number) => SAMPLE_EVENTS.filter(e => e.day === d);

  const upcomingEvents = SAMPLE_EVENTS.filter(e => e.day >= today.getDate()).slice(0, 5);

  return (
    <div className="flex flex-col h-full">
      <Header title="Calendrier" subtitle={`${MONTHS[month]} ${year}`} action={{ label: 'Ajouter événement', onClick: () => {} }} />
      <div className="flex flex-1 overflow-hidden p-6 gap-6">
        {/* Calendar grid */}
        <div className="flex-1 flex flex-col min-w-0">
          <div className="flex items-center justify-between mb-4">
            <button onClick={prev} className="p-2 hover:bg-slate-100 rounded-lg transition text-slate-500"><ChevronLeft size={18} /></button>
            <h2 className="font-bold text-slate-900 text-lg">{MONTHS[month]} {year}</h2>
            <button onClick={next} className="p-2 hover:bg-slate-100 rounded-lg transition text-slate-500"><ChevronRight size={18} /></button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm flex-1 overflow-hidden">
            {/* Day headers */}
            <div className="grid grid-cols-7 border-b border-slate-100">
              {DAYS.map(d => (
                <div key={d} className="py-2.5 text-center text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  {d}
                </div>
              ))}
            </div>

            {/* Grid */}
            <div className="grid grid-cols-7 flex-1">
              {Array.from({ length: firstDay }).map((_, i) => (
                <div key={`empty-${i}`} className="border-b border-r border-slate-50 min-h-[80px] bg-slate-50/30" />
              ))}
              {Array.from({ length: daysInMonth }).map((_, i) => {
                const day = i + 1;
                const events = eventsForDay(day);
                return (
                  <div key={day} className={`border-b border-r border-slate-50 min-h-[80px] p-1.5 hover:bg-slate-50/80 transition cursor-pointer ${(firstDay + i) % 7 === 6 ? 'border-r-0' : ''}`}>
                    <div className={`w-7 h-7 flex items-center justify-center rounded-full text-sm font-medium mb-1 ${isToday(day) ? 'bg-orange-500 text-white' : 'text-slate-700 hover:bg-slate-200 transition'}`}>
                      {day}
                    </div>
                    <div className="space-y-0.5">
                      {events.slice(0, 2).map((e, j) => (
                        <div key={j} className={`${e.color} text-white text-[10px] font-medium px-1.5 py-0.5 rounded truncate`}>
                          {e.title}
                        </div>
                      ))}
                      {events.length > 2 && <div className="text-[10px] text-slate-400 pl-1">+{events.length - 2} autres</div>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-64 flex-shrink-0 space-y-4">
          {/* Today */}
          <div className="bg-orange-500 text-white rounded-2xl p-4 text-center">
            <div className="text-sm font-medium opacity-80">Aujourd'hui</div>
            <div className="text-4xl font-black mt-1">{today.getDate()}</div>
            <div className="text-sm font-medium opacity-80">{MONTHS[today.getMonth()]} {today.getFullYear()}</div>
          </div>

          {/* Upcoming */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm">
            <div className="px-4 py-3 border-b border-slate-100">
              <h3 className="text-sm font-semibold text-slate-900">Prochains événements</h3>
            </div>
            <div className="divide-y divide-slate-50">
              {upcomingEvents.map((e, i) => (
                <div key={i} className="px-4 py-3 flex items-start gap-3">
                  <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${e.color}`} />
                  <div>
                    <div className="text-sm font-medium text-slate-800">{e.title}</div>
                    <div className="text-xs text-slate-400">Le {e.day} {MONTHS[month].toLowerCase()}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Legend */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-4">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Légende</h3>
            <div className="space-y-2">
              {[
                { color: 'bg-orange-500', label: 'Chantier' },
                { color: 'bg-blue-500', label: 'Réunion' },
                { color: 'bg-emerald-500', label: 'Finance' },
                { color: 'bg-violet-500', label: 'Interne' },
                { color: 'bg-amber-500', label: 'Inspection' },
              ].map(item => (
                <div key={item.label} className="flex items-center gap-2 text-xs text-slate-600">
                  <div className={`w-2.5 h-2.5 rounded-full ${item.color}`} />
                  {item.label}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
