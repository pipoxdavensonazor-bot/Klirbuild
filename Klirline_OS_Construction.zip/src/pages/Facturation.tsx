import { useEffect, useState } from 'react';
import { FileText, Search, Plus, Trash2, Send, Eye } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Invoice, InvoiceItem, Client, Project } from '../lib/types';
import Header from '../components/Header';
import { Modal, Badge, EmptyState, LoadingSpinner, FormField, inputCls, selectCls, textareaCls } from '../components/ui';

const statusOptions = [
  { value: 'draft', label: 'Brouillon', color: 'slate' as const },
  { value: 'sent', label: 'Envoyée', color: 'blue' as const },
  { value: 'paid', label: 'Payée', color: 'green' as const },
  { value: 'overdue', label: 'En retard', color: 'red' as const },
  { value: 'cancelled', label: 'Annulée', color: 'slate' as const },
];

interface ItemRow { id?: string; description: string; quantity: number; unit_price: number; total: number }

export default function FacturationPage() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [viewInvoice, setViewInvoice] = useState<Invoice | null>(null);
  const [viewItems, setViewItems] = useState<InvoiceItem[]>([]);
  const [editing, setEditing] = useState<Invoice | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<Invoice>>({});
  const [items, setItems] = useState<ItemRow[]>([{ description: '', quantity: 1, unit_price: 0, total: 0 }]);

  const fetchInvoices = async () => {
    setLoading(true);
    const { data } = await supabase.from('invoices').select('*, clients(first_name,last_name,company_name), projects(name)').order('created_at', { ascending: false });
    setInvoices(data as Invoice[] ?? []);
    setLoading(false);
  };

  useEffect(() => {
    fetchInvoices();
    supabase.from('clients').select('id,first_name,last_name,company_name').then(({ data }) => setClients(data as Client[] ?? []));
    supabase.from('projects').select('id,name').then(({ data }) => setProjects(data as Project[] ?? []));
  }, []);

  const nextInvoiceNo = () => {
    const n = invoices.length + 1;
    return `INV-${new Date().getFullYear()}-${n.toString().padStart(4, '0')}`;
  };

  const openCreate = () => {
    setEditing(null);
    setForm({ status: 'draft', issue_date: new Date().toISOString().split('T')[0], tax_rate: 15, invoice_no: nextInvoiceNo() });
    setItems([{ description: '', quantity: 1, unit_price: 0, total: 0 }]);
    setShowModal(true);
  };

  const openView = async (inv: Invoice) => {
    setViewInvoice(inv);
    const { data } = await supabase.from('invoice_items').select('*').eq('invoice_id', inv.id).order('sort_order');
    setViewItems(data as InvoiceItem[] ?? []);
  };

  const updateItem = (i: number, field: keyof ItemRow, val: string | number) => {
    setItems(prev => {
      const updated = [...prev];
      updated[i] = { ...updated[i], [field]: val };
      if (field === 'quantity' || field === 'unit_price') {
        updated[i].total = updated[i].quantity * updated[i].unit_price;
      }
      return updated;
    });
  };

  const calcTotals = () => {
    const subtotal = items.reduce((s, r) => s + r.total, 0);
    const taxRate = form.tax_rate ?? 15;
    const taxAmount = (subtotal * taxRate) / 100;
    return { subtotal, taxAmount, total: subtotal + taxAmount };
  };

  const handleSave = async () => {
    setSaving(true);
    const { subtotal, taxAmount, total } = calcTotals();
    const payload = { ...form, subtotal, tax_amount: taxAmount, total };
    let invoiceId = editing?.id;
    if (editing) {
      await supabase.from('invoices').update(payload).eq('id', editing.id);
      await supabase.from('invoice_items').delete().eq('invoice_id', editing.id);
    } else {
      const { data } = await supabase.from('invoices').insert(payload).select('id').single();
      invoiceId = data?.id;
    }
    if (invoiceId) {
      const rowItems = items.filter(r => r.description).map((r, i) => ({ invoice_id: invoiceId, ...r, sort_order: i }));
      if (rowItems.length) await supabase.from('invoice_items').insert(rowItems);
    }
    setSaving(false);
    setShowModal(false);
    fetchInvoices();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer cette facture ?')) return;
    await supabase.from('invoices').delete().eq('id', id);
    fetchInvoices();
  };

  const updateStatus = async (id: string, status: string) => {
    await supabase.from('invoices').update({ status }).eq('id', id);
    fetchInvoices();
  };

  const filtered = invoices.filter(inv => {
    const c = inv.clients as any;
    const q = search.toLowerCase();
    const matchSearch = [inv.invoice_no, c?.company_name, c?.first_name, c?.last_name].some(v => v?.toLowerCase().includes(q));
    return matchSearch && (statusFilter === 'all' || inv.status === statusFilter);
  });

  const fmt = (n: number) => new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD' }).format(n);
  const totals = calcTotals();

  return (
    <div className="flex flex-col h-full">
      <Header title="Facturation" subtitle={`${invoices.length} facture${invoices.length !== 1 ? 's' : ''}`} action={{ label: 'Nouvelle facture', onClick: openCreate }} />
      <div className="flex-1 p-6 overflow-auto">
        {/* Summary cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-5">
          {statusOptions.map(s => {
            const count = invoices.filter(i => i.status === s.value).length;
            const total = invoices.filter(i => i.status === s.value).reduce((sum, i) => sum + i.total, 0);
            return (
              <button key={s.value} onClick={() => setStatusFilter(s.value === statusFilter ? 'all' : s.value)}
                className={`p-3 rounded-xl border text-left transition ${statusFilter === s.value ? 'border-orange-400 bg-orange-50' : 'border-slate-100 bg-white hover:bg-slate-50'}`}>
                <div className="text-xs font-semibold text-slate-500 mb-1">{s.label}</div>
                <div className="text-lg font-bold text-slate-900">{count}</div>
                <div className="text-xs text-slate-400">{fmt(total)}</div>
              </button>
            );
          })}
        </div>

        <div className="flex gap-3 mb-4">
          <div className="relative max-w-sm">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher facture..." className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white transition" />
          </div>
        </div>

        {loading ? <LoadingSpinner /> : filtered.length === 0 ? (
          <EmptyState icon={<FileText size={28} />} title="Aucune facture" description="Créez votre première facture." action={{ label: 'Nouvelle facture', onClick: openCreate }} />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">N°</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Client</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden md:table-cell">Date</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden lg:table-cell">Échéance</th>
                  <th className="text-right px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Total</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Statut</th>
                  <th className="px-5 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map(inv => {
                  const c = inv.clients as any;
                  const s = statusOptions.find(o => o.value === inv.status);
                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/80 transition">
                      <td className="px-5 py-3.5 font-mono font-medium text-slate-700">{inv.invoice_no}</td>
                      <td className="px-5 py-3.5">
                        {c ? <span className="font-medium text-slate-900">{c.company_name ?? `${c.first_name} ${c.last_name}`}</span> : <span className="text-slate-400">—</span>}
                      </td>
                      <td className="px-5 py-3.5 hidden md:table-cell text-slate-500">{inv.issue_date}</td>
                      <td className="px-5 py-3.5 hidden lg:table-cell text-slate-500">{inv.due_date ?? '—'}</td>
                      <td className="px-5 py-3.5 text-right font-bold text-slate-900">{fmt(inv.total)}</td>
                      <td className="px-5 py-3.5">
                        {s && <Badge label={s.label} color={s.color} />}
                      </td>
                      <td className="px-5 py-3.5 text-right space-x-1">
                        <button onClick={() => openView(inv)} className="text-slate-400 hover:text-blue-600 px-2 py-1 rounded transition text-xs font-medium">Voir</button>
                        {inv.status === 'draft' && (
                          <button onClick={() => updateStatus(inv.id, 'sent')} className="text-slate-400 hover:text-green-600 px-2 py-1 rounded transition text-xs font-medium">Envoyer</button>
                        )}
                        {inv.status === 'sent' && (
                          <button onClick={() => updateStatus(inv.id, 'paid')} className="text-slate-400 hover:text-emerald-600 px-2 py-1 rounded transition text-xs font-medium">Payée</button>
                        )}
                        <button onClick={() => handleDelete(inv.id)} className="text-slate-400 hover:text-red-600 px-2 py-1 rounded transition text-xs font-medium">Suppr.</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showModal && (
        <Modal title={editing ? 'Modifier la facture' : 'Nouvelle facture'} onClose={() => setShowModal(false)} size="xl">
          <div className="space-y-5">
            <div className="grid grid-cols-3 gap-4">
              <FormField label="N° Facture">
                <input className={inputCls} value={form.invoice_no ?? ''} onChange={e => setForm(f => ({ ...f, invoice_no: e.target.value }))} />
              </FormField>
              <FormField label="Client">
                <select className={selectCls} value={form.client_id ?? ''} onChange={e => setForm(f => ({ ...f, client_id: e.target.value || undefined }))}>
                  <option value="">— Client —</option>
                  {clients.map(c => <option key={c.id} value={c.id}>{c.company_name ?? `${c.first_name} ${c.last_name}`}</option>)}
                </select>
              </FormField>
              <FormField label="Chantier">
                <select className={selectCls} value={form.project_id ?? ''} onChange={e => setForm(f => ({ ...f, project_id: e.target.value || undefined }))}>
                  <option value="">— Chantier —</option>
                  {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </FormField>
              <FormField label="Date émission">
                <input className={inputCls} type="date" value={form.issue_date ?? ''} onChange={e => setForm(f => ({ ...f, issue_date: e.target.value }))} />
              </FormField>
              <FormField label="Date d'échéance">
                <input className={inputCls} type="date" value={form.due_date ?? ''} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))} />
              </FormField>
              <FormField label="TPS+TVQ (%)">
                <input className={inputCls} type="number" value={form.tax_rate ?? 15} onChange={e => setForm(f => ({ ...f, tax_rate: parseFloat(e.target.value) }))} />
              </FormField>
            </div>

            {/* Line items */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold text-slate-700">Lignes</label>
                <button onClick={() => setItems(prev => [...prev, { description: '', quantity: 1, unit_price: 0, total: 0 }])} className="text-xs text-orange-600 hover:text-orange-700 font-semibold flex items-center gap-1">
                  <Plus size={12} /> Ajouter une ligne
                </button>
              </div>
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="text-left px-3 py-2 text-xs font-semibold text-slate-500">Description</th>
                      <th className="text-right px-3 py-2 text-xs font-semibold text-slate-500 w-20">Qté</th>
                      <th className="text-right px-3 py-2 text-xs font-semibold text-slate-500 w-28">Prix unit.</th>
                      <th className="text-right px-3 py-2 text-xs font-semibold text-slate-500 w-24">Total</th>
                      <th className="w-8" />
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {items.map((row, i) => (
                      <tr key={i}>
                        <td className="px-2 py-1.5">
                          <input className="w-full px-2 py-1 text-sm border-0 focus:outline-none bg-transparent" value={row.description} onChange={e => updateItem(i, 'description', e.target.value)} placeholder="Description du service..." />
                        </td>
                        <td className="px-2 py-1.5">
                          <input className="w-full px-2 py-1 text-sm text-right border-0 focus:outline-none bg-transparent" type="number" value={row.quantity} onChange={e => updateItem(i, 'quantity', parseFloat(e.target.value) || 0)} />
                        </td>
                        <td className="px-2 py-1.5">
                          <input className="w-full px-2 py-1 text-sm text-right border-0 focus:outline-none bg-transparent" type="number" value={row.unit_price} onChange={e => updateItem(i, 'unit_price', parseFloat(e.target.value) || 0)} />
                        </td>
                        <td className="px-3 py-1.5 text-right font-medium text-slate-700">{fmt(row.total)}</td>
                        <td className="px-2">
                          {items.length > 1 && (
                            <button onClick={() => setItems(prev => prev.filter((_, j) => j !== i))} className="text-slate-300 hover:text-red-500 transition">
                              <Trash2 size={14} />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Totals */}
            <div className="flex justify-end">
              <div className="w-64 space-y-1.5 text-sm">
                <div className="flex justify-between text-slate-500"><span>Sous-total</span><span>{fmt(totals.subtotal)}</span></div>
                <div className="flex justify-between text-slate-500"><span>TPS+TVQ ({form.tax_rate ?? 15}%)</span><span>{fmt(totals.taxAmount)}</span></div>
                <div className="flex justify-between font-bold text-slate-900 text-base pt-2 border-t border-slate-200"><span>Total</span><span>{fmt(totals.total)}</span></div>
              </div>
            </div>

            <FormField label="Notes">
              <textarea className={textareaCls} rows={2} value={form.notes ?? ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </FormField>
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-slate-100">
            <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
            <button onClick={handleSave} disabled={saving} className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50">
              {saving ? 'Enregistrement...' : 'Enregistrer'}
            </button>
          </div>
        </Modal>
      )}

      {/* View Modal */}
      {viewInvoice && (
        <Modal title={`Facture ${viewInvoice.invoice_no}`} onClose={() => setViewInvoice(null)} size="xl">
          <div className="space-y-4 text-sm">
            <div className="flex justify-between">
              <div>
                {(() => { const c = viewInvoice.clients as any; return c ? <div className="font-semibold text-slate-800">{c.company_name ?? `${c.first_name} ${c.last_name}`}</div> : null; })()}
                <div className="text-slate-500">Date : {viewInvoice.issue_date}</div>
                {viewInvoice.due_date && <div className="text-slate-500">Échéance : {viewInvoice.due_date}</div>}
              </div>
              {(() => { const s = statusOptions.find(o => o.value === viewInvoice.status); return s ? <Badge label={s.label} color={s.color} /> : null; })()}
            </div>
            {viewItems.length > 0 && (
              <table className="w-full border border-slate-100 rounded-xl overflow-hidden">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="text-left px-4 py-2 text-xs font-semibold text-slate-500">Description</th>
                    <th className="text-right px-4 py-2 text-xs font-semibold text-slate-500">Qté</th>
                    <th className="text-right px-4 py-2 text-xs font-semibold text-slate-500">P.U.</th>
                    <th className="text-right px-4 py-2 text-xs font-semibold text-slate-500">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {viewItems.map(item => (
                    <tr key={item.id}>
                      <td className="px-4 py-2">{item.description}</td>
                      <td className="px-4 py-2 text-right">{item.quantity}</td>
                      <td className="px-4 py-2 text-right">{fmt(item.unit_price)}</td>
                      <td className="px-4 py-2 text-right font-medium">{fmt(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            <div className="flex justify-end">
              <div className="w-56 space-y-1 text-sm">
                <div className="flex justify-between text-slate-500"><span>Sous-total</span><span>{fmt(viewInvoice.subtotal)}</span></div>
                <div className="flex justify-between text-slate-500"><span>Taxes</span><span>{fmt(viewInvoice.tax_amount)}</span></div>
                <div className="flex justify-between font-bold text-slate-900 text-base pt-2 border-t border-slate-200"><span>Total</span><span>{fmt(viewInvoice.total)}</span></div>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
