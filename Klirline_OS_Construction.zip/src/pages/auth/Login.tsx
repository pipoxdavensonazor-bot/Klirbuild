import { useState } from 'react';
import { Eye, EyeOff, LogIn, AlertCircle, Shield, Users, UserPlus, Settings } from 'lucide-react';
import { useAuth } from '../../lib/auth';

function GoogleIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}

function MicrosoftIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 23 23" fill="none">
      <path d="M1 1h10v10H1z" fill="#F25022"/>
      <path d="M12 1h10v10H12z" fill="#7FBA00"/>
      <path d="M1 12h10v10H1z" fill="#00A4EF"/>
      <path d="M12 12h10v10H12z" fill="#FFB900"/>
    </svg>
  );
}

interface LoginPageProps {
  onGoRegister: () => void;
  onGoForgot: () => void;
  onGoAdminSetup: () => void;
  firstRun: boolean;
}

function LoginForm({
  accentColor,
  onGoForgot,
  emailPlaceholder,
}: {
  accentColor: 'orange' | 'blue';
  onGoForgot: () => void;
  emailPlaceholder: string;
}) {
  const { signIn, signInWithGoogle, signInWithMicrosoft } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [microsoftLoading, setMicrosoftLoading] = useState(false);
  const [error, setError] = useState('');

  const ring = accentColor === 'orange' ? 'focus:ring-orange-500/30 focus:border-orange-400' : 'focus:ring-blue-500/30 focus:border-blue-400';
  const btn = accentColor === 'orange'
    ? 'bg-orange-500 hover:bg-orange-600 shadow-orange-200'
    : 'bg-blue-600 hover:bg-blue-700 shadow-blue-200';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const { error } = await signIn(email, password);
    if (error) {
      setError(
        error.includes('Invalid login') ? 'Courriel ou mot de passe incorrect.' :
        error.includes('Email not confirmed') ? 'Veuillez confirmer votre courriel.' :
        error
      );
    }
    setLoading(false);
  };

  const handleGoogle = async () => {
    setGoogleLoading(true);
    await signInWithGoogle();
    setGoogleLoading(false);
  };

  const handleMicrosoft = async () => {
    setMicrosoftLoading(true);
    await signInWithMicrosoft();
    setMicrosoftLoading(false);
  };

  return (
    <div className="space-y-3">
      <form onSubmit={handleSubmit} className="space-y-3">
        {error && (
          <div className="flex items-start gap-2 bg-red-50 border border-red-200 text-red-700 px-3 py-2.5 rounded-xl text-xs">
            <AlertCircle size={14} className="flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
        <div>
          <label className="block text-xs font-semibold text-slate-600 mb-1">Courriel</label>
          <input
            type="email" required value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder={emailPlaceholder}
            className={`w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 transition bg-slate-50 ${ring}`}
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-600 mb-1">Mot de passe</label>
          <div className="relative">
            <input
              type={showPw ? 'text' : 'password'} required value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              className={`w-full px-3 py-2.5 pr-10 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 transition bg-slate-50 ${ring}`}
            />
            <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition">
              {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          <div className="flex justify-end mt-1">
            <button type="button" onClick={onGoForgot} className="text-xs text-slate-400 hover:text-slate-600 transition">
              Mot de passe oublié ?
            </button>
          </div>
        </div>
        <button
          type="submit"
          disabled={loading || !email || !password}
          className={`w-full py-2.5 ${btn} text-white font-bold rounded-xl transition shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm`}
        >
          {loading
            ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            : <><LogIn size={14} />Se connecter</>
          }
        </button>
      </form>

      <div className="flex items-center gap-2 my-1">
        <div className="flex-1 h-px bg-slate-200" />
        <span className="text-xs text-slate-400 font-medium">ou</span>
        <div className="flex-1 h-px bg-slate-200" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <button
          type="button"
          onClick={handleGoogle}
          disabled={googleLoading}
          className="w-full flex items-center justify-center gap-2 py-2.5 border border-slate-200 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-semibold text-sm transition shadow-sm disabled:opacity-50"
        >
          {googleLoading
            ? <div className="w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" />
            : <><GoogleIcon />Google</>
          }
        </button>
        <button
          type="button"
          onClick={handleMicrosoft}
          disabled={microsoftLoading}
          className="w-full flex items-center justify-center gap-2 py-2.5 border border-slate-200 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-semibold text-sm transition shadow-sm disabled:opacity-50"
        >
          {microsoftLoading
            ? <div className="w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" />
            : <><MicrosoftIcon />Microsoft 365</>
          }
        </button>
      </div>
    </div>
  );
}

export default function LoginPage({ onGoRegister, onGoForgot, onGoAdminSetup, firstRun }: LoginPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 flex flex-col items-center justify-center p-4">
      {/* Ambient glows */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-1/2 h-full bg-orange-500/5 blur-3xl" />
        <div className="absolute top-0 right-0 w-1/2 h-full bg-blue-500/5 blur-3xl" />
      </div>

      {/* Logo */}
      <div className="relative flex flex-col items-center mb-8">
        <div className="w-16 h-16 rounded-2xl bg-white flex items-center justify-center shadow-2xl mb-4">
          <img src="/Copilot_20260624_204551.png" alt="Klirline" className="w-14 h-14 object-contain" />
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">KLIRLINE OS</h1>
        <p className="text-slate-400 text-sm mt-1">Plateforme de gestion construction</p>
      </div>

      {/* Split panel */}
      <div className="relative w-full max-w-3xl flex flex-col lg:flex-row gap-0 shadow-2xl rounded-3xl overflow-hidden">

        {/* ── LEFT: ADMIN ── */}
        <div className="flex-1 bg-gradient-to-br from-slate-800 to-slate-900 p-7 flex flex-col border-r border-white/5">
          {/* Header */}
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 rounded-xl bg-orange-500/20 border border-orange-500/30 flex items-center justify-center flex-shrink-0">
              <Shield size={18} className="text-orange-400" />
            </div>
            <div>
              <h2 className="text-base font-black text-white tracking-wide uppercase">Administrateur</h2>
              <p className="text-xs text-slate-400">Gestionnaire de l'entreprise</p>
            </div>
          </div>

          {/* Divider label */}
          <div className="flex items-center gap-2 mb-4">
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-xs text-orange-400 font-semibold">CONNEXION ADMIN</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>

          <LoginForm
            accentColor="orange"
            onGoForgot={onGoForgot}
            emailPlaceholder="admin@entreprise.com"
          />

          {/* Create admin account CTA */}
          <div className="mt-5 pt-4 border-t border-white/10">
            <button
              onClick={onGoAdminSetup}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 border-orange-500/40 hover:border-orange-500 hover:bg-orange-500/10 text-orange-400 hover:text-orange-300 font-semibold text-sm transition group"
            >
              <Settings size={15} className="group-hover:rotate-45 transition-transform duration-300" />
              {firstRun ? 'Configurer le compte administrateur' : 'Créer un compte administrateur'}
            </button>
            {firstRun && (
              <p className="text-xs text-orange-400/70 text-center mt-2">
                Aucun administrateur configuré — commencez ici
              </p>
            )}
          </div>
        </div>

        {/* Vertical separator with label */}
        <div className="hidden lg:flex flex-col items-center justify-center relative z-10 -mx-px">
          <div className="h-full w-px bg-white/10" />
          <div className="absolute bg-slate-900 border border-white/10 rounded-full px-2 py-1">
            <span className="text-xs font-bold text-slate-500">OU</span>
          </div>
        </div>

        {/* Horizontal separator for mobile */}
        <div className="lg:hidden flex items-center gap-3 px-7 py-2 bg-slate-900">
          <div className="flex-1 h-px bg-white/10" />
          <span className="text-xs font-bold text-slate-500">OU</span>
          <div className="flex-1 h-px bg-white/10" />
        </div>

        {/* ── RIGHT: USERS ── */}
        <div className="flex-1 bg-white p-7 flex flex-col">
          {/* Header */}
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center flex-shrink-0">
              <Users size={18} className="text-blue-600" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900 tracking-wide uppercase">Équipe</h2>
              <p className="text-xs text-slate-500">Employés, comptables, gestionnaires</p>
            </div>
          </div>

          {/* Divider label */}
          <div className="flex items-center gap-2 mb-4">
            <div className="flex-1 h-px bg-slate-200" />
            <span className="text-xs text-blue-600 font-semibold">CONNEXION UTILISATEUR</span>
            <div className="flex-1 h-px bg-slate-200" />
          </div>

          <LoginForm
            accentColor="blue"
            onGoForgot={onGoForgot}
            emailPlaceholder="jean@entreprise.com"
          />

          {/* Register CTA */}
          <div className="mt-5 pt-4 border-t border-slate-100">
            <button
              onClick={onGoRegister}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 border-blue-200 hover:border-blue-500 hover:bg-blue-50 text-blue-600 hover:text-blue-700 font-semibold text-sm transition"
            >
              <UserPlus size={15} />
              Créer votre compte
            </button>
            <p className="text-xs text-slate-400 text-center mt-2">
              Choisissez votre poste lors de l'inscription
            </p>
          </div>
        </div>
      </div>

      <p className="relative text-center text-xs text-slate-600 mt-6">
        &copy; 2026 Klirline Inc. &middot; Tous droits réservés
      </p>
    </div>
  );
}
