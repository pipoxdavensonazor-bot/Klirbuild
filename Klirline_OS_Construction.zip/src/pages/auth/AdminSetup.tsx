import { useState } from 'react';
import { Eye, EyeOff, ShieldCheck, AlertCircle, CheckCircle, Building2 } from 'lucide-react';
import { useAuth } from '../../lib/auth';

interface AdminSetupPageProps {
  onComplete: () => void;
}

export default function AdminSetupPage({ onComplete }: AdminSetupPageProps) {
  const { signUp } = useAuth();
  const [form, setForm] = useState({ fullName: '', company: '', email: '', password: '', confirm: '' });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [requiresConfirmation, setRequiresConfirmation] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (form.password !== form.confirm) { setError('Les mots de passe ne correspondent pas.'); return; }
    if (form.password.length < 8) { setError('Le mot de passe doit contenir au moins 8 caractères.'); return; }
    setLoading(true);
    const { error, requiresConfirmation } = await signUp(form.email, form.password, form.fullName, 'admin');
    if (error) {
      setError(
        error.includes('already registered') ? 'Ce courriel est déjà utilisé.' :
        error.includes('Password') ? 'Mot de passe trop faible.' :
        error
      );
    } else {
      setRequiresConfirmation(requiresConfirmation);
      setSuccess(true);
    }
    setLoading(false);
  };

  const pwStrength = (pw: string): { level: number; label: string; color: string } => {
    let score = 0;
    if (pw.length >= 8) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^a-zA-Z0-9]/.test(pw)) score++;
    const levels = [
      { level: 0, label: '', color: '' },
      { level: 1, label: 'Faible', color: 'bg-red-500' },
      { level: 2, label: 'Moyen', color: 'bg-amber-500' },
      { level: 3, label: 'Bon', color: 'bg-blue-500' },
      { level: 4, label: 'Fort', color: 'bg-emerald-500' },
    ];
    return levels[score] ?? levels[0];
  };

  const strength = pwStrength(form.password);

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-3xl shadow-2xl p-8 text-center">
            <div className={`w-16 h-16 ${requiresConfirmation ? 'bg-amber-100' : 'bg-emerald-100'} rounded-full flex items-center justify-center mx-auto mb-4`}>
              <CheckCircle size={32} className={requiresConfirmation ? 'text-amber-500' : 'text-emerald-600'} />
            </div>
            <h2 className="text-xl font-bold text-slate-900 mb-2">
              {requiresConfirmation ? 'Vérifiez votre courriel !' : 'Compte administrateur créé !'}
            </h2>
            <p className="text-slate-500 text-sm mb-6">
              {requiresConfirmation
                ? `Un lien de confirmation a été envoyé à ${form.email}. Confirmez votre adresse pour accéder à Klirline OS.`
                : 'Votre compte administrateur a été configuré avec succès. Vous pouvez maintenant vous connecter à Klirline OS.'
              }
            </p>
            {requiresConfirmation ? (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 text-left">
                <p className="text-sm text-amber-800 font-semibold mb-1">Prochaine étape</p>
                <p className="text-xs text-amber-700">
                  Ouvrez votre courriel <strong>{form.email}</strong> et cliquez sur le lien de confirmation. Une fois votre compte activé, revenez ici pour vous connecter.
                </p>
              </div>
            ) : (
              <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 mb-6 text-left">
                <p className="text-sm text-orange-800 font-semibold mb-1">Prochaine étape</p>
                <p className="text-xs text-orange-700">
                  Une fois connecté, allez dans <strong>Utilisateurs</strong> pour générer des codes d'accès et inviter vos employés.
                </p>
              </div>
            )}
            <button onClick={onComplete} className={`w-full py-3 ${requiresConfirmation ? 'bg-slate-700 hover:bg-slate-800' : 'bg-orange-500 hover:bg-orange-600'} text-white font-bold rounded-xl transition text-sm`}>
              {requiresConfirmation ? 'Retour à la connexion' : 'Se connecter'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-white flex items-center justify-center shadow-xl mb-4">
            <img src="/Copilot_20260624_204551.png" alt="Klirline" className="w-14 h-14 object-contain" />
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">KLIRLINE OS</h1>
          <p className="text-slate-400 text-sm mt-1">Configuration initiale</p>
        </div>

        {/* First-run banner */}
        <div className="flex items-start gap-3 bg-orange-500/20 border border-orange-500/30 rounded-2xl px-4 py-3 mb-5">
          <ShieldCheck size={18} className="text-orange-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-orange-300 text-sm font-semibold">Première configuration</p>
            <p className="text-orange-200/80 text-xs mt-0.5">Aucun administrateur n'existe encore. Créez le compte administrateur de votre entreprise.</p>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8">
          <h2 className="text-xl font-bold text-slate-900 mb-1">Créer le compte administrateur</h2>
          <p className="text-sm text-slate-500 mb-6">Gestionnaire de construction — accès complet à Klirline OS</p>

          {error && (
            <div className="flex items-start gap-3 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-5 text-sm">
              <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Nom complet</label>
              <input
                type="text" required value={form.fullName}
                onChange={e => setForm(f => ({ ...f, fullName: e.target.value }))}
                placeholder="Jean Tremblay"
                className="w-full px-4 py-3 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 transition bg-slate-50"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                <span className="flex items-center gap-1.5"><Building2 size={14} />Nom de l'entreprise</span>
              </label>
              <input
                type="text" value={form.company}
                onChange={e => setForm(f => ({ ...f, company: e.target.value }))}
                placeholder="Construction Tremblay inc."
                className="w-full px-4 py-3 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 transition bg-slate-50"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Courriel</label>
              <input
                type="email" required value={form.email}
                onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                placeholder="admin@entreprise.com"
                className="w-full px-4 py-3 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 transition bg-slate-50"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Mot de passe</label>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'} required value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  placeholder="Min. 8 caractères"
                  className="w-full px-4 py-3 pr-12 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 transition bg-slate-50"
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition">
                  {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              {form.password && (
                <div className="mt-2">
                  <div className="flex gap-1 mb-1">
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className={`flex-1 h-1 rounded-full transition-all ${i <= strength.level ? strength.color : 'bg-slate-100'}`} />
                    ))}
                  </div>
                  {strength.label && <p className={`text-xs font-medium ${strength.level <= 1 ? 'text-red-500' : strength.level <= 2 ? 'text-amber-500' : 'text-emerald-600'}`}>{strength.label}</p>}
                </div>
              )}
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Confirmer le mot de passe</label>
              <input
                type="password" required value={form.confirm}
                onChange={e => setForm(f => ({ ...f, confirm: e.target.value }))}
                placeholder="••••••••"
                className={`w-full px-4 py-3 text-sm border rounded-xl focus:outline-none focus:ring-2 transition bg-slate-50 ${form.confirm && form.confirm !== form.password ? 'border-red-300 focus:ring-red-500/20' : 'border-slate-200 focus:ring-orange-500/30 focus:border-orange-400'}`}
              />
              {form.confirm && form.confirm !== form.password && (
                <p className="text-xs text-red-500 mt-1">Les mots de passe ne correspondent pas</p>
              )}
            </div>

            <button
              type="submit"
              disabled={loading || !form.fullName || !form.email || !form.password || form.password !== form.confirm}
              className="w-full py-3 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-xl transition shadow-lg shadow-orange-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <><ShieldCheck size={16} />Créer le compte administrateur</>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
