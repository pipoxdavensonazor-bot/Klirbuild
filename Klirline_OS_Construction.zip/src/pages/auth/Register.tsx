import { useState } from 'react';
import { Eye, EyeOff, UserPlus, AlertCircle, CheckCircle, ArrowLeft, HardHat, Calculator, Briefcase } from 'lucide-react';
import { useAuth } from '../../lib/auth';

interface RegisterPageProps {
  onGoLogin: () => void;
}

const roleOptions = [
  {
    value: 'employee',
    label: 'Employé / Ouvrier',
    desc: 'Chantiers, présences, calendrier',
    icon: HardHat,
    color: 'emerald',
  },
  {
    value: 'accountant',
    label: 'Comptable',
    desc: 'Facturation, paiements, rapports',
    icon: Calculator,
    color: 'blue',
  },
  {
    value: 'manager',
    label: 'Gestionnaire',
    desc: 'Accès étendu aux modules opérationnels',
    icon: Briefcase,
    color: 'orange',
  },
];

const colorMap: Record<string, { border: string; bg: string; icon: string; label: string }> = {
  emerald: {
    border: 'border-emerald-400',
    bg: 'bg-emerald-50',
    icon: 'text-emerald-600',
    label: 'text-emerald-700',
  },
  blue: {
    border: 'border-blue-400',
    bg: 'bg-blue-50',
    icon: 'text-blue-600',
    label: 'text-blue-700',
  },
  orange: {
    border: 'border-orange-400',
    bg: 'bg-orange-50',
    icon: 'text-orange-600',
    label: 'text-orange-700',
  },
};

export default function RegisterPage({ onGoLogin }: RegisterPageProps) {
  const { signUp } = useAuth();
  const [form, setForm] = useState({ fullName: '', email: '', password: '', confirm: '', role: 'employee' });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [requiresConfirmation, setRequiresConfirmation] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (form.password !== form.confirm) { setError('Les mots de passe ne correspondent pas.'); return; }
    if (form.password.length < 8) { setError('Le mot de passe doit contenir au moins 8 caractères.'); return; }
    setLoading(true);
    const { error, requiresConfirmation } = await signUp(form.email, form.password, form.fullName, form.role);
    if (error) {
      setError(
        error.includes('already registered') ? 'Ce courriel est déjà utilisé.' :
        error.includes('Password') ? 'Mot de passe trop faible.' :
        error
      );
    } else {
      setRequiresConfirmation(requiresConfirmation);
      setSuccess(true);
    }
    setLoading(false);
  };

  const pwStrength = (pw: string): { level: number; label: string; color: string } => {
    let score = 0;
    if (pw.length >= 8) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^a-zA-Z0-9]/.test(pw)) score++;
    return [
      { level: 0, label: '', color: '' },
      { level: 1, label: 'Faible', color: 'bg-red-500' },
      { level: 2, label: 'Moyen', color: 'bg-amber-500' },
      { level: 3, label: 'Bon', color: 'bg-blue-500' },
      { level: 4, label: 'Fort', color: 'bg-emerald-500' },
    ][score] ?? { level: 0, label: '', color: '' };
  };

  const strength = pwStrength(form.password);

  if (success) {
    const chosen = roleOptions.find(r => r.value === form.role);
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-3xl shadow-2xl p-8 text-center">
            <div className={`w-16 h-16 ${requiresConfirmation ? 'bg-amber-100' : 'bg-emerald-100'} rounded-full flex items-center justify-center mx-auto mb-4`}>
              <CheckCircle size={32} className={requiresConfirmation ? 'text-amber-500' : 'text-emerald-600'} />
            </div>
            <h2 className="text-xl font-bold text-slate-900 mb-1">
              {requiresConfirmation ? 'Vérifiez votre courriel !' : 'Compte créé avec succès !'}
            </h2>
            <p className="text-slate-500 text-sm mb-5">
              {requiresConfirmation
                ? `Un lien de confirmation a été envoyé à ${form.email}. Cliquez sur ce lien pour activer votre compte.`
                : `Bienvenue dans Klirline OS, ${form.fullName.split(' ')[0]}.`
              }
            </p>
            {chosen && (
              <div className="flex items-center justify-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 mb-5">
                <chosen.icon size={16} className={colorMap[chosen.color].icon} />
                <span className="text-sm font-semibold text-slate-700">Poste : {chosen.label}</span>
              </div>
            )}
            {requiresConfirmation ? (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 text-left text-xs text-amber-700">
                <p className="font-semibold mb-1">Prochaine étape</p>
                <p>Ouvrez votre courriel et cliquez sur le lien de confirmation. Une fois confirmé, vous pourrez vous connecter normalement.</p>
              </div>
            ) : (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 text-left text-xs text-amber-700">
                Votre accès est limité à votre poste. L'administrateur peut ajuster vos permissions depuis le module Utilisateurs.
              </div>
            )}
            <button onClick={onGoLogin} className={`w-full py-3 ${requiresConfirmation ? 'bg-slate-700 hover:bg-slate-800' : 'bg-blue-600 hover:bg-blue-700'} text-white font-bold rounded-xl transition text-sm`}>
              {requiresConfirmation ? 'Retour à la connexion' : 'Se connecter maintenant'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-blue-500/8 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-emerald-500/8 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-lg">
        {/* Logo */}
        <div className="flex flex-col items-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-xl mb-3">
            <img src="/Copilot_20260624_204551.png" alt="Klirline" className="w-12 h-12 object-contain" />
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">KLIRLINE OS</h1>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header band */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-7 py-5">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
                <UserPlus size={18} className="text-white" />
              </div>
              <div>
                <h2 className="text-lg font-black text-white">Créer votre compte</h2>
                <p className="text-blue-200 text-xs">Rejoignez votre équipe Klirline OS</p>
              </div>
            </div>
          </div>

          <div className="p-7 space-y-5">
            {error && (
              <div className="flex items-start gap-3 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">
                <AlertCircle size={15} className="flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {/* Role / Poste selection */}
            <div>
              <label className="block text-sm font-bold text-slate-800 mb-2">Choisissez votre poste</label>
              <div className="grid grid-cols-3 gap-2">
                {roleOptions.map(opt => {
                  const c = colorMap[opt.color];
                  const selected = form.role === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setForm(f => ({ ...f, role: opt.value }))}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl border-2 transition text-center ${
                        selected ? `${c.border} ${c.bg}` : 'border-slate-100 hover:border-slate-300 bg-slate-50'
                      }`}
                    >
                      <opt.icon size={20} className={selected ? c.icon : 'text-slate-400'} />
                      <span className={`text-xs font-bold leading-tight ${selected ? c.label : 'text-slate-500'}`}>{opt.label}</span>
                      <span className="text-[10px] text-slate-400 leading-tight hidden sm:block">{opt.desc}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Nom complet</label>
                <input
                  type="text" required value={form.fullName}
                  onChange={e => setForm(f => ({ ...f, fullName: e.target.value }))}
                  placeholder="Jean Tremblay"
                  className="w-full px-4 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition bg-slate-50"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Courriel</label>
                <input
                  type="email" required value={form.email}
                  onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                  placeholder="jean@entreprise.com"
                  className="w-full px-4 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition bg-slate-50"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Mot de passe</label>
                <div className="relative">
                  <input
                    type={showPw ? 'text' : 'password'} required value={form.password}
                    onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                    placeholder="Min. 8 caractères"
                    className="w-full px-4 py-2.5 pr-10 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition bg-slate-50"
                  />
                  <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition">
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {form.password && (
                  <div className="mt-1.5">
                    <div className="flex gap-1">
                      {[1, 2, 3, 4].map(i => (
                        <div key={i} className={`flex-1 h-1 rounded-full transition-all ${i <= strength.level ? strength.color : 'bg-slate-100'}`} />
                      ))}
                    </div>
                    {strength.label && <p className={`text-[10px] font-medium mt-0.5 ${strength.level <= 1 ? 'text-red-500' : strength.level <= 2 ? 'text-amber-500' : 'text-emerald-600'}`}>{strength.label}</p>}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Confirmer le mot de passe</label>
                <input
                  type="password" required value={form.confirm}
                  onChange={e => setForm(f => ({ ...f, confirm: e.target.value }))}
                  placeholder="••••••••"
                  className={`w-full px-4 py-2.5 text-sm border rounded-xl focus:outline-none focus:ring-2 transition bg-slate-50 ${form.confirm && form.confirm !== form.password ? 'border-red-300 focus:ring-red-500/20' : 'border-slate-200 focus:ring-blue-500/30 focus:border-blue-400'}`}
                />
                {form.confirm && form.confirm !== form.password && (
                  <p className="text-[10px] text-red-500 mt-0.5">Les mots de passe ne correspondent pas</p>
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={handleSubmit as any}
              disabled={loading || !form.fullName || !form.email || !form.password || form.password !== form.confirm}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition shadow-lg shadow-blue-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm"
            >
              {loading
                ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                : <><UserPlus size={16} />Créer mon compte</>
              }
            </button>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-center gap-2">
              <button onClick={onGoLogin} className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 font-medium transition">
                <ArrowLeft size={14} />Retour à la connexion
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
