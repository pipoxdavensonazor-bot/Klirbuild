import { BarChart3, TrendingUp, DollarSign, PieChart, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import Header from '../components/Header';
import { StatCard, SectionCard } from '../components/ui';

export default function ComptabilitePage() {
  const fmt = (n: number) => new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD', maximumFractionDigits: 0 }).format(n);

  const months = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun'];
  const revenues = [32000, 45000, 38000, 52000, 48000, 67000];
  const expenses = [18000, 22000, 20000, 28000, 25000, 31000];
  const maxVal = Math.max(...revenues, ...expenses);

  return (
    <div className="flex flex-col h-full">
      <Header title="Comptabilité" subtitle="Aperçu financier de l'entreprise" />
      <div className="flex-1 p-6 overflow-auto space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Revenus YTD" value={fmt(282000)} sub="+12% vs l'an dernier" icon={<TrendingUp size={22} className="text-emerald-600" />} color="bg-emerald-50" />
          <StatCard label="Dépenses YTD" value={fmt(144000)} sub="-3% vs l'an dernier" icon={<ArrowDownRight size={22} className="text-red-500" />} color="bg-red-50" />
          <StatCard label="Bénéfice net" value={fmt(138000)} sub="marge 48.9%" icon={<DollarSign size={22} className="text-blue-600" />} color="bg-blue-50" />
          <StatCard label="À recevoir" value={fmt(43500)} sub="3 factures en attente" icon={<ArrowUpRight size={22} className="text-amber-600" />} color="bg-amber-50" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Revenue chart */}
          <div className="lg:col-span-2">
            <SectionCard title="Revenus vs Dépenses — 6 derniers mois">
              <div className="px-5 py-4">
                <div className="flex items-end gap-3 h-40">
                  {months.map((m, i) => (
                    <div key={m} className="flex-1 flex flex-col items-center gap-1">
                      <div className="w-full flex gap-1 items-end" style={{ height: '120px' }}>
                        <div className="flex-1 bg-emerald-500 rounded-t-md transition-all hover:bg-emerald-600" style={{ height: `${(revenues[i] / maxVal) * 120}px` }} title={fmt(revenues[i])} />
                        <div className="flex-1 bg-red-300 rounded-t-md transition-all hover:bg-red-400" style={{ height: `${(expenses[i] / maxVal) * 120}px` }} title={fmt(expenses[i])} />
                      </div>
                      <div className="text-xs text-slate-400 font-medium">{m}</div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-4 mt-3">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500"><div className="w-3 h-3 bg-emerald-500 rounded-sm" />Revenus</div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500"><div className="w-3 h-3 bg-red-300 rounded-sm" />Dépenses</div>
                </div>
              </div>
            </SectionCard>
          </div>

          {/* Expense breakdown */}
          <SectionCard title="Répartition des dépenses">
            <div className="px-5 py-4 space-y-3">
              {[
                { label: 'Main-d\'œuvre', pct: 52, color: 'bg-blue-500' },
                { label: 'Matériaux', pct: 28, color: 'bg-orange-500' },
                { label: 'Équipement', pct: 12, color: 'bg-violet-500' },
                { label: 'Administration', pct: 8, color: 'bg-slate-400' },
              ].map(item => (
                <div key={item.label}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-600">{item.label}</span>
                    <span className="font-semibold text-slate-800">{item.pct}%</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full ${item.color}`} style={{ width: `${item.pct}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </SectionCard>
        </div>

        <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-2xl border border-slate-200 p-6 text-center">
          <BarChart3 size={32} className="text-slate-400 mx-auto mb-3" />
          <h3 className="font-bold text-slate-700 mb-1">Module comptabilité avancé</h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            Connectez un logiciel comptable (QuickBooks, Sage) ou activez la comptabilité intégrée pour les journaux, le bilan, et les déclarations de taxes.
          </p>
        </div>
      </div>
    </div>
  );
}
