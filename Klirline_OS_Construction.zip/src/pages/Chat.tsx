import { useEffect, useState, useRef } from 'react';
import { MessageSquare, Plus, Send, Hash, Users, HardHat } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { ChatChannel, ChatMessage } from '../lib/types';
import Header from '../components/Header';
import { Modal, EmptyState, LoadingSpinner, FormField, inputCls } from '../components/ui';

export default function ChatPage() {
  const [channels, setChannels] = useState<ChatChannel[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeChannel, setActiveChannel] = useState<ChatChannel | null>(null);
  const [loading, setLoading] = useState(true);
  const [msgLoading, setMsgLoading] = useState(false);
  const [text, setText] = useState('');
  const [senderName, setSenderName] = useState(() => localStorage.getItem('chat_name') ?? '');
  const [showChannelModal, setShowChannelModal] = useState(false);
  const [channelForm, setChannelForm] = useState({ name: '', type: 'group' });
  const [showNameModal, setShowNameModal] = useState(false);
  const [tempName, setTempName] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  const fetchChannels = async () => {
    const { data } = await supabase.from('chat_channels').select('*, projects(name)').order('created_at', { ascending: true });
    setChannels(data as ChatChannel[] ?? []);
    setLoading(false);
  };

  const fetchMessages = async (channelId: string) => {
    setMsgLoading(true);
    const { data } = await supabase.from('chat_messages').select('*').eq('channel_id', channelId).order('created_at', { ascending: true });
    setMessages(data as ChatMessage[] ?? []);
    setMsgLoading(false);
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
  };

  useEffect(() => { fetchChannels(); }, []);
  useEffect(() => { if (activeChannel) fetchMessages(activeChannel.id); }, [activeChannel]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  useEffect(() => {
    if (!activeChannel) return;
    const channel = supabase
      .channel(`chat:${activeChannel.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `channel_id=eq.${activeChannel.id}` }, (payload) => {
        setMessages(prev => [...prev, payload.new as ChatMessage]);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [activeChannel]);

  const sendMessage = async () => {
    if (!text.trim() || !activeChannel) return;
    if (!senderName) { setShowNameModal(true); return; }
    const content = text;
    setText('');
    await supabase.from('chat_messages').insert({
      channel_id: activeChannel.id,
      sender_name: senderName,
      content,
    });
  };

  const createChannel = async () => {
    if (!channelForm.name.trim()) return;
    await supabase.from('chat_channels').insert({ name: channelForm.name, type: channelForm.type });
    setShowChannelModal(false);
    setChannelForm({ name: '', type: 'group' });
    fetchChannels();
  };

  const saveName = () => {
    setSenderName(tempName);
    localStorage.setItem('chat_name', tempName);
    setShowNameModal(false);
  };

  const channelIcon = (type: string) => {
    if (type === 'project') return <HardHat size={14} />;
    if (type === 'direct') return <Users size={14} />;
    return <Hash size={14} />;
  };

  const fmtTime = (d: string) => new Date(d).toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit' });
  const fmtDate = (d: string) => new Date(d).toLocaleDateString('fr-CA', { weekday: 'short', month: 'short', day: 'numeric' });

  const groupedMessages = messages.reduce<{ date: string; msgs: ChatMessage[] }[]>((groups, msg) => {
    const date = new Date(msg.created_at).toDateString();
    const last = groups[groups.length - 1];
    if (last?.date === date) last.msgs.push(msg);
    else groups.push({ date, msgs: [msg] });
    return groups;
  }, []);

  return (
    <div className="flex flex-col h-full">
      <Header title="Chat" subtitle="Messagerie interne" action={{ label: 'Nouveau canal', onClick: () => setShowChannelModal(true) }} />
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar channels */}
        <div className="w-64 flex-shrink-0 bg-slate-50 border-r border-slate-100 flex flex-col overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-100">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Canaux</p>
          </div>
          <div className="flex-1 overflow-y-auto py-2 px-2">
            {loading ? <LoadingSpinner /> : channels.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-8">Aucun canal</p>
            ) : channels.map(ch => (
              <button
                key={ch.id}
                onClick={() => setActiveChannel(ch)}
                className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-medium transition mb-0.5 ${activeChannel?.id === ch.id ? 'bg-orange-500 text-white' : 'text-slate-600 hover:bg-white'}`}
              >
                <span className="flex-shrink-0">{channelIcon(ch.type)}</span>
                <span className="truncate">{ch.name}</span>
              </button>
            ))}
          </div>
          <div className="px-3 pb-3">
            {senderName ? (
              <div className="flex items-center gap-2 px-3 py-2 bg-white rounded-xl border border-slate-100 text-xs text-slate-500">
                <div className="w-6 h-6 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold text-xs flex-shrink-0">
                  {senderName[0]?.toUpperCase()}
                </div>
                <span className="truncate">{senderName}</span>
                <button onClick={() => { setTempName(senderName); setShowNameModal(true); }} className="text-slate-300 hover:text-slate-500 ml-auto">✎</button>
              </div>
            ) : (
              <button onClick={() => setShowNameModal(true)} className="w-full text-xs text-orange-600 font-semibold text-center py-2 bg-orange-50 rounded-xl hover:bg-orange-100 transition">
                Définir mon nom
              </button>
            )}
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 flex flex-col min-w-0 bg-white">
          {!activeChannel ? (
            <div className="flex-1 flex items-center justify-center">
              <EmptyState icon={<MessageSquare size={28} />} title="Sélectionner un canal" description="Choisissez un canal pour afficher la conversation." action={{ label: 'Créer un canal', onClick: () => setShowChannelModal(true) }} />
            </div>
          ) : (
            <>
              <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
                <span className="text-slate-400">{channelIcon(activeChannel.type)}</span>
                <span className="font-semibold text-slate-900">{activeChannel.name}</span>
              </div>
              <div className="flex-1 overflow-y-auto px-5 py-4 space-y-1">
                {msgLoading ? <LoadingSpinner /> : messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full text-slate-400 text-sm">Aucun message. Commencez la conversation !</div>
                ) : groupedMessages.map(group => (
                  <div key={group.date}>
                    <div className="flex items-center gap-3 my-4">
                      <div className="flex-1 h-px bg-slate-100" />
                      <span className="text-xs text-slate-400 px-2">{fmtDate(group.msgs[0].created_at)}</span>
                      <div className="flex-1 h-px bg-slate-100" />
                    </div>
                    {group.msgs.map((msg, i) => {
                      const prev = i > 0 ? group.msgs[i - 1] : null;
                      const showHeader = !prev || prev.sender_name !== msg.sender_name;
                      return (
                        <div key={msg.id} className={`flex items-start gap-3 ${!showHeader ? 'mt-0.5' : 'mt-3'}`}>
                          {showHeader ? (
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white font-bold text-xs flex-shrink-0 mt-0.5">
                              {msg.sender_name[0]?.toUpperCase()}
                            </div>
                          ) : <div className="w-8 flex-shrink-0" />}
                          <div className="flex-1 min-w-0">
                            {showHeader && (
                              <div className="flex items-baseline gap-2 mb-0.5">
                                <span className="font-semibold text-slate-900 text-sm">{msg.sender_name}</span>
                                <span className="text-xs text-slate-400">{fmtTime(msg.created_at)}</span>
                              </div>
                            )}
                            <p className="text-sm text-slate-700 leading-relaxed break-words">{msg.content}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ))}
                <div ref={bottomRef} />
              </div>
              <div className="px-5 py-4 border-t border-slate-100">
                <div className="flex items-center gap-3 bg-slate-50 rounded-2xl px-4 py-2.5 border border-slate-200 focus-within:border-orange-400 focus-within:ring-2 focus-within:ring-orange-500/20 transition">
                  <input
                    value={text}
                    onChange={e => setText(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                    placeholder={`Message dans #${activeChannel.name}...`}
                    className="flex-1 bg-transparent text-sm text-slate-800 placeholder-slate-400 focus:outline-none"
                  />
                  <button onClick={sendMessage} disabled={!text.trim()} className="text-orange-500 hover:text-orange-600 disabled:text-slate-300 transition flex-shrink-0">
                    <Send size={18} />
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {showChannelModal && (
        <Modal title="Nouveau canal" onClose={() => setShowChannelModal(false)} size="sm">
          <div className="space-y-4">
            <FormField label="Nom du canal" required>
              <input className={inputCls} value={channelForm.name} onChange={e => setChannelForm(f => ({ ...f, name: e.target.value }))} placeholder="général, chantier-montréal..." />
            </FormField>
            <FormField label="Type">
              <div className="grid grid-cols-3 gap-2">
                {[{ v: 'group', l: 'Groupe' }, { v: 'project', l: 'Chantier' }, { v: 'direct', l: 'Direct' }].map(o => (
                  <button key={o.v} onClick={() => setChannelForm(f => ({ ...f, type: o.v }))}
                    className={`py-2 rounded-lg text-sm font-medium border transition ${channelForm.type === o.v ? 'border-orange-400 bg-orange-50 text-orange-700' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                    {o.l}
                  </button>
                ))}
              </div>
            </FormField>
            <div className="flex justify-end gap-3 pt-2 border-t border-slate-100">
              <button onClick={() => setShowChannelModal(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
              <button onClick={createChannel} disabled={!channelForm.name.trim()} className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50">Créer</button>
            </div>
          </div>
        </Modal>
      )}

      {showNameModal && (
        <Modal title="Votre nom d'affichage" onClose={() => setShowNameModal(false)} size="sm">
          <div className="space-y-4">
            <FormField label="Nom" required>
              <input className={inputCls} value={tempName} onChange={e => setTempName(e.target.value)} placeholder="Philippe Martin" onKeyDown={e => e.key === 'Enter' && tempName && saveName()} autoFocus />
            </FormField>
            <div className="flex justify-end gap-3 pt-2 border-t border-slate-100">
              <button onClick={() => setShowNameModal(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
              <button onClick={saveName} disabled={!tempName.trim()} className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50">Confirmer</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
