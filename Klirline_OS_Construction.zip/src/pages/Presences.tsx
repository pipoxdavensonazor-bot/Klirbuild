import { useEffect, useState } from 'react';
import { Clock, Play, Square, MapPin, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { TimeEntry, Employee, Project } from '../lib/types';
import Header from '../components/Header';
import { Modal, Badge, EmptyState, LoadingSpinner, FormField, selectCls, SectionCard, useToast, Toast } from '../components/ui';

export default function PresencesPage() {
  const [entries, setEntries] = useState<TimeEntry[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [clockInForm, setClockInForm] = useState<{ employee_id: string; project_id: string }>({ employee_id: '', project_id: '' });
  const [saving, setSaving] = useState(false);
  const [dateFilter, setDateFilter] = useState(() => new Date().toISOString().split('T')[0]);
  const { toast, showToast } = useToast();

  const fetchEntries = async () => {
    setLoading(true);
    const start = new Date(dateFilter);
    start.setHours(0, 0, 0, 0);
    const end = new Date(dateFilter);
    end.setHours(23, 59, 59, 999);
    const { data, error } = await supabase
      .from('time_entries')
      .select('*, employees(first_name,last_name,role), projects(name)')
      .gte('clock_in', start.toISOString())
      .lte('clock_in', end.toISOString())
      .order('clock_in', { ascending: false });
    if (error) showToast('error', 'Impossible de charger les présences.');
    setEntries(data as TimeEntry[] ?? []);
    setLoading(false);
  };

  useEffect(() => {
    fetchEntries();
    supabase.from('employees').select('id,first_name,last_name,status').eq('status', 'active').then(({ data }) => setEmployees(data as Employee[] ?? []));
    supabase.from('projects').select('id,name,status').eq('status', 'active').then(({ data }) => setProjects(data as Project[] ?? []));
  }, [dateFilter]);

  const handleClockIn = async () => {
    if (!clockInForm.employee_id) return;
    setSaving(true);
    const { error } = await supabase.from('time_entries').insert({
      employee_id: clockInForm.employee_id,
      project_id: clockInForm.project_id || null,
      clock_in: new Date().toISOString(),
      status: 'active',
    });
    if (error) { showToast('error', 'Erreur lors du pointage.'); setSaving(false); return; }
    showToast('success', 'Entrée pointée.');
    setSaving(false);
    setShowModal(false);
    setClockInForm({ employee_id: '', project_id: '' });
    fetchEntries();
  };

  const handleClockOut = async (id: string) => {
    const { error } = await supabase.from('time_entries').update({ clock_out: new Date().toISOString(), status: 'completed' }).eq('id', id);
    if (error) { showToast('error', 'Erreur lors du pointage de sortie.'); return; }
    showToast('success', 'Sortie pointée.');
    fetchEntries();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer cette présence ?')) return;
    const { error } = await supabase.from('time_entries').delete().eq('id', id);
    if (error) { showToast('error', 'Impossible de supprimer cette présence.'); return; }
    showToast('success', 'Présence supprimée.');
    fetchEntries();
  };

  const filtered = entries.filter(e => {
    const emp = e.employees as any;
    const q = search.toLowerCase();
    return !q || `${emp?.first_name} ${emp?.last_name}`.toLowerCase().includes(q);
  });

  const active = filtered.filter(e => e.status === 'active');
  const completed = filtered.filter(e => e.status === 'completed');

  const duration = (start: string, end?: string | null) => {
    const from = new Date(start).getTime();
    const to = end ? new Date(end).getTime() : Date.now();
    const diffMs = to - from;
    const h = Math.floor(diffMs / 3600000);
    const m = Math.floor((diffMs % 3600000) / 60000);
    return `${h}h ${m.toString().padStart(2, '0')}m`;
  };

  const totalHours = completed.reduce((sum, e) => {
    if (!e.clock_out) return sum;
    return sum + (new Date(e.clock_out).getTime() - new Date(e.clock_in).getTime()) / 3600000;
  }, 0);

  return (
    <div className="flex flex-col h-full">
      <Header
        title="Présences"
        subtitle={`${active.length} actif${active.length !== 1 ? 's' : ''} · ${totalHours.toFixed(1)}h total aujourd'hui`}
        action={{ label: 'Pointer entrée', onClick: () => setShowModal(true) }}
      />
      <div className="flex-1 p-6 overflow-auto space-y-5">
        {/* Date + search */}
        <div className="flex gap-3 flex-wrap">
          <input
            type="date"
            value={dateFilter}
            onChange={e => setDateFilter(e.target.value)}
            className="px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white transition"
          />
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher employé..." className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white transition w-52" />
          </div>
        </div>

        {loading ? <LoadingSpinner /> : (
          <>
            {/* Active */}
            {active.length > 0 && (
              <SectionCard title={`Actifs (${active.length})`}>
                <div className="divide-y divide-slate-50">
                  {active.map(e => {
                    const emp = e.employees as any;
                    const proj = e.projects as any;
                    return (
                      <div key={e.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50/80 transition">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold flex-shrink-0">
                            {emp?.first_name?.[0]}{emp?.last_name?.[0]}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900 text-sm">{emp?.first_name} {emp?.last_name}</div>
                            <div className="text-xs text-slate-400 flex items-center gap-1.5">
                              {proj?.name && <><MapPin size={10} />{proj.name}</>}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <div className="text-xs text-slate-400">Arrivée</div>
                            <div className="text-sm font-semibold text-slate-700">{new Date(e.clock_in).toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit' })}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-xs text-emerald-600 font-semibold bg-emerald-50 px-2 py-1 rounded-full animate-pulse">
                              {duration(e.clock_in)}
                            </div>
                          </div>
                          <button
                            onClick={() => handleClockOut(e.id)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-semibold rounded-lg transition"
                          >
                            <Square size={12} fill="currentColor" />Pointer sortie
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </SectionCard>
            )}

            {/* Completed */}
            {completed.length === 0 && active.length === 0 ? (
              <EmptyState icon={<Clock size={28} />} title="Aucune présence" description={`Aucun pointage le ${dateFilter}.`} action={{ label: 'Pointer entrée', onClick: () => setShowModal(true) }} />
            ) : completed.length > 0 && (
              <SectionCard title={`Complétées (${completed.length})`}>
                <div className="divide-y divide-slate-50">
                  {completed.map(e => {
                    const emp = e.employees as any;
                    const proj = e.projects as any;
                    return (
                      <div key={e.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50/80 transition">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 font-bold flex-shrink-0">
                            {emp?.first_name?.[0]}{emp?.last_name?.[0]}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900 text-sm">{emp?.first_name} {emp?.last_name}</div>
                            <div className="text-xs text-slate-400">{proj?.name ?? 'Aucun chantier'}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <div className="text-xs text-slate-400">Entrée</div>
                            <div className="text-sm font-medium text-slate-700">{new Date(e.clock_in).toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit' })}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-xs text-slate-400">Sortie</div>
                            <div className="text-sm font-medium text-slate-700">{e.clock_out ? new Date(e.clock_out).toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit' }) : '—'}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-xs text-slate-400">Durée</div>
                            <div className="text-sm font-semibold text-slate-800">{duration(e.clock_in, e.clock_out)}</div>
                          </div>
                          <button onClick={() => handleDelete(e.id)} className="text-xs text-slate-300 hover:text-red-500 transition">×</button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </SectionCard>
            )}
          </>
        )}
      </div>

      {showModal && (
        <Modal title="Pointer une entrée" onClose={() => setShowModal(false)} size="sm">
          <div className="space-y-4">
            <div className="flex items-center justify-center">
              <div className="w-20 h-20 rounded-2xl bg-emerald-100 flex items-center justify-center">
                <Play size={32} className="text-emerald-600 fill-emerald-600" />
              </div>
            </div>
            <p className="text-center text-sm text-slate-500">Heure d'arrivée : <span className="font-semibold text-slate-800">{new Date().toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit' })}</span></p>
            <FormField label="Employé" required>
              <select className={selectCls} value={clockInForm.employee_id} onChange={e => setClockInForm(f => ({ ...f, employee_id: e.target.value }))}>
                <option value="">— Sélectionner un employé —</option>
                {employees.map(e => <option key={e.id} value={e.id}>{e.first_name} {e.last_name}</option>)}
              </select>
            </FormField>
            <FormField label="Chantier">
              <select className={selectCls} value={clockInForm.project_id} onChange={e => setClockInForm(f => ({ ...f, project_id: e.target.value }))}>
                <option value="">— Aucun chantier —</option>
                {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </FormField>
            <button
              onClick={handleClockIn}
              disabled={saving || !clockInForm.employee_id}
              className="w-full py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Play size={16} fill="currentColor" />
              {saving ? 'Enregistrement...' : 'Commencer le travail'}
            </button>
          </div>
        </Modal>
      )}
      <Toast toast={toast} />
    </div>
  );
}
