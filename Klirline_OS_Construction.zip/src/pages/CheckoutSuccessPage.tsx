import React, { useEffect, useState } from 'react';
import { CheckCircle, ArrowRight, Loader2 } from 'lucide-react';
import { useSubscription } from '../hooks/useSubscription';

export function CheckoutSuccessPage() {
  const { subscription, loading } = useSubscription();
  const [countdown, setCountdown] = useState(8);

  useEffect(() => {
    if (countdown <= 0) {
      window.location.href = '/';
      return;
    }
    const timer = setTimeout(() => setCountdown(c => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [countdown]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-indigo-50 via-white to-emerald-50 px-4">
      <div className="w-full max-w-md text-center">
        {/* Animated checkmark */}
        <div className="mx-auto mb-8 flex h-24 w-24 items-center justify-center rounded-full bg-emerald-100 ring-8 ring-emerald-50">
          <CheckCircle className="h-12 w-12 text-emerald-500" strokeWidth={1.5} />
        </div>

        <h1 className="text-3xl font-extrabold tracking-tight text-gray-900">
          Payment Successful!
        </h1>
        <p className="mt-3 text-lg text-gray-500">
          Thank you for your purchase. Your account has been updated.
        </p>

        {/* Plan info */}
        <div className="mt-8 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
          {loading ? (
            <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
              <Loader2 className="h-4 w-4 animate-spin" />
              Loading your plan details…
            </div>
          ) : subscription.isActive && subscription.planName ? (
            <div>
              <p className="text-sm font-medium text-gray-500">Active Plan</p>
              <p className="mt-1 text-2xl font-bold text-indigo-600">{subscription.planName}</p>
              <p className="mt-1 text-sm text-emerald-600">✓ Active &amp; ready to use</p>
            </div>
          ) : (
            <div>
              <p className="text-sm text-gray-500">Your payment was processed successfully.</p>
              <p className="mt-1 text-xs text-gray-400">It may take a moment for your account to update.</p>
            </div>
          )}
        </div>

        {/* Redirect countdown */}
        <p className="mt-6 text-sm text-gray-400">
          Redirecting you home in {countdown}s…
        </p>

        {/* Manual redirect */}
        <button
          onClick={() => (window.location.href = '/')}
          className="mt-4 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-3 text-sm font-semibold text-white shadow-sm transition-all hover:bg-indigo-700 active:scale-95"
        >
          Go to Dashboard
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}