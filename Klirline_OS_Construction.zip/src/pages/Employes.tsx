import { useEffect, useState } from 'react';
import { UserCircle, Search, Phone, Mail, DollarSign, Briefcase } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Employee } from '../lib/types';
import Header from '../components/Header';
import { Modal, Badge, EmptyState, LoadingSpinner, FormField, inputCls, selectCls, textareaCls, useToast, Toast } from '../components/ui';

const roleOptions = [
  { value: 'admin', label: 'Administrateur' },
  { value: 'manager', label: 'Gestionnaire' },
  { value: 'foreman', label: 'Contremaître' },
  { value: 'worker', label: 'Ouvrier' },
  { value: 'accountant', label: 'Comptable' },
];
const roleColor: Record<string, 'blue' | 'orange' | 'green' | 'slate' | 'purple'> = {
  admin: 'purple', manager: 'blue', foreman: 'orange', worker: 'green', accountant: 'slate',
};
const statusColor: Record<string, 'green' | 'slate' | 'yellow'> = {
  active: 'green', inactive: 'slate', on_leave: 'yellow',
};
const statusLabel: Record<string, string> = {
  active: 'Actif', inactive: 'Inactif', on_leave: 'En congé',
};

export default function EmployesPage() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Partial<Employee>>({});
  const { toast, showToast } = useToast();

  const loadEmployees = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('employees').select('*').order('first_name', { ascending: true });
    if (error) showToast('error', 'Impossible de charger les employés.');
    setEmployees(data as Employee[] ?? []);
    setLoading(false);
  };

  useEffect(() => { loadEmployees(); }, []);

  const openCreate = () => { setEditing(null); setForm({ role: 'worker', status: 'active' }); setShowModal(true); };
  const openEdit = (e: Employee) => { setEditing(e); setForm({ ...e }); setShowModal(true); };

  const handleSave = async () => {
    setSaving(true);
    if (editing) {
      const { error } = await supabase.from('employees').update(form).eq('id', editing.id);
      if (error) { showToast('error', 'Erreur lors de la mise à jour.'); setSaving(false); return; }
    } else {
      const { error } = await supabase.from('employees').insert({ ...form, first_name: form.first_name ?? '', last_name: form.last_name ?? '' });
      if (error) { showToast('error', 'Erreur lors de la création.'); setSaving(false); return; }
    }
    showToast('success', editing ? 'Employé mis à jour.' : 'Employé créé.');
    setSaving(false);
    setShowModal(false);
    loadEmployees();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer cet employé ?')) return;
    const { error } = await supabase.from('employees').delete().eq('id', id);
    if (error) { showToast('error', 'Impossible de supprimer cet employé.'); return; }
    showToast('success', 'Employé supprimé.');
    loadEmployees();
  };

  const filtered = employees.filter(e => {
    const q = search.toLowerCase();
    return [e.first_name, e.last_name, e.email, e.department].some(v => v?.toLowerCase().includes(q));
  });

  const fmt = (n: number) => new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD', maximumFractionDigits: 0 }).format(n);

  return (
    <div className="flex flex-col h-full">
      <Header title="Employés" subtitle={`${employees.filter(e => e.status === 'active').length} actif${employees.filter(e => e.status === 'active').length !== 1 ? 's' : ''} sur ${employees.length}`} action={{ label: 'Nouvel employé', onClick: openCreate }} />
      <div className="flex-1 p-6 overflow-auto">
        <div className="mb-4 relative max-w-sm">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher un employé..." className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white transition" />
        </div>

        {loading ? <LoadingSpinner /> : filtered.length === 0 ? (
          <EmptyState icon={<UserCircle size={28} />} title="Aucun employé" description="Ajoutez votre premier employé." action={{ label: 'Nouvel employé', onClick: openCreate }} />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filtered.map(e => {
              const roleOpt = roleOptions.find(r => r.value === e.role);
              return (
                <div key={e.id} className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center text-slate-700 font-bold text-lg flex-shrink-0">
                        {e.first_name[0]}{e.last_name[0]}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900">{e.first_name} {e.last_name}</div>
                        <div className="text-xs text-slate-400">{e.department ?? 'Aucun département'}</div>
                      </div>
                    </div>
                    <Badge label={statusLabel[e.status]} color={statusColor[e.status]} />
                  </div>
                  <div className="space-y-1.5 mb-4">
                    <Badge label={roleOpt?.label ?? e.role} color={roleColor[e.role] ?? 'slate'} />
                    {e.email && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-2">
                        <Mail size={11} />{e.email}
                      </div>
                    )}
                    {e.phone && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <Phone size={11} />{e.phone}
                      </div>
                    )}
                    {e.salary && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <DollarSign size={11} />{fmt(e.salary)} / an
                      </div>
                    )}
                    {e.hire_date && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <Briefcase size={11} />Embauché le {e.hire_date}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2 pt-3 border-t border-slate-50">
                    <button onClick={() => openEdit(e)} className="flex-1 text-center text-xs font-semibold text-orange-600 hover:text-orange-700 transition">Modifier</button>
                    <button onClick={() => handleDelete(e.id)} className="flex-1 text-center text-xs font-semibold text-red-400 hover:text-red-600 transition">Supprimer</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {showModal && (
        <Modal title={editing ? 'Modifier l\'employé' : 'Nouvel employé'} onClose={() => setShowModal(false)} size="lg">
          <div className="grid grid-cols-2 gap-4">
            <FormField label="Prénom" required>
              <input className={inputCls} value={form.first_name ?? ''} onChange={e => setForm(f => ({ ...f, first_name: e.target.value }))} />
            </FormField>
            <FormField label="Nom" required>
              <input className={inputCls} value={form.last_name ?? ''} onChange={e => setForm(f => ({ ...f, last_name: e.target.value }))} />
            </FormField>
            <FormField label="Courriel">
              <input className={inputCls} type="email" value={form.email ?? ''} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            </FormField>
            <FormField label="Téléphone">
              <input className={inputCls} value={form.phone ?? ''} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
            </FormField>
            <FormField label="Rôle">
              <select className={selectCls} value={form.role ?? 'worker'} onChange={e => setForm(f => ({ ...f, role: e.target.value as any }))}>
                {roleOptions.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
              </select>
            </FormField>
            <FormField label="Département">
              <input className={inputCls} value={form.department ?? ''} onChange={e => setForm(f => ({ ...f, department: e.target.value }))} placeholder="Chantier, Comptabilité..." />
            </FormField>
            <FormField label="Date d'embauche">
              <input className={inputCls} type="date" value={form.hire_date ?? ''} onChange={e => setForm(f => ({ ...f, hire_date: e.target.value }))} />
            </FormField>
            <FormField label="Salaire annuel ($)">
              <input className={inputCls} type="number" value={form.salary ?? ''} onChange={e => setForm(f => ({ ...f, salary: parseFloat(e.target.value) || undefined }))} />
            </FormField>
            <FormField label="Statut">
              <select className={selectCls} value={form.status ?? 'active'} onChange={e => setForm(f => ({ ...f, status: e.target.value as any }))}>
                <option value="active">Actif</option>
                <option value="inactive">Inactif</option>
                <option value="on_leave">En congé</option>
              </select>
            </FormField>
            <FormField label="Notes">
              <textarea className={textareaCls} rows={3} value={form.notes ?? ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </FormField>
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-slate-100">
            <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition">Annuler</button>
            <button onClick={handleSave} disabled={saving || !form.first_name || !form.last_name} className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50">
              {saving ? 'Enregistrement...' : 'Enregistrer'}
            </button>
          </div>
        </Modal>
      )}
      <Toast toast={toast} />
    </div>
  );
}
