import { useEffect, useState, useCallback } from 'react';
import {
  ClipboardList, Search, Plus, Trash2, Eye, CheckCircle,
  XCircle, Send, ArrowRight, Copy, AlertCircle, Building2,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Soumission, SoumissionItem } from '../lib/types';
import Header from '../components/Header';
import { Modal, Badge, EmptyState, LoadingSpinner, FormField, inputCls, selectCls, textareaCls } from '../components/ui';
import { useCompanySettings } from '../lib/useCompanySettings';

// ── helpers ────────────────────────────────────────────────────────────────────

const TPS_RATE = 5;
const TVQ_RATE = 9.975;

const STATUS_META: Record<string, { label: string; color: 'slate' | 'blue' | 'green' | 'red' | 'orange' | 'yellow' }> = {
  brouillon: { label: 'Brouillon',  color: 'slate'  },
  envoyée:   { label: 'Envoyée',    color: 'blue'   },
  approuvée: { label: 'Approuvée',  color: 'green'  },
  refusée:   { label: 'Refusée',    color: 'red'    },
  expirée:   { label: 'Expirée',    color: 'orange' },
};

const UNITS = ['forfait', 'h', 'jour', 'm²', 'pi²', 'm³', 'pi³', 'ml', 'pcs', 'tonnes', 'kg', 'L'];

const fmt = (n: number) =>
  new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD' }).format(n);

const today = () => new Date().toISOString().split('T')[0];

interface ItemRow {
  id?: string;
  description: string;
  quantity: number;
  unit: string;
  unit_price: number;
  total: number;
}

interface ClientRow {
  id: string;
  name: string;
  company: string | null;
}

const emptyItem = (): ItemRow => ({ description: '', quantity: 1, unit: 'forfait', unit_price: 0, total: 0 });

function calcTotals(items: ItemRow[], tpsRate: number, tvqRate: number) {
  const subtotal = items.reduce((s, r) => s + r.total, 0);
  const tps = (subtotal * tpsRate) / 100;
  const tvq = (subtotal * tvqRate) / 100;
  return { subtotal, tps_amount: tps, tvq_amount: tvq, total: subtotal + tps + tvq };
}

// ── component ──────────────────────────────────────────────────────────────────

export default function SoumissionsPage() {
  const [soumissions, setSoumissions] = useState<Soumission[]>([]);
  const [clients, setClients] = useState<ClientRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const { settings: company } = useCompanySettings();

  // modal states
  const [showForm, setShowForm] = useState(false);
  const [viewSom, setViewSom] = useState<Soumission | null>(null);
  const [viewItems, setViewItems] = useState<SoumissionItem[]>([]);
  const [editing, setEditing] = useState<Soumission | null>(null);
  const [saving, setSaving] = useState(false);
  const [converting, setConverting] = useState(false);

  // form state
  const [form, setForm] = useState<Partial<Soumission>>({});
  const [items, setItems] = useState<ItemRow[]>([emptyItem()]);

  const fetchSoumissions = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('soumissions')
      .select('*, clients(id, name, company)')
      .order('created_at', { ascending: false });
    setSoumissions((data as Soumission[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchSoumissions();
    supabase.from('clients').select('id, name, company').then(({ data }) =>
      setClients((data as ClientRow[]) ?? [])
    );
  }, [fetchSoumissions]);

  // ── numbering ────────────────────────────────────────────────────────────────

  const nextNo = () => {
    const year = new Date().getFullYear();
    const nums = soumissions
      .map(s => parseInt(s.soumission_no.split('-')[2] ?? '0', 10))
      .filter(n => !isNaN(n));
    const next = nums.length ? Math.max(...nums) + 1 : 1;
    return `SOM-${year}-${next.toString().padStart(4, '0')}`;
  };

  // ── open handlers ────────────────────────────────────────────────────────────

  const openCreate = () => {
    setEditing(null);
    const d = today();
    const valid = new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0];
    setForm({
      soumission_no: nextNo(),
      status: 'brouillon',
      issue_date: d,
      valid_until: valid,
      tps_rate: TPS_RATE,
      tvq_rate: TVQ_RATE,
    });
    setItems([emptyItem()]);
    setShowForm(true);
  };

  const openEdit = async (som: Soumission) => {
    setEditing(som);
    setForm({ ...som });
    const { data } = await supabase
      .from('soumission_items')
      .select('*')
      .eq('soumission_id', som.id)
      .order('sort_order');
    setItems(
      ((data as SoumissionItem[]) ?? []).map(r => ({
        id: r.id,
        description: r.description,
        quantity: r.quantity,
        unit: r.unit,
        unit_price: r.unit_price,
        total: r.total,
      }))
    );
    setShowForm(true);
  };

  const openView = async (som: Soumission) => {
    setViewSom(som);
    const { data } = await supabase
      .from('soumission_items')
      .select('*')
      .eq('soumission_id', som.id)
      .order('sort_order');
    setViewItems((data as SoumissionItem[]) ?? []);
  };

  // ── item editing ─────────────────────────────────────────────────────────────

  const updateItem = (i: number, field: keyof ItemRow, val: string | number) => {
    setItems(prev => {
      const next = [...prev];
      const row = { ...next[i], [field]: val };
      if (field === 'quantity' || field === 'unit_price') {
        row.total = Number(row.quantity) * Number(row.unit_price);
      }
      next[i] = row;
      return next;
    });
  };

  const addItem = () => setItems(p => [...p, emptyItem()]);
  const removeItem = (i: number) => setItems(p => p.filter((_, j) => j !== i));

  // ── save ──────────────────────────────────────────────────────────────────────

  const handleSave = async () => {
    setSaving(true);
    const { subtotal, tps_amount, tvq_amount, total } = calcTotals(
      items, form.tps_rate ?? TPS_RATE, form.tvq_rate ?? TVQ_RATE
    );
    const payload = {
      ...form,
      subtotal,
      tps_amount,
      tvq_amount,
      total,
      updated_at: new Date().toISOString(),
    };

    let somId = editing?.id;
    if (editing) {
      await supabase.from('soumissions').update(payload).eq('id', editing.id);
      await supabase.from('soumission_items').delete().eq('soumission_id', editing.id);
    } else {
      const { data } = await supabase
        .from('soumissions')
        .insert(payload)
        .select('id')
        .single();
      somId = data?.id;
    }

    if (somId) {
      const rows = items
        .filter(r => r.description.trim())
        .map((r, i) => ({ soumission_id: somId, ...r, sort_order: i }));
      if (rows.length) await supabase.from('soumission_items').insert(rows);
    }

    setSaving(false);
    setShowForm(false);
    fetchSoumissions();
  };

  // ── status update ─────────────────────────────────────────────────────────────

  const updateStatus = async (id: string, status: string) => {
    await supabase.from('soumissions').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
    if (viewSom?.id === id) setViewSom(v => v ? { ...v, status: status as Soumission['status'] } : null);
    fetchSoumissions();
  };

  // ── convert to invoice ────────────────────────────────────────────────────────

  const convertToInvoice = async (som: Soumission) => {
    if (!confirm('Convertir cette soumission en facture ?')) return;
    setConverting(true);

    const invoiceNo = `INV-${new Date().getFullYear()}-${String(Date.now()).slice(-4)}`;
    const dueDate = new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0];

    const { data: inv, error } = await supabase
      .from('invoices')
      .insert({
        number: invoiceNo,
        client_id: som.client_id,
        issue_date: today(),
        due_date: dueDate,
        status: 'draft',
        subtotal: som.subtotal,
        tax_rate: som.tps_rate + som.tvq_rate,
        tax_amount: som.tps_amount + som.tvq_amount,
        total: som.total,
        notes: `Converti de ${som.soumission_no} — ${som.titre}`,
      })
      .select('id')
      .single();

    if (error || !inv) { setConverting(false); return; }

    // copy items
    const { data: sitems } = await supabase
      .from('soumission_items')
      .select('*')
      .eq('soumission_id', som.id)
      .order('sort_order');

    if (sitems?.length) {
      await supabase.from('invoice_items').insert(
        sitems.map((r: SoumissionItem) => ({
          invoice_id: inv.id,
          description: r.description,
          quantity: r.quantity,
          unit_price: r.unit_price,
          total: r.total,
        }))
      );
    }

    await supabase.from('soumissions').update({
      status: 'approuvée',
      converted_invoice_id: inv.id,
      updated_at: new Date().toISOString(),
    }).eq('id', som.id);

    setConverting(false);
    setViewSom(null);
    fetchSoumissions();
    window.dispatchEvent(new CustomEvent('klirline:navigate', { detail: 'facturation' }));
  };

  // ── delete ────────────────────────────────────────────────────────────────────

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer cette soumission ?')) return;
    await supabase.from('soumissions').delete().eq('id', id);
    if (viewSom?.id === id) setViewSom(null);
    fetchSoumissions();
  };

  // ── filter / display ──────────────────────────────────────────────────────────

  const filtered = soumissions.filter(s => {
    const c = s.clients as any;
    const q = search.toLowerCase();
    const matchQ = [s.soumission_no, s.titre, c?.name, c?.company].some(v =>
      v?.toLowerCase().includes(q)
    );
    return matchQ && (statusFilter === 'all' || s.status === statusFilter);
  });

  const totals = calcTotals(items, form.tps_rate ?? TPS_RATE, form.tvq_rate ?? TVQ_RATE);

  // ── summary cards ─────────────────────────────────────────────────────────────
  const statuses = Object.keys(STATUS_META);
  const statusCounts = Object.fromEntries(
    statuses.map(s => [s, soumissions.filter(x => x.status === s)])
  );
  const totalPipeline = soumissions
    .filter(s => ['envoyée', 'approuvée'].includes(s.status))
    .reduce((sum, s) => sum + s.total, 0);

  return (
    <div className="flex flex-col h-full">
      <Header
        title="Soumissions"
        subtitle={`${soumissions.length} soumission${soumissions.length !== 1 ? 's' : ''} · pipeline ${fmt(totalPipeline)}`}
        action={{ label: 'Nouvelle soumission', onClick: openCreate }}
      />

      <div className="flex-1 p-6 overflow-auto">
        {/* Summary cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-5">
          {statuses.map(s => {
            const meta = STATUS_META[s];
            const list = statusCounts[s] ?? [];
            const amt = list.reduce((sum, x) => sum + x.total, 0);
            return (
              <button
                key={s}
                onClick={() => setStatusFilter(s === statusFilter ? 'all' : s)}
                className={`p-3 rounded-xl border text-left transition ${
                  statusFilter === s
                    ? 'border-orange-400 bg-orange-50'
                    : 'border-slate-100 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="text-xs font-semibold text-slate-500 mb-1">{meta.label}</div>
                <div className="text-xl font-bold text-slate-900">{list.length}</div>
                <div className="text-xs text-slate-400 mt-0.5">{fmt(amt)}</div>
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div className="flex gap-3 mb-4">
          <div className="relative max-w-sm">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Rechercher soumission..."
              className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-400 bg-white transition"
            />
          </div>
        </div>

        {/* Table */}
        {loading ? (
          <LoadingSpinner />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={<ClipboardList size={28} />}
            title="Aucune soumission"
            description="Créez votre première soumission pour démarrer le cycle de vente."
            action={{ label: 'Nouvelle soumission', onClick: openCreate }}
          />
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">N°</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Titre</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden md:table-cell">Client</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider hidden lg:table-cell">Valide jusqu'au</th>
                  <th className="text-right px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Total</th>
                  <th className="text-left px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wider">Statut</th>
                  <th className="px-5 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map(som => {
                  const c = som.clients as any;
                  const meta = STATUS_META[som.status];
                  const isExpired =
                    som.valid_until &&
                    new Date(som.valid_until) < new Date() &&
                    som.status === 'envoyée';
                  return (
                    <tr key={som.id} className="hover:bg-slate-50/80 transition">
                      <td className="px-5 py-3.5 font-mono font-medium text-slate-700 text-xs">{som.soumission_no}</td>
                      <td className="px-5 py-3.5 font-medium text-slate-900 max-w-[200px] truncate">{som.titre}</td>
                      <td className="px-5 py-3.5 hidden md:table-cell text-slate-500">
                        {c ? c.company ?? c.name : <span className="text-slate-300">—</span>}
                      </td>
                      <td className="px-5 py-3.5 hidden lg:table-cell">
                        {som.valid_until ? (
                          <span className={isExpired ? 'text-red-500 font-medium' : 'text-slate-500'}>
                            {som.valid_until}
                          </span>
                        ) : <span className="text-slate-300">—</span>}
                      </td>
                      <td className="px-5 py-3.5 text-right font-bold text-slate-900">{fmt(som.total)}</td>
                      <td className="px-5 py-3.5">
                        {meta && <Badge label={meta.label} color={meta.color} />}
                        {som.converted_invoice_id && (
                          <span className="ml-2 text-xs text-emerald-600 font-medium">facturée</span>
                        )}
                      </td>
                      <td className="px-5 py-3.5 text-right space-x-1 whitespace-nowrap">
                        <button
                          onClick={() => openView(som)}
                          className="text-slate-400 hover:text-blue-600 px-2 py-1 rounded transition text-xs font-medium"
                        >
                          Voir
                        </button>
                        {som.status === 'brouillon' && (
                          <button
                            onClick={() => openEdit(som)}
                            className="text-slate-400 hover:text-orange-600 px-2 py-1 rounded transition text-xs font-medium"
                          >
                            Modifier
                          </button>
                        )}
                        <button
                          onClick={() => handleDelete(som.id)}
                          className="text-slate-400 hover:text-red-500 px-2 py-1 rounded transition text-xs font-medium"
                        >
                          Suppr.
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ── Form Modal ──────────────────────────────────────────────────────────── */}
      {showForm && (
        <Modal
          title={editing ? `Modifier ${editing.soumission_no}` : 'Nouvelle soumission'}
          onClose={() => setShowForm(false)}
          size="xl"
        >
          <div className="space-y-5">
            {/* Header fields */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <FormField label="N° Soumission">
                <input
                  className={inputCls}
                  value={form.soumission_no ?? ''}
                  onChange={e => setForm(f => ({ ...f, soumission_no: e.target.value }))}
                />
              </FormField>
              <FormField label="Client">
                <select
                  className={selectCls}
                  value={form.client_id ?? ''}
                  onChange={e => setForm(f => ({ ...f, client_id: e.target.value || undefined }))}
                >
                  <option value="">— Aucun —</option>
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>{c.company ?? c.name}</option>
                  ))}
                </select>
              </FormField>
              <FormField label="Statut">
                <select
                  className={selectCls}
                  value={form.status ?? 'brouillon'}
                  onChange={e => setForm(f => ({ ...f, status: e.target.value as Soumission['status'] }))}
                >
                  {Object.entries(STATUS_META).map(([val, { label }]) => (
                    <option key={val} value={val}>{label}</option>
                  ))}
                </select>
              </FormField>
              <FormField label="Date d'émission">
                <input
                  className={inputCls}
                  type="date"
                  value={form.issue_date ?? ''}
                  onChange={e => setForm(f => ({ ...f, issue_date: e.target.value }))}
                />
              </FormField>
              <FormField label="Valide jusqu'au">
                <input
                  className={inputCls}
                  type="date"
                  value={form.valid_until ?? ''}
                  onChange={e => setForm(f => ({ ...f, valid_until: e.target.value }))}
                />
              </FormField>
              <FormField label="Titre de la soumission">
                <input
                  className={inputCls}
                  value={form.titre ?? ''}
                  onChange={e => setForm(f => ({ ...f, titre: e.target.value }))}
                  placeholder="Ex: Rénovation toiture — 123 rue des Érables"
                />
              </FormField>
            </div>

            {/* Tax rates */}
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Taux TPS (%)">
                <input
                  className={inputCls}
                  type="number"
                  step="0.001"
                  value={form.tps_rate ?? TPS_RATE}
                  onChange={e => setForm(f => ({ ...f, tps_rate: parseFloat(e.target.value) }))}
                />
              </FormField>
              <FormField label="Taux TVQ (%)">
                <input
                  className={inputCls}
                  type="number"
                  step="0.001"
                  value={form.tvq_rate ?? TVQ_RATE}
                  onChange={e => setForm(f => ({ ...f, tvq_rate: parseFloat(e.target.value) }))}
                />
              </FormField>
            </div>

            {/* Line items */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold text-slate-700">Lignes de travail</label>
                <button
                  onClick={addItem}
                  className="text-xs text-orange-600 hover:text-orange-700 font-semibold flex items-center gap-1"
                >
                  <Plus size={12} /> Ajouter une ligne
                </button>
              </div>
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="text-left px-3 py-2 text-xs font-semibold text-slate-500">Description</th>
                      <th className="text-right px-2 py-2 text-xs font-semibold text-slate-500 w-20">Qté</th>
                      <th className="text-left px-2 py-2 text-xs font-semibold text-slate-500 w-24">Unité</th>
                      <th className="text-right px-2 py-2 text-xs font-semibold text-slate-500 w-28">Prix unit.</th>
                      <th className="text-right px-3 py-2 text-xs font-semibold text-slate-500 w-24">Sous-total</th>
                      <th className="w-8" />
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {items.map((row, i) => (
                      <tr key={i}>
                        <td className="px-2 py-1.5">
                          <input
                            className="w-full px-2 py-1 text-sm border-0 focus:outline-none bg-transparent"
                            value={row.description}
                            onChange={e => updateItem(i, 'description', e.target.value)}
                            placeholder="Ex: Main-d'oeuvre installation..."
                          />
                        </td>
                        <td className="px-2 py-1.5">
                          <input
                            className="w-full px-2 py-1 text-sm text-right border-0 focus:outline-none bg-transparent"
                            type="number"
                            min="0"
                            value={row.quantity}
                            onChange={e => updateItem(i, 'quantity', parseFloat(e.target.value) || 0)}
                          />
                        </td>
                        <td className="px-2 py-1.5">
                          <select
                            className="w-full px-1 py-1 text-xs border-0 focus:outline-none bg-transparent"
                            value={row.unit}
                            onChange={e => updateItem(i, 'unit', e.target.value)}
                          >
                            {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                          </select>
                        </td>
                        <td className="px-2 py-1.5">
                          <input
                            className="w-full px-2 py-1 text-sm text-right border-0 focus:outline-none bg-transparent"
                            type="number"
                            min="0"
                            value={row.unit_price}
                            onChange={e => updateItem(i, 'unit_price', parseFloat(e.target.value) || 0)}
                          />
                        </td>
                        <td className="px-3 py-1.5 text-right font-medium text-slate-700">
                          {fmt(row.total)}
                        </td>
                        <td className="px-2">
                          {items.length > 1 && (
                            <button
                              onClick={() => removeItem(i)}
                              className="text-slate-300 hover:text-red-500 transition"
                            >
                              <Trash2 size={14} />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Totals */}
            <div className="flex justify-end">
              <div className="w-72 space-y-1.5 text-sm bg-slate-50 rounded-xl p-4">
                <div className="flex justify-between text-slate-500">
                  <span>Sous-total</span><span className="font-medium">{fmt(totals.subtotal)}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>TPS ({form.tps_rate ?? TPS_RATE}%)</span>
                  <span>{fmt(totals.tps_amount)}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>TVQ ({form.tvq_rate ?? TVQ_RATE}%)</span>
                  <span>{fmt(totals.tvq_amount)}</span>
                </div>
                <div className="flex justify-between font-bold text-slate-900 text-base pt-2 border-t border-slate-200">
                  <span>Total TTC</span><span>{fmt(totals.total)}</span>
                </div>
              </div>
            </div>

            <FormField label="Description / Notes">
              <textarea
                className={textareaCls}
                rows={3}
                value={form.notes ?? ''}
                onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                placeholder="Conditions, précisions, exclusions..."
              />
            </FormField>
          </div>

          <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-slate-100">
            <button
              onClick={() => setShowForm(false)}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition"
            >
              Annuler
            </button>
            <button
              onClick={handleSave}
              disabled={saving || !form.titre?.trim()}
              className="px-5 py-2 text-sm font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50"
            >
              {saving ? 'Enregistrement...' : editing ? 'Mettre à jour' : 'Créer la soumission'}
            </button>
          </div>
        </Modal>
      )}

      {/* ── View Modal ──────────────────────────────────────────────────────────── */}
      {viewSom && (
        <Modal
          title={viewSom.soumission_no}
          onClose={() => setViewSom(null)}
          size="xl"
        >
          <div className="space-y-5 text-sm">
            {/* Company header */}
            {company.nom_entreprise && (
              <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="flex items-start gap-3">
                  {company.logo_url ? (
                    <img src={company.logo_url} alt="Logo" className="h-10 w-auto object-contain" />
                  ) : (
                    <div className="w-10 h-10 rounded-xl bg-orange-50 border border-orange-100 flex items-center justify-center flex-shrink-0">
                      <Building2 size={18} className="text-orange-500" />
                    </div>
                  )}
                  <div>
                    <div className="font-bold text-slate-900 text-sm">{company.nom_entreprise}</div>
                    {company.adresse && (
                      <div className="text-xs text-slate-500 mt-0.5">
                        {company.adresse}{company.ville ? `, ${company.ville}` : ''}{company.province ? ` (${company.province})` : ''}{company.code_postal ? ` ${company.code_postal}` : ''}
                      </div>
                    )}
                    {company.telephone && <div className="text-xs text-slate-500">{company.telephone}</div>}
                  </div>
                </div>
                <div className="text-right text-xs text-slate-400 space-y-0.5 flex-shrink-0">
                  {company.neq && <div>NEQ : {company.neq}</div>}
                  {company.rbq && <div>RBQ : {company.rbq}</div>}
                  {company.tps_no && <div>TPS : {company.tps_no}</div>}
                  {company.tvq_no && <div>TVQ : {company.tvq_no}</div>}
                </div>
              </div>
            )}

            {/* Header */}
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="font-bold text-slate-900 text-base mb-1">{viewSom.titre}</h3>
                {(() => {
                  const c = viewSom.clients as any;
                  return c ? (
                    <div className="text-slate-500">{c.company ?? c.name}</div>
                  ) : null;
                })()}
                <div className="text-slate-400 text-xs mt-1">
                  Émise le {viewSom.issue_date}
                  {viewSom.valid_until && ` · valide jusqu'au ${viewSom.valid_until}`}
                </div>
              </div>
              {STATUS_META[viewSom.status] && (
                <Badge label={STATUS_META[viewSom.status].label} color={STATUS_META[viewSom.status].color} />
              )}
            </div>

            {/* Items table */}
            {viewItems.length > 0 && (
              <div className="border border-slate-100 rounded-xl overflow-hidden">
                <table className="w-full">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="text-left px-4 py-2.5 text-xs font-semibold text-slate-500">Description</th>
                      <th className="text-right px-4 py-2.5 text-xs font-semibold text-slate-500">Qté</th>
                      <th className="text-left px-3 py-2.5 text-xs font-semibold text-slate-500">Unité</th>
                      <th className="text-right px-4 py-2.5 text-xs font-semibold text-slate-500">P.U.</th>
                      <th className="text-right px-4 py-2.5 text-xs font-semibold text-slate-500">Sous-total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {viewItems.map(item => (
                      <tr key={item.id}>
                        <td className="px-4 py-2.5 text-slate-700">{item.description}</td>
                        <td className="px-4 py-2.5 text-right text-slate-600">{item.quantity}</td>
                        <td className="px-3 py-2.5 text-slate-500 text-xs">{item.unit}</td>
                        <td className="px-4 py-2.5 text-right text-slate-600">{fmt(item.unit_price)}</td>
                        <td className="px-4 py-2.5 text-right font-medium text-slate-900">{fmt(item.total)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Totals */}
            <div className="flex justify-end">
              <div className="w-72 space-y-1.5 bg-slate-50 rounded-xl p-4">
                <div className="flex justify-between text-slate-500">
                  <span>Sous-total</span><span className="font-medium">{fmt(viewSom.subtotal)}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>TPS ({viewSom.tps_rate}%)</span><span>{fmt(viewSom.tps_amount)}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>TVQ ({viewSom.tvq_rate}%)</span><span>{fmt(viewSom.tvq_amount)}</span>
                </div>
                <div className="flex justify-between font-bold text-slate-900 text-base pt-2 border-t border-slate-200">
                  <span>Total TTC</span><span>{fmt(viewSom.total)}</span>
                </div>
              </div>
            </div>

            {viewSom.notes && (
              <div className="bg-amber-50 border border-amber-100 rounded-xl px-4 py-3 text-slate-600 text-xs whitespace-pre-wrap">
                {viewSom.notes}
              </div>
            )}

            {viewSom.converted_invoice_id && (
              <div className="flex items-center gap-2 text-emerald-700 bg-emerald-50 border border-emerald-100 rounded-xl px-4 py-3">
                <CheckCircle size={15} />
                <span className="text-sm font-medium">Convertie en facture</span>
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-2 mt-6 pt-4 border-t border-slate-100">
            <div className="flex gap-2 flex-wrap">
              {viewSom.status === 'brouillon' && (
                <>
                  <button
                    onClick={() => { setViewSom(null); openEdit(viewSom); }}
                    className="px-3 py-2 text-xs font-semibold border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg transition"
                  >
                    Modifier
                  </button>
                  <button
                    onClick={() => updateStatus(viewSom.id, 'envoyée')}
                    className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition"
                  >
                    <Send size={13} /> Marquer envoyée
                  </button>
                </>
              )}
              {viewSom.status === 'envoyée' && (
                <>
                  <button
                    onClick={() => updateStatus(viewSom.id, 'approuvée')}
                    className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition"
                  >
                    <CheckCircle size={13} /> Approuvée
                  </button>
                  <button
                    onClick={() => updateStatus(viewSom.id, 'refusée')}
                    className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-red-500 hover:bg-red-600 text-white rounded-lg transition"
                  >
                    <XCircle size={13} /> Refusée
                  </button>
                </>
              )}
              {viewSom.status === 'approuvée' && !viewSom.converted_invoice_id && (
                <button
                  onClick={() => convertToInvoice(viewSom)}
                  disabled={converting}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition disabled:opacity-50"
                >
                  <ArrowRight size={13} /> Convertir en facture
                </button>
              )}
            </div>
            <div className="ml-auto flex gap-2">
              <button
                onClick={() => openEdit(viewSom)}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
              >
                <Copy size={13} /> Dupliquer
              </button>
              <button
                onClick={() => handleDelete(viewSom.id)}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
              >
                <Trash2 size={13} /> Supprimer
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
