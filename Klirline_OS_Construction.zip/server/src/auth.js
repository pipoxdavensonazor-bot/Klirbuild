import express from 'express';
import crypto from 'crypto';
import {
  CognitoIdentityProviderClient,
  InitiateAuthCommand,
  SignUpCommand,
  ForgotPasswordCommand,
  AdminConfirmSignUpCommand,
  AdminUpdateUserAttributesCommand,
} from '@aws-sdk/client-cognito-identity-provider';
import { query } from './db.js';
import { verifyToken, cognitoConfig } from './cognito.js';

export const authRouter = express.Router();

const REGION = cognitoConfig.REGION;
const CLIENT_ID = cognitoConfig.CLIENT_ID;
const USER_POOL_ID = cognitoConfig.USER_POOL_ID;
const CLIENT_SECRET = process.env.COGNITO_CLIENT_SECRET || '';
const COGNITO_DOMAIN = process.env.COGNITO_DOMAIN || '';
const AUTO_CONFIRM = process.env.COGNITO_AUTO_CONFIRM === 'true';

const client = REGION ? new CognitoIdentityProviderClient({ region: REGION }) : null;

function secretHash(username) {
  if (!CLIENT_SECRET) return undefined;
  return crypto
    .createHmac('SHA256', CLIENT_SECRET)
    .update(username + CLIENT_ID)
    .digest('base64');
}

function notConfigured(res) {
  return res.status(503).json({ error: 'Cognito non configuré. Définissez les variables COGNITO_*.' });
}

// Build a Supabase-like session payload from Cognito tokens.
async function sessionFromTokens(tokens) {
  const idToken = tokens.IdToken;
  const claims = await verifyToken(idToken).catch(() => ({}));
  return {
    access_token: tokens.AccessToken,
    id_token: idToken,
    refresh_token: tokens.RefreshToken ?? null,
    token_type: 'bearer',
    expires_in: tokens.ExpiresIn ?? 3600,
    expires_at: Math.floor(Date.now() / 1000) + (tokens.ExpiresIn ?? 3600),
    user: {
      id: claims.sub,
      email: claims.email ?? null,
      user_metadata: {
        full_name: claims.name ?? null,
        role: claims['custom:role'] ?? null,
      },
    },
  };
}

// POST /auth/v1/token  — email + password sign-in
authRouter.post('/token', async (req, res) => {
  if (!client) return notConfigured(res);
  const { email, password } = req.body || {};
  try {
    const out = await client.send(
      new InitiateAuthCommand({
        AuthFlow: 'USER_PASSWORD_AUTH',
        ClientId: CLIENT_ID,
        AuthParameters: {
          USERNAME: email,
          PASSWORD: password,
          ...(secretHash(email) ? { SECRET_HASH: secretHash(email) } : {}),
        },
      }),
    );
    const session = await sessionFromTokens(out.AuthenticationResult);
    return res.json({ session, error: null });
  } catch (err) {
    return res.status(400).json({ session: null, error: { message: translate(err) } });
  }
});

// POST /auth/v1/refresh  — refresh an access token
authRouter.post('/refresh', async (req, res) => {
  if (!client) return notConfigured(res);
  const { refresh_token, username } = req.body || {};
  try {
    const out = await client.send(
      new InitiateAuthCommand({
        AuthFlow: 'REFRESH_TOKEN_AUTH',
        ClientId: CLIENT_ID,
        AuthParameters: {
          REFRESH_TOKEN: refresh_token,
          ...(secretHash(username ?? '') ? { SECRET_HASH: secretHash(username) } : {}),
        },
      }),
    );
    const result = out.AuthenticationResult;
    if (!result.RefreshToken) result.RefreshToken = refresh_token;
    const session = await sessionFromTokens(result);
    return res.json({ session, error: null });
  } catch (err) {
    return res.status(400).json({ session: null, error: { message: translate(err) } });
  }
});

// POST /auth/v1/signup  — register a new user + create their profile row
authRouter.post('/signup', async (req, res) => {
  if (!client) return notConfigured(res);
  const { email, password, data } = req.body || {};
  const fullName = data?.full_name ?? '';
  const role = data?.role ?? 'employee';
  try {
    const out = await client.send(
      new SignUpCommand({
        ClientId: CLIENT_ID,
        Username: email,
        Password: password,
        ...(secretHash(email) ? { SecretHash: secretHash(email) } : {}),
        UserAttributes: [
          { Name: 'email', Value: email },
          ...(fullName ? [{ Name: 'name', Value: fullName }] : []),
        ],
      }),
    );
    const sub = out.UserSub;

    // Optionally auto-confirm (requires admin IAM permissions on the pool).
    if (AUTO_CONFIRM && USER_POOL_ID) {
      try {
        await client.send(
          new AdminConfirmSignUpCommand({ UserPoolId: USER_POOL_ID, Username: email }),
        );
        await client.send(
          new AdminUpdateUserAttributesCommand({
            UserPoolId: USER_POOL_ID,
            Username: email,
            UserAttributes: [{ Name: 'email_verified', Value: 'true' }],
          }),
        );
      } catch (e) {
        console.warn('[auth] auto-confirm failed:', e.message);
      }
    }

    // Create the profile row (mirrors the old on-signup DB trigger).
    try {
      await query(
        `INSERT INTO profiles (id, email, full_name, role) VALUES ($1,$2,$3,$4)
         ON CONFLICT (id) DO NOTHING`,
        [sub, email, fullName || email.split('@')[0], role],
      );
    } catch (e) {
      console.warn('[auth] profile insert failed:', e.message);
    }

    // If auto-confirmed, sign in immediately so the client gets a session.
    if (AUTO_CONFIRM) {
      try {
        const login = await client.send(
          new InitiateAuthCommand({
            AuthFlow: 'USER_PASSWORD_AUTH',
            ClientId: CLIENT_ID,
            AuthParameters: {
              USERNAME: email,
              PASSWORD: password,
              ...(secretHash(email) ? { SECRET_HASH: secretHash(email) } : {}),
            },
          }),
        );
        const session = await sessionFromTokens(login.AuthenticationResult);
        return res.json({ session, needsConfirmation: false, error: null });
      } catch {
        /* fall through to confirmation-required response */
      }
    }

    return res.json({ session: null, needsConfirmation: true, error: null });
  } catch (err) {
    return res.status(400).json({ session: null, error: { message: translate(err) } });
  }
});

// POST /auth/v1/recover  — send a password reset code
authRouter.post('/recover', async (req, res) => {
  if (!client) return notConfigured(res);
  const { email } = req.body || {};
  try {
    await client.send(
      new ForgotPasswordCommand({
        ClientId: CLIENT_ID,
        Username: email,
        ...(secretHash(email) ? { SecretHash: secretHash(email) } : {}),
      }),
    );
    return res.json({ error: null });
  } catch (err) {
    return res.status(400).json({ error: { message: translate(err) } });
  }
});

// POST /auth/v1/oauth/token  — exchange a Hosted UI authorization code for tokens
authRouter.post('/oauth/token', async (req, res) => {
  if (!COGNITO_DOMAIN) return notConfigured(res);
  const { code, redirect_uri } = req.body || {};
  try {
    const body = new URLSearchParams({
      grant_type: 'authorization_code',
      client_id: CLIENT_ID,
      code,
      redirect_uri,
    });
    const headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
    if (CLIENT_SECRET) {
      headers.Authorization =
        'Basic ' + Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64');
    }
    const resp = await fetch(`${COGNITO_DOMAIN}/oauth2/token`, {
      method: 'POST',
      headers,
      body,
    });
    const tok = await resp.json();
    if (!resp.ok || !tok.id_token) {
      return res.status(400).json({ session: null, error: { message: tok.error || 'OAuth exchange failed' } });
    }
    const session = await sessionFromTokens({
      AccessToken: tok.access_token,
      IdToken: tok.id_token,
      RefreshToken: tok.refresh_token,
      ExpiresIn: tok.expires_in,
    });

    // Ensure a profile row exists for federated (Google/Microsoft) users.
    if (session.user?.id) {
      await query(
        `INSERT INTO profiles (id, email, full_name, role) VALUES ($1,$2,$3,'employee')
         ON CONFLICT (id) DO NOTHING`,
        [session.user.id, session.user.email, session.user.user_metadata.full_name ?? ''],
      ).catch(() => {});
    }
    return res.json({ session, error: null });
  } catch (err) {
    return res.status(400).json({ session: null, error: { message: err.message } });
  }
});

function translate(err) {
  const name = err.name || '';
  const map = {
    NotAuthorizedException: 'Courriel ou mot de passe incorrect.',
    UserNotConfirmedException: 'Compte non confirmé. Vérifiez votre courriel.',
    UsernameExistsException: 'Un compte existe déjà avec ce courriel.',
    InvalidPasswordException: 'Mot de passe trop faible.',
    UserNotFoundException: 'Aucun compte trouvé pour ce courriel.',
    CodeMismatchException: 'Code de vérification invalide.',
  };
  return map[name] || err.message || 'Erreur d’authentification.';
}
