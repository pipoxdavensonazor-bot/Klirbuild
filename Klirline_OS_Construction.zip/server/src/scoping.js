// ============================================================================
// Authorization config — replaces Supabase Row Level Security.
// The REST layer consults these sets to scope every query to the authenticated
// Cognito user (req.user.id === the Cognito `sub`, which equals profiles.id).
// ============================================================================

// Tables/views that were owner-scoped (RLS: auth.uid() = owner_id).
export const OWNER_SCOPED = new Set([
  'subscriptions',
  'soumissions',
  'company_settings',
  'payroll_employees',
  'payroll_periods',
  'payroll_entries',
  'fiscal_rates',
  'ccq_certificates',
  'ccq_conventions',
  'ccq_wage_rates',
  'ccq_social_contributions',
  'ccq_declarations',
  'cnesst_incidents',
  'stripe_user_subscriptions',
]);

// Tables that were user-scoped (RLS: auth.uid() = user_id).
export const USER_SCOPED = new Set([
  'emails',
  'gmail_tokens',
  'm365_tokens',
  'audit_log',
]);

// Single-tenant business tables — any authenticated user may read/write
// (original RLS was `USING (true)` for anon+authenticated).
export const OPEN_TABLES = new Set([
  'employees',
  'clients',
  'leads',
  'projects',
  'project_employees',
  'tasks',
  'time_entries',
  'invoices',
  'invoice_items',
  'payments',
  'expenses',
  'documents',
  'chat_channels',
  'chat_messages',
  'soumission_items',
  'invite_codes',
]);

// `profiles` is handled specially (readable by all authenticated; writable own
// row, or any row for admins).
export const PROFILES = 'profiles';

// Every table/view the REST layer is allowed to touch.
export const ALLOWED = new Set([
  ...OWNER_SCOPED,
  ...USER_SCOPED,
  ...OPEN_TABLES,
  PROFILES,
]);

export function scopeColumn(table) {
  if (OWNER_SCOPED.has(table)) return 'owner_id';
  if (USER_SCOPED.has(table)) return 'user_id';
  return null;
}

// ---------------------------------------------------------------------------
// Embedded-resource (foreign table) relationships used by `select('*, x(...)')`.
// All are belongs-to (to-one) relationships. Key = `<table>.<embedName>`.
// ---------------------------------------------------------------------------
export const RELATIONSHIPS = {
  'time_entries.employees': { fk: 'employee_id', refTable: 'employees' },
  'time_entries.projects': { fk: 'project_id', refTable: 'projects' },
  'leads.employees': { fk: 'assigned_to', refTable: 'employees' },
  'invoices.clients': { fk: 'client_id', refTable: 'clients' },
  'invoices.projects': { fk: 'project_id', refTable: 'projects' },
  'documents.projects': { fk: 'project_id', refTable: 'projects' },
  'documents.clients': { fk: 'client_id', refTable: 'clients' },
  'chat_channels.projects': { fk: 'project_id', refTable: 'projects' },
  'tasks.employees': { fk: 'assigned_to', refTable: 'employees' },
};
