import express from 'express';
import { query } from '../db.js';
import { verifyToken } from '../cognito.js';

function getGoogleCredentials() {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  if (clientId && clientSecret) return { clientId, clientSecret };

  const googleSecret = process.env.Google;
  if (googleSecret) {
    try {
      const parsed = JSON.parse(googleSecret);
      const id = parsed.client_id ?? parsed.clientId ?? parsed.web?.client_id;
      const secret = parsed.client_secret ?? parsed.clientSecret ?? parsed.web?.client_secret;
      if (id && secret) return { clientId: id, clientSecret: secret };
    } catch {
      /* ignore */
    }
  }
  throw new Error('Google credentials not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.');
}

async function refreshAccessToken(refreshToken) {
  const { clientId, clientSecret } = getGoogleCredentials();
  const resp = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    }),
  });
  const data = await resp.json();
  return data.access_token ? data : null;
}

function getHeader(headers, name) {
  return headers.find((h) => h.name.toLowerCase() === name.toLowerCase())?.value ?? '';
}

function decodeBase64url(data) {
  try {
    return Buffer.from(data.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
  } catch {
    return '';
  }
}

function extractBody(payload) {
  const body = payload.body;
  if (body?.data) return decodeBase64url(body.data);
  const parts = payload.parts;
  if (parts) {
    const textPart = parts.find((p) => p.mimeType === 'text/plain');
    if (textPart) return extractBody(textPart);
    const htmlPart = parts.find((p) => p.mimeType === 'text/html');
    if (htmlPart) return extractBody(htmlPart);
    for (const part of parts) {
      const nested = extractBody(part);
      if (nested) return nested;
    }
  }
  return '';
}

async function getUser(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  try {
    const claims = await verifyToken(authHeader.replace('Bearer ', ''));
    return { id: claims.sub, email: claims.email || claims['cognito:username'] };
  } catch {
    return null;
  }
}

const router = express.Router();

// GET /functions/v1/gmail-oauth?action=auth-url  OR  OAuth callback (code & state)
router.get('/gmail-oauth', async (req, res) => {
  const apiBase = process.env.API_URL || `${req.protocol}://${req.get('host')}`;
  const redirectUri = `${apiBase}/functions/v1/gmail-oauth`;

  // MODE 1: generate auth URL
  if (req.query.action === 'auth-url') {
    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Invalid session' });

    const appOrigin = req.headers.origin ?? req.query.origin ?? '';
    let clientId;
    try {
      ({ clientId } = getGoogleCredentials());
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }

    const state = Buffer.from(JSON.stringify({ user_id: user.id, app_origin: appOrigin })).toString('base64');
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: [
        'https://www.googleapis.com/auth/gmail.readonly',
        'https://www.googleapis.com/auth/gmail.send',
        'https://www.googleapis.com/auth/gmail.compose',
        'https://www.googleapis.com/auth/userinfo.email',
      ].join(' '),
      access_type: 'offline',
      prompt: 'consent',
      state,
    });
    return res.json({ url: `https://accounts.google.com/o/oauth2/v2/auth?${params}` });
  }

  // MODE 2: OAuth callback
  const { code, state: stateParam, error: errorParam } = req.query;
  let appOrigin = process.env.APP_URL || '';

  if (errorParam) return res.redirect(`${appOrigin}?gmail_error=${encodeURIComponent(String(errorParam))}`);
  if (!code || !stateParam) return res.redirect(`${appOrigin}?gmail_error=missing_params`);

  let userId;
  try {
    const decoded = JSON.parse(Buffer.from(String(stateParam), 'base64').toString('utf8'));
    userId = decoded.user_id;
    if (decoded.app_origin) appOrigin = decoded.app_origin;
  } catch {
    return res.redirect(`${appOrigin}?gmail_error=invalid_state`);
  }

  let clientId;
  let clientSecret;
  try {
    ({ clientId, clientSecret } = getGoogleCredentials());
  } catch {
    return res.redirect(`${appOrigin}?gmail_error=credentials_not_configured`);
  }

  const tokenResp = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code: String(code),
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
    }),
  });
  const tokens = await tokenResp.json();
  if (!tokens.access_token) return res.redirect(`${appOrigin}?gmail_error=token_exchange_failed`);

  const userInfoResp = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
    headers: { Authorization: `Bearer ${tokens.access_token}` },
  });
  const userInfo = await userInfoResp.json();
  if (!userInfo.email) return res.redirect(`${appOrigin}?gmail_error=no_email`);

  const expiresAt = new Date(Date.now() + (tokens.expires_in ?? 3600) * 1000).toISOString();
  try {
    await query(
      `INSERT INTO gmail_tokens (user_id, gmail_email, access_token, refresh_token, expires_at, scope, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, now())
       ON CONFLICT (user_id, gmail_email) DO UPDATE SET
         access_token = EXCLUDED.access_token,
         refresh_token = COALESCE(EXCLUDED.refresh_token, gmail_tokens.refresh_token),
         expires_at = EXCLUDED.expires_at,
         scope = EXCLUDED.scope,
         updated_at = now()`,
      [userId, userInfo.email, tokens.access_token, tokens.refresh_token ?? null, expiresAt, tokens.scope ?? ''],
    );
  } catch {
    return res.redirect(`${appOrigin}?gmail_error=db_error`);
  }

  return res.redirect(`${appOrigin}?gmail_connected=true&gmail_email=${encodeURIComponent(userInfo.email)}`);
});

// POST /functions/v1/gmail-proxy
router.post('/gmail-proxy', async (req, res) => {
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const body = req.body || {};
  const { action } = body;

  if (action === 'get_status') {
    const { rows } = await query(
      'SELECT gmail_email, updated_at FROM gmail_tokens WHERE user_id = $1',
      [user.id],
    );
    return res.json({ connected: rows.length > 0, accounts: rows });
  }

  if (action === 'disconnect') {
    await query('DELETE FROM gmail_tokens WHERE user_id = $1', [user.id]);
    return res.json({ success: true });
  }

  const { rows: tokenRows } = await query(
    'SELECT * FROM gmail_tokens WHERE user_id = $1 LIMIT 1',
    [user.id],
  );
  const tokenRow = tokenRows[0];
  if (!tokenRow) return res.status(400).json({ error: 'Gmail not connected' });

  let accessToken = tokenRow.access_token;
  if (tokenRow.expires_at && new Date(tokenRow.expires_at).getTime() < Date.now() + 60_000) {
    if (tokenRow.refresh_token) {
      const refreshed = await refreshAccessToken(tokenRow.refresh_token);
      if (refreshed) {
        accessToken = refreshed.access_token;
        await query(
          'UPDATE gmail_tokens SET access_token = $1, expires_at = $2, updated_at = now() WHERE id = $3',
          [refreshed.access_token, new Date(Date.now() + refreshed.expires_in * 1000).toISOString(), tokenRow.id],
        );
      }
    }
  }

  const gmailBase = 'https://gmail.googleapis.com/gmail/v1/users/me';
  const authBearer = `Bearer ${accessToken}`;

  if (action === 'list_messages') {
    const folder = body.folder ?? 'inbox';
    const label = folder === 'inbox' ? 'INBOX' : folder === 'sent' ? 'SENT' : 'DRAFT';
    const listResp = await fetch(`${gmailBase}/messages?labelIds=${label}&maxResults=25`, {
      headers: { Authorization: authBearer },
    });
    const listData = await listResp.json();
    if (!listData.messages?.length) return res.json({ messages: [] });

    const messages = await Promise.all(
      listData.messages.map(async (m) => {
        const r = await fetch(
          `${gmailBase}/messages/${m.id}?format=metadata&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Subject&metadataHeaders=Date`,
          { headers: { Authorization: authBearer } },
        );
        const msg = await r.json();
        const hdrs = msg.payload?.headers ?? [];
        return {
          id: msg.id,
          threadId: msg.threadId,
          snippet: msg.snippet ?? '',
          isUnread: (msg.labelIds ?? []).includes('UNREAD'),
          from: getHeader(hdrs, 'From'),
          to: getHeader(hdrs, 'To'),
          subject: getHeader(hdrs, 'Subject'),
          date: getHeader(hdrs, 'Date'),
          labelIds: msg.labelIds ?? [],
        };
      }),
    );
    return res.json({ messages });
  }

  if (action === 'get_message') {
    const resp = await fetch(`${gmailBase}/messages/${body.messageId}?format=full`, {
      headers: { Authorization: authBearer },
    });
    const msg = await resp.json();
    const hdrs = msg.payload?.headers ?? [];
    return res.json({
      id: msg.id,
      threadId: msg.threadId,
      from: getHeader(hdrs, 'From'),
      to: getHeader(hdrs, 'To'),
      subject: getHeader(hdrs, 'Subject'),
      date: getHeader(hdrs, 'Date'),
      body: extractBody(msg.payload ?? {}),
      snippet: msg.snippet ?? '',
      labelIds: msg.labelIds ?? [],
    });
  }

  if (action === 'send_email') {
    const { to, subject, body: emailBody, replyToMessageId } = body;
    const from = tokenRow.gmail_email;
    const rawMessage = [
      `From: ${from}`,
      `To: ${to}`,
      `Subject: ${subject}`,
      'Content-Type: text/plain; charset=UTF-8',
      'MIME-Version: 1.0',
      '',
      emailBody,
    ].join('\r\n');
    const encoded = Buffer.from(rawMessage).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    const sendResp = await fetch(`${gmailBase}/messages/send`, {
      method: 'POST',
      headers: { Authorization: authBearer, 'Content-Type': 'application/json' },
      body: JSON.stringify({ raw: encoded, ...(replyToMessageId ? { threadId: replyToMessageId } : {}) }),
    });
    const result = await sendResp.json();
    if (result.error) return res.status(400).json({ error: result.error.message ?? 'Send failed' });
    return res.json({ success: true, id: result.id });
  }

  return res.status(400).json({ error: 'Unknown action' });
});

export const gmailRouter = router;
