import express from 'express';
import { query } from '../db.js';
import { verifyToken } from '../cognito.js';

const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || '';
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || '';

const ANNUAL_STARTER = process.env.STRIPE_PRICE_STARTER_ANNUAL || '';
const ANNUAL_PRO = process.env.STRIPE_PRICE_PRO_ANNUAL || '';
const ANNUAL_ENTERPRISE = process.env.STRIPE_PRICE_ENTERPRISE_ANNUAL || '';

const PLANS_MONTHLY = {
  starter: { priceId: process.env.STRIPE_PRICE_STARTER || ANNUAL_STARTER, name: 'Klirline Starter' },
  pro: { priceId: process.env.STRIPE_PRICE_PRO || ANNUAL_PRO, name: 'Klirline Pro' },
  enterprise: { priceId: process.env.STRIPE_PRICE_ENTERPRISE || ANNUAL_ENTERPRISE, name: 'Klirline Enterprise' },
};

const PLANS_ANNUAL = {
  starter: { priceId: ANNUAL_STARTER || (process.env.STRIPE_PRICE_STARTER || ''), name: 'Klirline Starter (annuel)' },
  pro: { priceId: ANNUAL_PRO || (process.env.STRIPE_PRICE_PRO || ''), name: 'Klirline Pro (annuel)' },
  enterprise: { priceId: ANNUAL_ENTERPRISE || (process.env.STRIPE_PRICE_ENTERPRISE || ''), name: 'Klirline Enterprise (annuel)' },
};

// Resolve the authenticated user from the Authorization header via Cognito.
async function getUser(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return { error: 'Non autorisé', status: 401 };
  const token = authHeader.replace('Bearer ', '');
  try {
    const claims = await verifyToken(token);
    return { user: { id: claims.sub, email: claims.email || claims['cognito:username'] } };
  } catch {
    return { error: 'Session invalide', status: 401 };
  }
}

const router = express.Router();

// POST /functions/v1/stripe-checkout
router.post('/stripe-checkout', async (req, res) => {
  try {
    if (!STRIPE_SECRET_KEY) {
      return res.status(503).json({ error: 'Stripe non configuré. Ajoutez STRIPE_SECRET_KEY dans les secrets.' });
    }
    const { user, error, status } = await getUser(req);
    if (error) return res.status(status).json({ error });

    const { plan, annual, successUrl, cancelUrl } = req.body || {};
    const planMap = annual ? PLANS_ANNUAL : PLANS_MONTHLY;
    const planConfig = planMap[plan];
    if (!planConfig || !planConfig.priceId) {
      return res.status(400).json({ error: `Plan invalide ou prix non configuré: ${plan}${annual ? ' (annuel)' : ''}` });
    }

    const { rows } = await query(
      'SELECT stripe_customer_id FROM subscriptions WHERE owner_id = $1 LIMIT 1',
      [user.id],
    );
    const subscription = rows[0];
    let customerId = subscription?.stripe_customer_id;

    if (!customerId) {
      const customerRes = await fetch('https://api.stripe.com/v1/customers', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${STRIPE_SECRET_KEY}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          email: user.email ?? '',
          'metadata[user_id]': user.id,
        }),
      });
      const customer = await customerRes.json();
      if (!customerRes.ok) throw new Error(customer.error?.message ?? 'Erreur création client Stripe');
      customerId = customer.id;
    }

    const origin = req.headers.origin ?? '';
    const params = new URLSearchParams({
      customer: customerId,
      mode: 'subscription',
      'line_items[0][price]': planConfig.priceId,
      'line_items[0][quantity]': '1',
      success_url: successUrl ?? `${origin}/`,
      cancel_url: cancelUrl ?? `${origin}/`,
      'subscription_data[metadata][user_id]': user.id,
      'subscription_data[metadata][plan]': plan,
      'subscription_data[metadata][billing]': annual ? 'annual' : 'monthly',
      allow_promotion_codes: 'true',
      'payment_method_types[0]': 'card',
    });

    if (!subscription?.stripe_customer_id) {
      params.set('subscription_data[trial_period_days]', '14');
    }

    const sessionRes = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${STRIPE_SECRET_KEY}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params,
    });
    const stripeSession = await sessionRes.json();
    if (!sessionRes.ok) throw new Error(stripeSession.error?.message ?? 'Erreur création session Stripe');

    await query(
      `INSERT INTO subscriptions (owner_id, stripe_customer_id, plan, status)
       VALUES ($1, $2, $3, 'trialing')
       ON CONFLICT (owner_id) DO UPDATE
         SET stripe_customer_id = EXCLUDED.stripe_customer_id,
             plan = EXCLUDED.plan,
             status = 'trialing',
             updated_at = now()`,
      [user.id, customerId, plan],
    );

    return res.json({ url: stripeSession.url, sessionId: stripeSession.id });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// POST /functions/v1/stripe-portal
router.post('/stripe-portal', async (req, res) => {
  try {
    if (!STRIPE_SECRET_KEY) return res.status(503).json({ error: 'Stripe non configuré.' });
    const { user, error, status } = await getUser(req);
    if (error) return res.status(status).json({ error });

    const { returnUrl } = req.body || {};
    const { rows } = await query(
      'SELECT stripe_customer_id FROM subscriptions WHERE owner_id = $1 LIMIT 1',
      [user.id],
    );
    const sub = rows[0];
    if (!sub?.stripe_customer_id) {
      return res.status(404).json({ error: 'Aucun abonnement Stripe actif trouvé.' });
    }

    const origin = req.headers.origin ?? '';
    const portalRes = await fetch('https://api.stripe.com/v1/billing_portal/sessions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${STRIPE_SECRET_KEY}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        customer: sub.stripe_customer_id,
        return_url: returnUrl ?? `${origin}/`,
      }),
    });
    const portal = await portalRes.json();
    if (!portalRes.ok) throw new Error(portal.error?.message ?? 'Erreur portail Stripe');

    return res.json({ url: portal.url });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// Verify Stripe webhook signature using HMAC-SHA256 (Node crypto).
async function verifyStripeSignature(payload, sigHeader, secret) {
  if (!secret) return true; // dev only
  const { createHmac } = await import('node:crypto');
  const parts = sigHeader.split(',');
  const timestamp = parts.find((p) => p.startsWith('t='))?.substring(2);
  const signatures = parts.filter((p) => p.startsWith('v1=')).map((p) => p.substring(3));
  if (!timestamp || signatures.length === 0) return false;
  if (Math.abs(Date.now() / 1000 - parseInt(timestamp, 10)) > 300) return false;
  const computedSig = createHmac('sha256', secret).update(`${timestamp}.${payload}`).digest('hex');
  return signatures.some((sig) => sig === computedSig);
}

// The webhook is mounted separately with a raw body parser.
const webhook = express.Router();
webhook.post('/', express.raw({ type: '*/*' }), async (req, res) => {
  try {
    const body = req.body instanceof Buffer ? req.body.toString('utf8') : req.body;
    const signature = req.headers['stripe-signature'] ?? '';

    if (STRIPE_WEBHOOK_SECRET) {
      if (!signature) return res.status(400).json({ error: 'Missing stripe-signature header' });
      const valid = await verifyStripeSignature(body, signature, STRIPE_WEBHOOK_SECRET);
      if (!valid) return res.status(400).json({ error: 'Invalid webhook signature' });
    }

    const event = JSON.parse(body);

    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const sub = event.data.object;
        const userId = sub.metadata?.user_id;
        if (!userId) break;
        await query(
          `INSERT INTO subscriptions
             (owner_id, stripe_customer_id, stripe_subscription_id, plan, status, current_period_end, cancel_at_period_end)
           VALUES ($1, $2, $3, $4, $5, $6, $7)
           ON CONFLICT (owner_id) DO UPDATE SET
             stripe_customer_id = EXCLUDED.stripe_customer_id,
             stripe_subscription_id = EXCLUDED.stripe_subscription_id,
             plan = EXCLUDED.plan,
             status = EXCLUDED.status,
             current_period_end = EXCLUDED.current_period_end,
             cancel_at_period_end = EXCLUDED.cancel_at_period_end,
             updated_at = now()`,
          [
            userId,
            sub.customer,
            sub.id,
            sub.metadata?.plan ?? 'starter',
            sub.status,
            new Date(sub.current_period_end * 1000).toISOString(),
            sub.cancel_at_period_end,
          ],
        );
        await query('UPDATE profiles SET subscription_status = $1 WHERE id = $2', [sub.status, userId]);
        break;
      }
      case 'customer.subscription.deleted': {
        const sub = event.data.object;
        const userId = sub.metadata?.user_id;
        if (!userId) break;
        await query("UPDATE subscriptions SET status = 'canceled' WHERE stripe_subscription_id = $1", [sub.id]);
        await query("UPDATE profiles SET subscription_status = 'canceled' WHERE id = $1", [userId]);
        break;
      }
      case 'invoice.payment_succeeded': {
        const invoice = event.data.object;
        if (invoice.subscription) {
          await query("UPDATE subscriptions SET status = 'active' WHERE stripe_subscription_id = $1", [invoice.subscription]);
        }
        break;
      }
      case 'invoice.payment_failed': {
        const invoice = event.data.object;
        if (invoice.subscription) {
          await query("UPDATE subscriptions SET status = 'past_due' WHERE stripe_subscription_id = $1", [invoice.subscription]);
        }
        break;
      }
    }

    return res.json({ received: true });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

export const stripeRouter = { router, webhook };
