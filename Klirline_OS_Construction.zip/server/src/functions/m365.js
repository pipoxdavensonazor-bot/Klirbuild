import express from 'express';
import { query } from '../db.js';
import { verifyToken } from '../cognito.js';

const SCOPES = 'openid email profile offline_access Mail.Read Mail.Send User.Read';
const GRAPH = 'https://graph.microsoft.com/v1.0';

function getMsCredentials() {
  const clientId = process.env.MICROSOFT_CLIENT_ID;
  const clientSecret = process.env.MICROSOFT_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    throw new Error('Microsoft credentials not configured. Set MICROSOFT_CLIENT_ID and MICROSOFT_CLIENT_SECRET.');
  }
  return { clientId, clientSecret };
}

async function refreshAccessToken(refreshToken) {
  const { clientId, clientSecret } = getMsCredentials();
  const resp = await fetch('https://login.microsoftonline.com/common/oauth2/v2.0/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
      scope: SCOPES,
    }),
  });
  const data = await resp.json();
  return data.access_token ? data : null;
}

async function getUser(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  try {
    const claims = await verifyToken(authHeader.replace('Bearer ', ''));
    return { id: claims.sub, email: claims.email || claims['cognito:username'] };
  } catch {
    return null;
  }
}

const router = express.Router();

// GET /functions/v1/m365-oauth?action=auth-url  OR  OAuth callback
router.get('/m365-oauth', async (req, res) => {
  const apiBase = process.env.API_URL || `${req.protocol}://${req.get('host')}`;
  const redirectUri = `${apiBase}/functions/v1/m365-oauth`;

  if (req.query.action === 'auth-url') {
    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Invalid session' });

    let clientId;
    try {
      ({ clientId } = getMsCredentials());
    } catch (e) {
      return res.status(503).json({ error: e.message });
    }

    const appOrigin = req.headers.origin ?? req.query.origin ?? '';
    const state = Buffer.from(JSON.stringify({ user_id: user.id, app_origin: appOrigin })).toString('base64');
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: SCOPES,
      state,
      response_mode: 'query',
    });
    return res.json({ url: `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?${params}` });
  }

  const { code, state: stateParam, error: errorParam } = req.query;
  let appOrigin = process.env.APP_URL || '';

  if (errorParam) {
    const desc = req.query.error_description ?? errorParam;
    return res.redirect(`${appOrigin}?m365_error=${encodeURIComponent(String(desc))}`);
  }
  if (!code || !stateParam) return res.redirect(`${appOrigin}?m365_error=missing_params`);

  let userId;
  try {
    const decoded = JSON.parse(Buffer.from(String(stateParam), 'base64').toString('utf8'));
    userId = decoded.user_id;
    if (decoded.app_origin) appOrigin = decoded.app_origin;
  } catch {
    return res.redirect(`${appOrigin}?m365_error=invalid_state`);
  }

  let clientId;
  let clientSecret;
  try {
    ({ clientId, clientSecret } = getMsCredentials());
  } catch {
    return res.redirect(`${appOrigin}?m365_error=credentials_not_configured`);
  }

  const tokenResp = await fetch('https://login.microsoftonline.com/common/oauth2/v2.0/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code: String(code),
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
      scope: SCOPES,
    }),
  });
  const tokens = await tokenResp.json();
  if (!tokens.access_token) {
    const msg = tokens.error_description ?? tokens.error ?? 'token_exchange_failed';
    return res.redirect(`${appOrigin}?m365_error=${encodeURIComponent(msg)}`);
  }

  const meResp = await fetch('https://graph.microsoft.com/v1.0/me', {
    headers: { Authorization: `Bearer ${tokens.access_token}` },
  });
  const me = await meResp.json();
  const msEmail = me.mail ?? me.userPrincipalName;
  if (!msEmail) return res.redirect(`${appOrigin}?m365_error=no_email`);

  const expiresAt = new Date(Date.now() + (tokens.expires_in ?? 3600) * 1000).toISOString();
  try {
    await query(
      `INSERT INTO m365_tokens (user_id, ms_email, access_token, refresh_token, expires_at, scope, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, now())
       ON CONFLICT (user_id, ms_email) DO UPDATE SET
         access_token = EXCLUDED.access_token,
         refresh_token = COALESCE(EXCLUDED.refresh_token, m365_tokens.refresh_token),
         expires_at = EXCLUDED.expires_at,
         scope = EXCLUDED.scope,
         updated_at = now()`,
      [userId, msEmail, tokens.access_token, tokens.refresh_token ?? null, expiresAt, tokens.scope ?? ''],
    );
  } catch {
    return res.redirect(`${appOrigin}?m365_error=db_error`);
  }

  return res.redirect(`${appOrigin}?m365_connected=true&ms_email=${encodeURIComponent(msEmail)}`);
});

// POST /functions/v1/m365-proxy
router.post('/m365-proxy', async (req, res) => {
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const body = req.body || {};
  const { action } = body;

  if (action === 'get_status') {
    const { rows } = await query('SELECT ms_email, updated_at FROM m365_tokens WHERE user_id = $1', [user.id]);
    return res.json({ connected: rows.length > 0, accounts: rows });
  }

  if (action === 'disconnect') {
    await query('DELETE FROM m365_tokens WHERE user_id = $1', [user.id]);
    return res.json({ success: true });
  }

  const { rows: tokenRows } = await query('SELECT * FROM m365_tokens WHERE user_id = $1 LIMIT 1', [user.id]);
  const tokenRow = tokenRows[0];
  if (!tokenRow) return res.status(400).json({ error: 'Microsoft 365 not connected' });

  let accessToken = tokenRow.access_token;
  if (tokenRow.expires_at && new Date(tokenRow.expires_at).getTime() < Date.now() + 60_000) {
    if (tokenRow.refresh_token) {
      try {
        const refreshed = await refreshAccessToken(tokenRow.refresh_token);
        if (refreshed) {
          accessToken = refreshed.access_token;
          await query(
            'UPDATE m365_tokens SET access_token = $1, expires_at = $2, updated_at = now() WHERE id = $3',
            [refreshed.access_token, new Date(Date.now() + refreshed.expires_in * 1000).toISOString(), tokenRow.id],
          );
        }
      } catch {
        /* continue with current token */
      }
    }
  }

  const authBearer = `Bearer ${accessToken}`;

  if (action === 'list_messages') {
    const folder = body.folder ?? 'inbox';
    const folderPath = folder === 'inbox' ? 'inbox' : folder === 'sent' ? 'sentitems' : 'drafts';
    const select = ['id', 'subject', 'bodyPreview', 'receivedDateTime', 'isRead', 'from', 'toRecipients'].join(',');
    const resp = await fetch(
      `${GRAPH}/me/mailFolders/${folderPath}/messages?$top=25&$select=${select}&$orderby=receivedDateTime desc`,
      { headers: { Authorization: authBearer } },
    );
    const data = await resp.json();
    if (data.error) return res.status(400).json({ error: data.error.message ?? 'Graph API error' });

    const messages = (data.value ?? []).map((m) => {
      const from = m.from;
      const to = m.toRecipients;
      return {
        id: m.id,
        subject: m.subject ?? '(sans objet)',
        snippet: m.bodyPreview ?? '',
        isUnread: m.isRead === false,
        from: from ? `${from.emailAddress.name} <${from.emailAddress.address}>` : '',
        to: to?.map((r) => r.emailAddress.address).join(', ') ?? '',
        date: m.receivedDateTime ?? '',
      };
    });
    return res.json({ messages });
  }

  if (action === 'get_message') {
    const resp = await fetch(
      `${GRAPH}/me/messages/${body.messageId}?$select=id,subject,body,from,toRecipients,receivedDateTime,isRead`,
      { headers: { Authorization: authBearer } },
    );
    const m = await resp.json();
    if (m.error) return res.status(400).json({ error: m.error.message ?? 'Graph API error' });

    const from = m.from;
    const to = m.toRecipients;
    const bodyHtml = m.body?.content ?? '';
    const bodyText = bodyHtml.replace(/<[^>]+>/g, ' ').replace(/\s{2,}/g, ' ').trim();
    return res.json({
      id: m.id,
      subject: m.subject ?? '(sans objet)',
      from: from ? `${from.emailAddress.name} <${from.emailAddress.address}>` : '',
      to: to?.map((r) => r.emailAddress.address).join(', ') ?? '',
      date: m.receivedDateTime ?? '',
      body: bodyText || bodyHtml,
      isUnread: m.isRead === false,
    });
  }

  if (action === 'send_email') {
    const { to, subject, body: emailBody } = body;
    const payload = {
      message: {
        subject,
        body: { contentType: 'Text', content: emailBody ?? '' },
        toRecipients: to.split(',').map((addr) => ({ emailAddress: { address: addr.trim() } })),
      },
      saveToSentItems: true,
    };
    const resp = await fetch(`${GRAPH}/me/sendMail`, {
      method: 'POST',
      headers: { Authorization: authBearer, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (resp.status === 202 || resp.status === 200) return res.json({ success: true });
    const errData = await resp.json().catch(() => ({}));
    return res.status(400).json({ error: errData.error?.message ?? 'Send failed' });
  }

  return res.status(400).json({ error: 'Unknown action' });
});

export const m365Router = router;
