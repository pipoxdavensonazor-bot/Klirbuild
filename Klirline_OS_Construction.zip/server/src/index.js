import 'dotenv/config';
import express from 'express';
import cors from 'cors';

import { restRouter } from './rest.js';
import { rpcRouter } from './rpc.js';
import { authRouter } from './auth.js';
import { stripeRouter } from './functions/stripe.js';
import { gmailRouter } from './functions/gmail.js';
import { m365Router } from './functions/m365.js';

const app = express();

// CORS: allow the SPA / Electron / Capacitor origins.
const allowedOrigins = (process.env.CORS_ORIGINS || '*')
  .split(',')
  .map((o) => o.trim());
app.use(
  cors({
    origin: allowedOrigins.includes('*') ? true : allowedOrigins,
    credentials: true,
  }),
);

// The Stripe webhook needs the raw body for signature verification, so it is
// mounted BEFORE the JSON body parser (it uses express.raw internally).
app.use('/functions/v1/stripe-webhook', stripeRouter.webhook);

app.use(express.json({ limit: '10mb' }));

app.get('/health', (_req, res) => res.json({ status: 'ok' }));

// Auth broker (Cognito) — mirrors the subset of supabase.auth used by the app.
app.use('/auth/v1', authRouter);

// PostgREST-compatible data API: /rest/v1/:table
app.use('/rest/v1', restRouter);

// Postgres function calls: /rest/v1/rpc/:fn
app.use('/rest/v1/rpc', rpcRouter);

// Ported edge functions: /functions/v1/*
app.use('/functions/v1', stripeRouter.router);
app.use('/functions/v1', gmailRouter);
app.use('/functions/v1', m365Router);

app.use((err, _req, res, _next) => {
  console.error('[server] Unhandled error:', err);
  res.status(500).json({ error: err?.message || 'Internal server error' });
});

const port = process.env.PORT || 8787;
app.listen(port, () => {
  console.log(`[server] Klirline API listening on port ${port}`);
});
