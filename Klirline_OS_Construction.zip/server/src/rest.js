import express from 'express';
import { query } from './db.js';
import { requireAuth } from './cognito.js';
import {
  ALLOWED,
  OWNER_SCOPED,
  USER_SCOPED,
  PROFILES,
  scopeColumn,
  RELATIONSHIPS,
} from './scoping.js';

export const restRouter = express.Router();

const IDENT = /^[a-zA-Z_][a-zA-Z0-9_]*$/;
function ident(name) {
  if (!IDENT.test(name)) throw new Error(`Invalid identifier: ${name}`);
  return `"${name}"`;
}

const OPS = {
  eq: '=',
  neq: '<>',
  gt: '>',
  gte: '>=',
  lt: '<',
  lte: '<=',
  like: 'LIKE',
  ilike: 'ILIKE',
};

// --- select string parser (handles embeds like `clients(first_name,last_name)`) ---
function parseSelect(select) {
  const cols = [];
  const embeds = [];
  if (!select || select.trim() === '') {
    cols.push('*');
    return { cols, embeds };
  }
  let depth = 0;
  let token = '';
  const tokens = [];
  for (const ch of select) {
    if (ch === '(') depth++;
    if (ch === ')') depth--;
    if (ch === ',' && depth === 0) {
      tokens.push(token.trim());
      token = '';
    } else {
      token += ch;
    }
  }
  if (token.trim()) tokens.push(token.trim());

  for (const t of tokens) {
    const m = t.match(/^([a-zA-Z_][a-zA-Z0-9_]*)\s*\((.*)\)$/s);
    if (m) {
      embeds.push({ name: m[1], inner: m[2].trim() });
    } else {
      cols.push(t.trim());
    }
  }
  if (cols.length === 0) cols.push('*');
  return { cols, embeds };
}

function buildSelectExpr(table, select) {
  const { cols, embeds } = parseSelect(select);
  const parts = [];

  for (const c of cols) {
    if (c === '*') parts.push('t.*');
    else parts.push(`t.${ident(c)}`);
  }

  for (const e of embeds) {
    const rel = RELATIONSHIPS[`${table}.${e.name}`];
    if (!rel) throw new Error(`Unknown relationship: ${table}.${e.name}`);
    const refT = ident(rel.refTable);
    const fk = ident(rel.fk);
    let inner;
    if (e.inner === '*' || e.inner === '') {
      inner = `row_to_json(r)`;
      parts.push(
        `(SELECT ${inner} FROM (SELECT * FROM ${refT} WHERE ${refT}.id = t.${fk}) r) AS ${ident(e.name)}`,
      );
    } else {
      const innerCols = e.inner.split(',').map((s) => s.trim()).filter(Boolean);
      const jsonPairs = innerCols
        .map((c) => `'${c}', r.${ident(c)}`)
        .join(', ');
      parts.push(
        `(SELECT json_build_object(${jsonPairs}) FROM ${refT} r WHERE r.id = t.${fk}) AS ${ident(e.name)}`,
      );
    }
  }

  return parts.join(', ');
}

async function isAdmin(uid) {
  if (!uid) return false;
  const { rows } = await query(
    `SELECT 1 FROM profiles WHERE id = $1 AND role IN ('admin','manager') LIMIT 1`,
    [uid],
  );
  return rows.length > 0;
}

// Build WHERE clause from filters + scope. Returns { sql, params, nextIdx }.
function buildWhere(table, filters, params, startIdx, scopeClause) {
  const clauses = [];
  let idx = startIdx;
  for (const f of filters || []) {
    const col = ident(f.column);
    if (f.op === 'is') {
      // value is typically null
      clauses.push(`t.${col} IS ${f.value === null ? 'NULL' : 'NOT NULL'}`);
    } else if (f.op === 'in') {
      params.push(f.value);
      clauses.push(`t.${col} = ANY($${idx++})`);
    } else if (OPS[f.op]) {
      params.push(f.value);
      clauses.push(`t.${col} ${OPS[f.op]} $${idx++}`);
    } else {
      throw new Error(`Unsupported filter op: ${f.op}`);
    }
  }
  if (scopeClause) {
    params.push(scopeClause.value);
    clauses.push(`t.${ident(scopeClause.column)} = $${idx++}`);
  }
  return { sql: clauses.length ? `WHERE ${clauses.join(' AND ')}` : '', nextIdx: idx };
}

function scopeFor(table, uid) {
  const col = scopeColumn(table);
  if (!col) return null;
  return { column: col, value: uid };
}

restRouter.post('/query', requireAuth, async (req, res) => {
  try {
    const d = req.body || {};
    const table = d.table;
    if (!table || !ALLOWED.has(table)) {
      return res.status(400).json({ error: `Table not allowed: ${table}` });
    }
    const uid = req.user.id;
    const op = d.op || 'select';
    const T = ident(table);

    // ----- SELECT -----
    if (op === 'select') {
      const selectExpr = buildSelectExpr(table, d.select);
      const params = [];
      const scope = table === PROFILES ? null : scopeFor(table, uid);
      const { sql: whereSql, nextIdx } = buildWhere(table, d.filters, params, 1, scope);

      // Count support: `.select('*', { count: 'exact', head: true })`
      let count = null;
      if (d.count) {
        const countSql = `SELECT COUNT(*)::int AS count FROM ${T} t ${whereSql}`;
        const { rows: countRows } = await query(countSql, params);
        count = countRows[0]?.count ?? 0;
        if (d.head) {
          // head:true means "no rows, just the count".
          return res.json({ data: [], count, error: null });
        }
      }

      let sql = `SELECT ${selectExpr} FROM ${T} t ${whereSql}`;

      if (d.order && d.order.length) {
        const orderParts = d.order.map((o) => {
          const dir = o.ascending === false ? 'DESC' : 'ASC';
          const nulls = o.nullsFirst ? 'NULLS FIRST' : 'NULLS LAST';
          return `t.${ident(o.column)} ${dir} ${nulls}`;
        });
        sql += ` ORDER BY ${orderParts.join(', ')}`;
      }

      let idx = nextIdx;
      if (typeof d.rangeFrom === 'number' && typeof d.rangeTo === 'number') {
        params.push(d.rangeTo - d.rangeFrom + 1);
        sql += ` LIMIT $${idx++}`;
        params.push(d.rangeFrom);
        sql += ` OFFSET $${idx++}`;
      } else if (typeof d.limit === 'number') {
        params.push(d.limit);
        sql += ` LIMIT $${idx++}`;
      }

      const { rows } = await query(sql, params);

      if (d.single === 'one') {
        if (rows.length !== 1) {
          return res.json({
            data: null,
            count,
            error: { message: 'JSON object requested, multiple (or no) rows returned', code: 'PGRST116' },
          });
        }
        return res.json({ data: rows[0], count, error: null });
      }
      if (d.single === 'maybe') {
        return res.json({ data: rows[0] ?? null, count, error: null });
      }
      return res.json({ data: rows, count, error: null });
    }

    // ----- INSERT / UPSERT -----
    if (op === 'insert' || op === 'upsert') {
      let records = Array.isArray(d.values) ? d.values : [d.values];
      records = records.filter(Boolean);
      if (records.length === 0) return res.json({ data: [], error: null });

      const scopeCol = scopeColumn(table);
      if (scopeCol) {
        records = records.map((r) => ({ [scopeCol]: uid, ...r, [scopeCol]: r[scopeCol] ?? uid }));
      }
      if (table === PROFILES) {
        const admin = await isAdmin(uid);
        if (!admin) records = records.map((r) => ({ ...r, id: uid }));
      }

      const columns = Array.from(
        records.reduce((set, r) => {
          Object.keys(r).forEach((k) => set.add(k));
          return set;
        }, new Set()),
      );
      const colSql = columns.map(ident).join(', ');
      const params = [];
      let idx = 1;
      const valueRows = records.map((r) => {
        const placeholders = columns.map((c) => {
          params.push(r[c] ?? null);
          return `$${idx++}`;
        });
        return `(${placeholders.join(', ')})`;
      });

      let sql = `INSERT INTO ${T} (${colSql}) VALUES ${valueRows.join(', ')}`;

      if (op === 'upsert' && d.onConflict) {
        const conflictCols = d.onConflict.split(',').map((s) => ident(s.trim())).join(', ');
        const updates = columns
          .filter((c) => !d.onConflict.split(',').map((s) => s.trim()).includes(c))
          .map((c) => `${ident(c)} = EXCLUDED.${ident(c)}`)
          .join(', ');
        sql += updates
          ? ` ON CONFLICT (${conflictCols}) DO UPDATE SET ${updates}`
          : ` ON CONFLICT (${conflictCols}) DO NOTHING`;
      }

      if (d.returning) {
        const { cols } = parseSelect(d.returning === true ? '*' : d.returning);
        sql += ` RETURNING ${cols.map((c) => (c === '*' ? '*' : ident(c))).join(', ')}`;
      }

      const { rows } = await query(sql, params);
      if (d.returning && d.single) {
        return res.json({ data: rows[0] ?? null, error: null });
      }
      return res.json({ data: d.returning ? rows : null, error: null });
    }

    // ----- UPDATE -----
    if (op === 'update') {
      const values = d.values || {};
      if (table === PROFILES) {
        const admin = await isAdmin(uid);
        if (!admin) {
          d.filters = [...(d.filters || []), { op: 'eq', column: 'id', value: uid }];
        }
      }
      const params = [];
      let idx = 1;
      const setCols = Object.keys(values);
      if (setCols.length === 0) return res.json({ data: null, error: { message: 'No update values' } });
      const setSql = setCols
        .map((c) => {
          params.push(values[c] ?? null);
          return `${ident(c)} = $${idx++}`;
        })
        .join(', ');

      const scope = table === PROFILES ? null : scopeFor(table, uid);
      const { sql: whereSql } = buildWhere(table, d.filters, params, idx, scope);

      let sql = `UPDATE ${T} t SET ${setSql} ${whereSql}`;
      if (d.returning) {
        const { cols } = parseSelect(d.returning === true ? '*' : d.returning);
        sql += ` RETURNING ${cols.map((c) => (c === '*' ? '*' : ident(c))).join(', ')}`;
      }
      const { rows } = await query(sql, params);
      if (d.returning && d.single) return res.json({ data: rows[0] ?? null, error: null });
      return res.json({ data: d.returning ? rows : null, error: null });
    }

    // ----- DELETE -----
    if (op === 'delete') {
      if (table === PROFILES) {
        const admin = await isAdmin(uid);
        if (!admin) {
          d.filters = [...(d.filters || []), { op: 'eq', column: 'id', value: uid }];
        }
      }
      const params = [];
      const scope = table === PROFILES ? null : scopeFor(table, uid);
      const { sql: whereSql } = buildWhere(table, d.filters, params, 1, scope);
      if (!whereSql) return res.status(400).json({ error: 'Refusing unfiltered delete' });
      let sql = `DELETE FROM ${T} t ${whereSql}`;
      if (d.returning) {
        const { cols } = parseSelect(d.returning === true ? '*' : d.returning);
        sql += ` RETURNING ${cols.map((c) => (c === '*' ? '*' : ident(c))).join(', ')}`;
      }
      const { rows } = await query(sql, params);
      return res.json({ data: d.returning ? rows : null, error: null });
    }

    return res.status(400).json({ error: `Unknown op: ${op}` });
  } catch (err) {
    console.error('[rest] error:', err.message);
    return res.json({ data: null, error: { message: err.message } });
  }
});
