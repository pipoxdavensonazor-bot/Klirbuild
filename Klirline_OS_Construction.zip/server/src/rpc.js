import express from 'express';
import { query } from './db.js';
import { optionalAuth } from './cognito.js';

export const rpcRouter = express.Router();

// Mirrors the Supabase `.rpc(fn, args)` surface. Only whitelisted functions run.
rpcRouter.post('/:fn', optionalAuth, async (req, res) => {
  const { fn } = req.params;
  try {
    if (fn === 'count_admins') {
      const { rows } = await query(`SELECT count_admins() AS count`);
      // PostgREST returns the scalar directly for a scalar-returning function.
      return res.json({ data: rows[0].count, error: null });
    }
    return res.json({ data: null, error: { message: `Unknown function: ${fn}` } });
  } catch (err) {
    console.error('[rpc] error:', err.message);
    return res.json({ data: null, error: { message: err.message } });
  }
});
