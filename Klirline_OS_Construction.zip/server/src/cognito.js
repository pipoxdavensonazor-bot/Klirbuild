import jwt from 'jsonwebtoken';
import { JwksClient } from 'jwks-rsa';

const REGION = process.env.COGNITO_REGION || process.env.AWS_REGION || '';
const USER_POOL_ID = process.env.COGNITO_USER_POOL_ID || '';
const CLIENT_ID = process.env.COGNITO_CLIENT_ID || '';

const ISSUER = USER_POOL_ID
  ? `https://cognito-idp.${REGION}.amazonaws.com/${USER_POOL_ID}`
  : '';

const jwks = ISSUER
  ? new JwksClient({
      jwksUri: `${ISSUER}/.well-known/jwks.json`,
      cache: true,
      rateLimit: true,
    })
  : null;

function getKey(header, callback) {
  if (!jwks) return callback(new Error('Cognito not configured'));
  jwks.getSigningKey(header.kid, (err, key) => {
    if (err) return callback(err);
    callback(null, key.getPublicKey());
  });
}

/**
 * Verifies a Cognito-issued JWT (access or id token) and resolves to a claims object.
 */
export function verifyToken(token) {
  return new Promise((resolve, reject) => {
    if (!ISSUER) return reject(new Error('Cognito not configured'));
    jwt.verify(
      token,
      getKey,
      { issuer: ISSUER, algorithms: ['RS256'] },
      (err, decoded) => {
        if (err) return reject(err);
        // For access tokens the audience lives in `client_id`; id tokens use `aud`.
        if (CLIENT_ID) {
          const aud = decoded.aud || decoded.client_id;
          if (aud && aud !== CLIENT_ID) return reject(new Error('Token audience mismatch'));
        }
        resolve(decoded);
      },
    );
  });
}

/**
 * Express middleware: requires a valid Bearer token and attaches `req.user`.
 * req.user = { id, email, claims }
 */
export async function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Non autorisé' });
  try {
    const claims = await verifyToken(token);
    req.user = {
      id: claims.sub,
      email: claims.email || claims['cognito:username'] || null,
      claims,
    };
    next();
  } catch (err) {
    res.status(401).json({ error: 'Session invalide', detail: err.message });
  }
}

/**
 * Optional auth: attaches req.user when a valid token is present, but never blocks.
 * Used by endpoints such as the first-run admin count.
 */
export async function optionalAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (token) {
    try {
      const claims = await verifyToken(token);
      req.user = { id: claims.sub, email: claims.email ?? null, claims };
    } catch {
      /* ignore — treated as anonymous */
    }
  }
  next();
}

export const cognitoConfig = { REGION, USER_POOL_ID, CLIENT_ID, ISSUER };
