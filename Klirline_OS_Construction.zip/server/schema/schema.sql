-- ============================================================================
-- Klirline OS — Consolidated Aurora PostgreSQL schema
-- ----------------------------------------------------------------------------
-- Ported from the original Supabase migrations. Key differences vs Supabase:
--   * No Row Level Security / policies  — authorization is enforced in the
--     Express API layer (per-request owner/user scoping using the Cognito sub).
--   * No `auth.users` table / FKs        — user identities live in AWS Cognito.
--     Columns that referenced auth.users are now plain `uuid` (the Cognito sub).
--   * No `auth.uid()` defaults           — owner_id / user_id are injected by
--     the API from the authenticated token.
--   * No signup trigger                  — the API creates a profile row on
--     first login / signup.
-- Apply with:  psql "$DATABASE_URL" -f server/schema/schema.sql
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ─── PROFILES ───────────────────────────────────────────────────────────────
-- id = Cognito `sub` (UUID string)
CREATE TABLE IF NOT EXISTS profiles (
  id                  uuid PRIMARY KEY,
  email               text,
  full_name           text,
  role                text NOT NULL DEFAULT 'employee',
  department          text,
  avatar_url          text,
  is_active           boolean NOT NULL DEFAULT true,
  subscription_status text NOT NULL DEFAULT 'none',
  created_at          timestamptz NOT NULL DEFAULT now()
);

-- ─── SUBSCRIPTIONS ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subscriptions (
  id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id                uuid NOT NULL,
  stripe_customer_id      text,
  stripe_subscription_id  text UNIQUE,
  price_id                text,
  plan                    text NOT NULL DEFAULT 'starter',
  status                  text NOT NULL DEFAULT 'trialing',
  current_period_end      timestamptz,
  cancel_at_period_end    boolean NOT NULL DEFAULT false,
  created_at              timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT subscriptions_owner_unique UNIQUE (owner_id)
);

-- ─── INVITE CODES ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invite_codes (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code        text UNIQUE NOT NULL,
  role        text NOT NULL DEFAULT 'employee',
  created_by  uuid,
  used_by     uuid,
  used_at     timestamptz,
  expires_at  timestamptz,
  created_at  timestamptz DEFAULT now()
);

-- ─── EMPLOYEES ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS employees (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name   text NOT NULL,
  last_name    text NOT NULL,
  email        text UNIQUE,
  phone        text,
  role         text NOT NULL DEFAULT 'worker',
  department   text,
  hire_date    date,
  salary       numeric(12,2),
  status       text NOT NULL DEFAULT 'active',
  avatar_url   text,
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── CLIENTS ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clients (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text,
  first_name   text NOT NULL DEFAULT '',
  last_name    text NOT NULL DEFAULT '',
  email        text,
  phone        text,
  address      text,
  city         text,
  province     text,
  postal_code  text,
  status       text NOT NULL DEFAULT 'active',
  type         text NOT NULL DEFAULT 'residential',
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── LEADS ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS leads (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name   text NOT NULL,
  last_name    text NOT NULL,
  company_name text,
  email        text,
  phone        text,
  source       text,
  stage        text NOT NULL DEFAULT 'new',
  value        numeric(12,2),
  notes        text,
  assigned_to  uuid REFERENCES employees(id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── PROJECTS (CHANTIERS) ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS projects (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name            text NOT NULL,
  description     text,
  client_id       uuid REFERENCES clients(id) ON DELETE SET NULL,
  foreman_id      uuid REFERENCES employees(id) ON DELETE SET NULL,
  address         text,
  city            text,
  start_date      date,
  end_date        date,
  status          text NOT NULL DEFAULT 'planning',
  budget          numeric(12,2),
  spent           numeric(12,2) NOT NULL DEFAULT 0,
  notes           text,
  qr_code         text,
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- ─── PROJECT EMPLOYEES ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS project_employees (
  project_id   uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  employee_id  uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  role         text,
  PRIMARY KEY (project_id, employee_id)
);

-- ─── TASKS ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tasks (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id   uuid REFERENCES projects(id) ON DELETE CASCADE,
  title        text NOT NULL,
  description  text,
  assigned_to  uuid REFERENCES employees(id) ON DELETE SET NULL,
  status       text NOT NULL DEFAULT 'todo',
  priority     text NOT NULL DEFAULT 'medium',
  due_date     date,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── TIME ENTRIES (PRÉSENCES) ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS time_entries (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id  uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  project_id   uuid REFERENCES projects(id) ON DELETE SET NULL,
  clock_in     timestamptz NOT NULL DEFAULT now(),
  clock_out    timestamptz,
  lat_in       double precision,
  lng_in       double precision,
  lat_out      double precision,
  lng_out      double precision,
  notes        text,
  status       text NOT NULL DEFAULT 'active',
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── INVOICES ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoices (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_no   text UNIQUE NOT NULL,
  client_id    uuid REFERENCES clients(id) ON DELETE SET NULL,
  project_id   uuid REFERENCES projects(id) ON DELETE SET NULL,
  issue_date   date NOT NULL DEFAULT CURRENT_DATE,
  due_date     date,
  status       text NOT NULL DEFAULT 'draft',
  subtotal     numeric(12,2) NOT NULL DEFAULT 0,
  tax_rate     numeric(5,2) NOT NULL DEFAULT 15,
  tax_amount   numeric(12,2) NOT NULL DEFAULT 0,
  total        numeric(12,2) NOT NULL DEFAULT 0,
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── INVOICE ITEMS ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoice_items (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id   uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  description  text NOT NULL,
  quantity     numeric(10,2) NOT NULL DEFAULT 1,
  unit_price   numeric(12,2) NOT NULL DEFAULT 0,
  total        numeric(12,2) NOT NULL DEFAULT 0,
  sort_order   integer NOT NULL DEFAULT 0
);

-- ─── PAYMENTS ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payments (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id   uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  amount       numeric(12,2) NOT NULL,
  method       text NOT NULL DEFAULT 'transfer',
  paid_at      timestamptz NOT NULL DEFAULT now(),
  reference    text,
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── EXPENSES ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS expenses (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id   uuid REFERENCES projects(id) ON DELETE SET NULL,
  employee_id  uuid REFERENCES employees(id) ON DELETE SET NULL,
  category     text NOT NULL DEFAULT 'materials',
  description  text NOT NULL,
  amount       numeric(12,2) NOT NULL,
  date         date NOT NULL DEFAULT CURRENT_DATE,
  receipt_url  text,
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── DOCUMENTS ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS documents (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name         text NOT NULL,
  type         text NOT NULL DEFAULT 'other',
  file_url     text,
  file_size    integer,
  mime_type    text,
  project_id   uuid REFERENCES projects(id) ON DELETE SET NULL,
  client_id    uuid REFERENCES clients(id) ON DELETE SET NULL,
  uploaded_by  uuid REFERENCES employees(id) ON DELETE SET NULL,
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── CHAT CHANNELS ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS chat_channels (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name         text NOT NULL,
  type         text NOT NULL DEFAULT 'group',
  project_id   uuid REFERENCES projects(id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── CHAT MESSAGES ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS chat_messages (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id   uuid NOT NULL REFERENCES chat_channels(id) ON DELETE CASCADE,
  sender_name  text NOT NULL,
  sender_role  text,
  content      text NOT NULL,
  file_url     text,
  file_name    text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ─── EMAILS (local/manual emails) ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS emails (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid,
  client_id   uuid REFERENCES clients(id) ON DELETE SET NULL,
  direction   text NOT NULL DEFAULT 'outbound' CHECK (direction IN ('inbound','outbound')),
  from_addr   text NOT NULL DEFAULT '',
  to_addr     text NOT NULL DEFAULT '',
  subject     text NOT NULL DEFAULT '',
  body        text,
  status      text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','sent','received')),
  sent_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- ─── GMAIL TOKENS ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS gmail_tokens (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL,
  gmail_email   text NOT NULL,
  access_token  text NOT NULL,
  refresh_token text,
  expires_at    timestamptz,
  scope         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, gmail_email)
);

-- ─── M365 TOKENS ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS m365_tokens (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL,
  ms_email      text NOT NULL,
  access_token  text NOT NULL,
  refresh_token text,
  expires_at    timestamptz,
  scope         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, ms_email)
);

-- ─── SOUMISSIONS (QUOTES) ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS soumissions (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  soumission_no       text UNIQUE NOT NULL,
  client_id           uuid REFERENCES clients(id) ON DELETE SET NULL,
  titre               text NOT NULL DEFAULT '',
  description         text,
  status              text NOT NULL DEFAULT 'brouillon'
                        CHECK (status IN ('brouillon','envoyée','approuvée','refusée','expirée')),
  issue_date          date NOT NULL DEFAULT CURRENT_DATE,
  valid_until         date,
  subtotal            numeric(12,2) NOT NULL DEFAULT 0,
  tps_rate            numeric(5,3)  NOT NULL DEFAULT 5,
  tvq_rate            numeric(5,3)  NOT NULL DEFAULT 9.975,
  tps_amount          numeric(12,2) NOT NULL DEFAULT 0,
  tvq_amount          numeric(12,2) NOT NULL DEFAULT 0,
  total               numeric(12,2) NOT NULL DEFAULT 0,
  notes               text,
  converted_invoice_id uuid REFERENCES invoices(id) ON DELETE SET NULL,
  owner_id            uuid NOT NULL,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS soumission_items (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  soumission_id   uuid NOT NULL REFERENCES soumissions(id) ON DELETE CASCADE,
  description     text NOT NULL DEFAULT '',
  quantity        numeric(10,2) NOT NULL DEFAULT 1,
  unit            text NOT NULL DEFAULT 'forfait',
  unit_price      numeric(12,2) NOT NULL DEFAULT 0,
  total           numeric(12,2) NOT NULL DEFAULT 0,
  sort_order      integer NOT NULL DEFAULT 0
);

-- ─── COMPANY SETTINGS ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS company_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  nom_entreprise text NOT NULL DEFAULT '',
  neq text NOT NULL DEFAULT '',
  rbq text NOT NULL DEFAULT '',
  tps_no text NOT NULL DEFAULT '',
  tvq_no text NOT NULL DEFAULT '',
  adresse text NOT NULL DEFAULT '',
  ville text NOT NULL DEFAULT '',
  province text NOT NULL DEFAULT 'QC',
  code_postal text NOT NULL DEFAULT '',
  telephone text NOT NULL DEFAULT '',
  courriel text NOT NULL DEFAULT '',
  site_web text NOT NULL DEFAULT '',
  logo_url text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT company_settings_owner_unique UNIQUE (owner_id)
);

-- ─── PAYROLL ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payroll_employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  sin text,
  email text,
  phone text,
  address text,
  city text,
  province text DEFAULT 'QC',
  postal_code text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','on_leave','terminated')),
  employment_type text NOT NULL DEFAULT 'permanent' CHECK (employment_type IN ('permanent','temporary','contract','seasonal')),
  hire_date date,
  termination_date date,
  department text,
  position text,
  pay_type text NOT NULL DEFAULT 'hourly' CHECK (pay_type IN ('hourly','salary')),
  pay_frequency text NOT NULL DEFAULT 'biweekly' CHECK (pay_frequency IN ('weekly','biweekly','semimonthly','monthly')),
  hourly_rate numeric(10,4),
  annual_salary numeric(12,2),
  federal_td1_credits numeric(12,2) NOT NULL DEFAULT 15705.00,
  provincial_td1_credits numeric(12,2) NOT NULL DEFAULT 17183.00,
  bank_institution text,
  bank_transit text,
  bank_account text,
  ccq_classification text,
  ccq_number text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payroll_periods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  period_start date NOT NULL,
  period_end date NOT NULL,
  pay_date date NOT NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','approved','paid','cancelled')),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payroll_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  period_id uuid NOT NULL REFERENCES payroll_periods(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES payroll_employees(id) ON DELETE CASCADE,
  hours_regular numeric(8,2) NOT NULL DEFAULT 0,
  hours_overtime numeric(8,2) NOT NULL DEFAULT 0,
  hours_double numeric(8,2) NOT NULL DEFAULT 0,
  hours_vacation numeric(8,2) NOT NULL DEFAULT 0,
  hours_sick numeric(8,2) NOT NULL DEFAULT 0,
  hours_holiday numeric(8,2) NOT NULL DEFAULT 0,
  regular_rate numeric(10,4),
  gross_pay numeric(12,2) NOT NULL DEFAULT 0,
  vacation_pay numeric(12,2) NOT NULL DEFAULT 0,
  bonus numeric(12,2) NOT NULL DEFAULT 0,
  commission numeric(12,2) NOT NULL DEFAULT 0,
  expense_reimbursement numeric(12,2) NOT NULL DEFAULT 0,
  federal_tax numeric(12,2) NOT NULL DEFAULT 0,
  provincial_tax numeric(12,2) NOT NULL DEFAULT 0,
  rrq_employee numeric(12,2) NOT NULL DEFAULT 0,
  ei_employee numeric(12,2) NOT NULL DEFAULT 0,
  rqap_employee numeric(12,2) NOT NULL DEFAULT 0,
  collective_insurance numeric(12,2) NOT NULL DEFAULT 0,
  rrsp_employee numeric(12,2) NOT NULL DEFAULT 0,
  union_dues numeric(12,2) NOT NULL DEFAULT 0,
  other_deductions numeric(12,2) NOT NULL DEFAULT 0,
  total_deductions numeric(12,2) NOT NULL DEFAULT 0,
  rrq_employer numeric(12,2) NOT NULL DEFAULT 0,
  ei_employer numeric(12,2) NOT NULL DEFAULT 0,
  rqap_employer numeric(12,2) NOT NULL DEFAULT 0,
  cnesst_employer numeric(12,2) NOT NULL DEFAULT 0,
  net_pay numeric(12,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','approved','paid','void')),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS fiscal_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  year int NOT NULL,
  tps_rate numeric(6,4) NOT NULL DEFAULT 0.05,
  tvq_rate numeric(6,4) NOT NULL DEFAULT 0.09975,
  rrq_employee_rate numeric(6,4) NOT NULL DEFAULT 0.064,
  rrq_employer_rate numeric(6,4) NOT NULL DEFAULT 0.064,
  rrq_max_pensionable numeric(12,2) NOT NULL DEFAULT 68500.00,
  rrq_exemption numeric(12,2) NOT NULL DEFAULT 3500.00,
  ei_employee_rate numeric(6,4) NOT NULL DEFAULT 0.0132,
  ei_employer_multiplier numeric(6,4) NOT NULL DEFAULT 1.4,
  ei_max_insurable numeric(12,2) NOT NULL DEFAULT 63200.00,
  rqap_employee_rate numeric(6,4) NOT NULL DEFAULT 0.00494,
  rqap_employer_rate numeric(6,4) NOT NULL DEFAULT 0.00692,
  rqap_max_insurable numeric(12,2) NOT NULL DEFAULT 94000.00,
  cnesst_rate numeric(6,4) NOT NULL DEFAULT 0.0400,
  vacation_rate_year1 numeric(6,4) NOT NULL DEFAULT 0.04,
  vacation_rate_year3 numeric(6,4) NOT NULL DEFAULT 0.06,
  federal_brackets jsonb NOT NULL DEFAULT '[
    {"min": 0,      "max": 55867,   "rate": 0.15,   "base": 0},
    {"min": 55867,  "max": 111733,  "rate": 0.205,  "base": 8380.05},
    {"min": 111733, "max": 154906,  "rate": 0.26,   "base": 19591.82},
    {"min": 154906, "max": 220000,  "rate": 0.29,   "base": 30823.14},
    {"min": 220000, "max": null,    "rate": 0.33,   "base": 49698.14}
  ]',
  provincial_brackets jsonb NOT NULL DEFAULT '[
    {"min": 0,      "max": 51780,   "rate": 0.14,   "base": 0},
    {"min": 51780,  "max": 103545,  "rate": 0.19,   "base": 7249.20},
    {"min": 103545, "max": 126000,  "rate": 0.24,   "base": 17083.05},
    {"min": 126000, "max": null,    "rate": 0.2575, "base": 22476.45}
  ]',
  federal_qc_abatement numeric(6,4) NOT NULL DEFAULT 0.165,
  federal_basic_personal numeric(12,2) NOT NULL DEFAULT 15705.00,
  provincial_basic_personal numeric(12,2) NOT NULL DEFAULT 17183.00,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(owner_id, year)
);

CREATE TABLE IF NOT EXISTS audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  action text NOT NULL,
  table_name text NOT NULL,
  record_id uuid,
  old_values jsonb,
  new_values jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ─── CCQ MODULE ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ccq_certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  employee_id uuid REFERENCES payroll_employees(id) ON DELETE SET NULL,
  numero_certificat text NOT NULL,
  type_certificat text NOT NULL DEFAULT 'compagnon' CHECK (type_certificat IN ('apprenti', 'compagnon', 'occupation')),
  metier text NOT NULL,
  specialite text,
  niveau_apprentissage int CHECK (niveau_apprentissage BETWEEN 1 AND 5),
  secteur text NOT NULL DEFAULT 'Résidentiel',
  region text NOT NULL DEFAULT 'Montréal',
  date_emission date,
  date_expiration date,
  date_renouvellement date,
  status text NOT NULL DEFAULT 'actif' CHECK (status IN ('actif', 'expiré', 'suspendu', 'révoqué')),
  formations_obligatoires jsonb DEFAULT '[]',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ccq_conventions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  secteur text NOT NULL,
  region text NOT NULL,
  nom text NOT NULL,
  annee int NOT NULL,
  date_entree_vigueur date,
  date_expiration date,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'expired', 'pending')),
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ccq_wage_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  convention_id uuid NOT NULL REFERENCES ccq_conventions(id) ON DELETE CASCADE,
  metier text NOT NULL,
  classification text NOT NULL,
  taux_horaire_base numeric(10,4) NOT NULL DEFAULT 0,
  taux_vacances_pct numeric(6,4) NOT NULL DEFAULT 8.33,
  prime_nuit numeric(10,4) DEFAULT 0,
  prime_fin_semaine numeric(10,4) DEFAULT 0,
  prime_ferie numeric(10,4) DEFAULT 0,
  indemnite_deplacement numeric(10,4) DEFAULT 0,
  indemnite_repas numeric(10,4) DEFAULT 0,
  indemnite_hebergement numeric(10,4) DEFAULT 0,
  supp_ot_50pct_after_h numeric(5,2) DEFAULT 8,
  supp_ot_100pct_after_h numeric(5,2) DEFAULT 10,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ccq_social_contributions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  convention_id uuid NOT NULL REFERENCES ccq_conventions(id) ON DELETE CASCADE,
  cotisation_syndicale_rate numeric(6,4) DEFAULT 1.80,
  fonds_formation_employee_rate numeric(6,4) DEFAULT 0.75,
  fonds_formation_employer_rate numeric(6,4) DEFAULT 0.75,
  fonds_retraite_employee_rate numeric(6,4) DEFAULT 4.50,
  fonds_retraite_employer_rate numeric(6,4) DEFAULT 4.50,
  assurance_collective_employee_rate numeric(6,4) DEFAULT 1.50,
  assurance_collective_employer_rate numeric(6,4) DEFAULT 2.00,
  autres_cotisations jsonb DEFAULT '[]',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (convention_id)
);

CREATE TABLE IF NOT EXISTS ccq_declarations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  periode_mois text NOT NULL,
  statut text NOT NULL DEFAULT 'brouillon' CHECK (statut IN ('brouillon', 'soumis', 'payé', 'rejeté')),
  nb_travailleurs int DEFAULT 0,
  total_heures numeric(12,2) DEFAULT 0,
  total_salaires_bruts numeric(14,2) DEFAULT 0,
  total_cotisations_employee numeric(14,2) DEFAULT 0,
  total_cotisations_employer numeric(14,2) DEFAULT 0,
  date_soumission timestamptz,
  date_paiement timestamptz,
  reference_ccq text,
  fichier_pdf_url text,
  fichier_excel_url text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (owner_id, periode_mois)
);

CREATE TABLE IF NOT EXISTS cnesst_incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  employee_id uuid REFERENCES payroll_employees(id) ON DELETE SET NULL,
  date_incident date NOT NULL,
  type_incident text NOT NULL DEFAULT 'premiers_soins' CHECK (type_incident IN ('accident', 'quasi_accident', 'premiers_soins', 'temps_perdu', 'maladie_professionnelle')),
  description text NOT NULL,
  nature_lesion text CHECK (nature_lesion IN ('contusion', 'coupure', 'fracture', 'brulure', 'entorse', 'strain', 'autre')),
  partie_corps_atteinte text,
  jours_perdus int DEFAULT 0,
  cout_estimatif numeric(12,2) DEFAULT 0,
  statut text NOT NULL DEFAULT 'ouvert' CHECK (statut IN ('ouvert', 'en_enquete', 'ferme', 'conteste')),
  date_fermeture date,
  mesures_preventives jsonb DEFAULT '[]',
  pieces_jointes jsonb DEFAULT '[]',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- ─── count_admins() — used by the first-run check via /rest/v1/rpc ─────────────
CREATE OR REPLACE FUNCTION count_admins()
RETURNS integer
LANGUAGE sql
STABLE
AS $$
  SELECT COUNT(*)::integer FROM profiles WHERE role = 'admin';
$$;

-- ─── stripe_user_subscriptions view (owner-scoped by the API) ──────────────────
CREATE OR REPLACE VIEW stripe_user_subscriptions AS
SELECT
  owner_id,
  status                                          AS subscription_status,
  price_id,
  EXTRACT(EPOCH FROM current_period_end)::bigint  AS current_period_end,
  cancel_at_period_end
FROM subscriptions;

-- ─── INDEXES ──────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_subscriptions_owner ON subscriptions(owner_id);
CREATE INDEX IF NOT EXISTS idx_leads_stage ON leads(stage);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_client_id ON projects(client_id);
CREATE INDEX IF NOT EXISTS idx_tasks_project_id ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_time_entries_employee_id ON time_entries(employee_id);
CREATE INDEX IF NOT EXISTS idx_time_entries_project_id ON time_entries(project_id);
CREATE INDEX IF NOT EXISTS idx_invoices_client_id ON invoices(client_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_chat_messages_channel_id ON chat_messages(channel_id);
CREATE INDEX IF NOT EXISTS idx_emails_user ON emails(user_id);
CREATE INDEX IF NOT EXISTS idx_emails_client_id ON emails(client_id);
CREATE INDEX IF NOT EXISTS idx_gmail_tokens_user ON gmail_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_m365_tokens_user ON m365_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_soumissions_owner  ON soumissions(owner_id);
CREATE INDEX IF NOT EXISTS idx_soumissions_client ON soumissions(client_id);
CREATE INDEX IF NOT EXISTS idx_soumissions_status ON soumissions(status);
CREATE INDEX IF NOT EXISTS idx_soumission_items_sid ON soumission_items(soumission_id);
CREATE INDEX IF NOT EXISTS idx_payroll_periods_owner ON payroll_periods(owner_id);
CREATE INDEX IF NOT EXISTS idx_payroll_periods_dates ON payroll_periods(period_start, period_end);
CREATE INDEX IF NOT EXISTS idx_payroll_entries_owner ON payroll_entries(owner_id);
CREATE INDEX IF NOT EXISTS idx_payroll_entries_period ON payroll_entries(period_id);
CREATE INDEX IF NOT EXISTS idx_payroll_entries_employee ON payroll_entries(employee_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_payroll_entries_unique ON payroll_entries(period_id, employee_id);
CREATE INDEX IF NOT EXISTS idx_fiscal_rates_owner_year ON fiscal_rates(owner_id, year);
CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_table ON audit_log(table_name, record_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_created ON audit_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ccq_cert_employee ON ccq_certificates(employee_id);
CREATE INDEX IF NOT EXISTS idx_ccq_cert_status ON ccq_certificates(status);
CREATE INDEX IF NOT EXISTS idx_ccq_cert_expiry ON ccq_certificates(date_expiration);
CREATE INDEX IF NOT EXISTS idx_ccq_wage_convention ON ccq_wage_rates(convention_id);
CREATE INDEX IF NOT EXISTS idx_ccq_social_convention ON ccq_social_contributions(convention_id);
CREATE INDEX IF NOT EXISTS idx_ccq_decl_periode ON ccq_declarations(periode_mois);
CREATE INDEX IF NOT EXISTS idx_cnesst_employee ON cnesst_incidents(employee_id);
CREATE INDEX IF NOT EXISTS idx_cnesst_statut ON cnesst_incidents(statut);
CREATE INDEX IF NOT EXISTS idx_cnesst_date ON cnesst_incidents(date_incident);
